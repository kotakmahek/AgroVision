import React, { useState } from "react";
import { VERIFIED_RESEARCH_DATASETS, SUPPORTED_RESEARCH_CLASSES } from "../data/researchDatasets";
import { 
  Database, 
  ExternalLink, 
  ShieldCheck, 
  BookOpen, 
  CheckCircle2, 
  Sprout, 
  Building2, 
  Scale, 
  FileCheck,
  Award
} from "lucide-react";

export const DataSourcesView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<"ORGANIZATIONS" | "PATHOLOGY_CATALOGUE" | "ETHICS">("ORGANIZATIONS");

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-br from-emerald-950 via-slate-900 to-emerald-950/80 border border-emerald-800/60 rounded-3xl p-6 sm:p-8 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 space-y-3">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="px-3 py-1 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded-full text-xs font-bold flex items-center gap-1.5 shadow-sm">
              <Database className="w-3.5 h-3.5 text-emerald-400" />
              Open Science & Data Provenance
            </span>
            <span className="px-3 py-1 bg-slate-800/80 text-slate-300 border border-slate-700/60 rounded-full text-xs font-medium">
              Government of India & Global Repositories
            </span>
          </div>

          <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight font-['Outfit',sans-serif]">
            Data Sources, Research Citations & <span className="text-emerald-400">Licensing</span>
          </h2>

          <p className="text-slate-300 text-sm sm:text-base max-w-3xl leading-relaxed">
            AgroVision AI adheres strictly to academic integrity and data attribution. Below is the full registry of verified public institutions, open-access research repositories, and chemical safety guidelines that form the foundation of our pathology screening engine.
          </p>

          <div className="flex items-center gap-2 pt-2 border-t border-emerald-900/60">
            <button
              onClick={() => setActiveTab("ORGANIZATIONS")}
              className={`px-4 py-1.5 rounded-xl text-xs font-bold transition ${activeTab === "ORGANIZATIONS" ? "bg-emerald-600 text-white" : "text-slate-300 hover:text-white hover:bg-slate-800/60"}`}
            >
              Research Organizations ({VERIFIED_RESEARCH_DATASETS.length})
            </button>
            <button
              onClick={() => setActiveTab("PATHOLOGY_CATALOGUE")}
              className={`px-4 py-1.5 rounded-xl text-xs font-bold transition ${activeTab === "PATHOLOGY_CATALOGUE" ? "bg-emerald-600 text-white" : "text-slate-300 hover:text-white hover:bg-slate-800/60"}`}
            >
              Supported Crops & Pathology Classes ({SUPPORTED_RESEARCH_CLASSES.length})
            </button>
            <button
              onClick={() => setActiveTab("ETHICS")}
              className={`px-4 py-1.5 rounded-xl text-xs font-bold transition ${activeTab === "ETHICS" ? "bg-emerald-600 text-white" : "text-slate-300 hover:text-white hover:bg-slate-800/60"}`}
            >
              Ethical AI & Legal Compliance
            </button>
          </div>
        </div>
      </div>

      {/* Tab 1: Verified Research Organizations */}
      {activeTab === "ORGANIZATIONS" && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {VERIFIED_RESEARCH_DATASETS.map((ds) => (
            <div
              key={ds.id}
              className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-4 hover:border-emerald-700/50 transition flex flex-col justify-between"
            >
              <div className="space-y-2">
                <div className="flex items-start justify-between gap-2">
                  <span className="px-2.5 py-0.5 rounded-md text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                    {ds.imageType}
                  </span>
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-slate-950 text-slate-300 border border-slate-800">
                    {ds.licenseType}
                  </span>
                </div>

                <h3 className="text-sm font-bold text-white leading-snug">
                  {ds.name}
                </h3>

                <p className="text-xs text-emerald-400 font-semibold flex items-center gap-1.5">
                  <Building2 className="w-3.5 h-3.5 shrink-0" />
                  {ds.sourceOrganization}
                </p>

                <p className="text-xs text-slate-400 font-mono bg-slate-950 p-2.5 rounded-xl border border-slate-800/80 leading-relaxed">
                  {ds.citation}
                </p>
              </div>

              <div className="space-y-3 pt-3 border-t border-slate-800/80">
                <div className="flex items-center justify-between text-xs text-slate-300">
                  <span>Image Count: <strong className="text-white">{ds.imageCount.toLocaleString()}</strong></span>
                  <span>Lighting: <strong className="text-slate-200">{ds.lightingConditions.slice(0, 30)}...</strong></span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-[11px] text-slate-400">
                    License: <strong className="text-slate-200">{ds.license}</strong>
                  </span>
                  <a
                    href={ds.url}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1 text-xs font-bold text-emerald-400 hover:text-emerald-300 transition"
                  >
                    <span>Source Repository</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Tab 2: Supported Crops & Pathology Catalogue */}
      {activeTab === "PATHOLOGY_CATALOGUE" && (
        <div className="space-y-4">
          <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl flex items-center justify-between text-xs text-slate-300">
            <span>
              Below are verified crop-pathology relationships codified from ICAR, TNAU, and PlantDoc research standards.
            </span>
            <span className="font-bold text-emerald-400">
              {SUPPORTED_RESEARCH_CLASSES.length} Official Diagnosable Classes
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {SUPPORTED_RESEARCH_CLASSES.map((cls, idx) => (
              <div
                key={idx}
                className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-3"
              >
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-1 bg-emerald-500/20 text-emerald-300 rounded-lg text-xs font-bold">
                      {cls.cropEnglish} ({cls.cropMarathi})
                    </span>
                    <span className="text-xs text-slate-400 italic">
                      {cls.scientificCropName}
                    </span>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-950 text-slate-300 border border-slate-800">
                    {cls.pathologyType}
                  </span>
                </div>

                <div>
                  <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                    {cls.conditionName}
                    <span className="text-emerald-400 font-semibold">({cls.conditionMarathi})</span>
                  </h4>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Pathogen: <strong className="text-slate-300">{cls.causalAgent}</strong>
                  </p>
                </div>

                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs space-y-1 text-slate-300">
                  <span className="text-[10px] font-bold text-slate-400 uppercase block">Typical Field Symptoms:</span>
                  <ul className="list-disc list-inside space-y-0.5 text-slate-300">
                    {cls.typicalFieldSymptoms.map((sym, sIdx) => (
                      <li key={sIdx} className="leading-relaxed text-[11px]">{sym}</li>
                    ))}
                  </ul>
                </div>

                <div className="text-[11px] text-slate-400 space-y-1 pt-2 border-t border-slate-800">
                  <p>
                    <strong className="text-slate-300">Reference Source:</strong> {cls.primaryDatasetSource}
                  </p>
                  <p className="text-emerald-300">
                    <strong className="text-emerald-400">CIBRC Dosage Standard:</strong> {cls.cibrcDosageNote}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 3: Ethical AI & Legal Compliance */}
      {activeTab === "ETHICS" && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6">
          <div className="flex items-center gap-3">
            <Scale className="w-6 h-6 text-emerald-400" />
            <h3 className="text-lg sm:text-xl font-bold text-white font-['Outfit',sans-serif]">
              Ethical AI Principles & Government Disclaimer
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-slate-300 leading-relaxed">
            <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2">
              <span className="text-emerald-300 font-bold text-sm flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                Farmer Data Sovereignty
              </span>
              <p>
                All photographs uploaded by farmers are processed ephemerally for leaf screening. GPS coordinates, when provided, are aggregated to Gram Panchayat block boundaries for Community Outbreak Alerts without revealing private farm boundaries.
              </p>
            </div>

            <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2">
              <span className="text-emerald-300 font-bold text-sm flex items-center gap-1.5">
                <FileCheck className="w-4 h-4 text-emerald-400" />
                CIBRC / Statutory Chemical Compliance
              </span>
              <p>
                AgroVision AI strictly recommends active chemical formulations approved by the Central Insecticides Board & Registration Committee (CIBRC), Ministry of Agriculture & Farmers Welfare. Banned organochlorines and unauthorized synthetic pyrethroids are barred from advisories.
              </p>
            </div>

            <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2">
              <span className="text-emerald-300 font-bold text-sm flex items-center gap-1.5">
                <Award className="w-4 h-4 text-emerald-400" />
                Advisory vs Certified Diagnosis
              </span>
              <p>
                AgroVision AI is an AI-assisted decision support system for early warning and preliminary field scouting. It is not a legally certified diagnostic laboratory. Farmers facing severe or quarantine infections are instructed to contact their district KVK agronomist.
              </p>
            </div>

            <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2">
              <span className="text-emerald-300 font-bold text-sm flex items-center gap-1.5">
                <BookOpen className="w-4 h-4 text-emerald-400" />
                Open Access Attribution
              </span>
              <p>
                Datasets and reference guidelines used by this platform are governed under Creative Commons CC BY 4.0 or Government Open Data licenses. AgroVision AI does not sell or monopolize open agricultural research data.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
