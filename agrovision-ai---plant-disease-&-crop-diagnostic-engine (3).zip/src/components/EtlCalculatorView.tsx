import React, { useState } from "react";
import { ETL_CONFIGS, EtlCropConfig } from "../data/communityAndEtlData";
import { 
  Calculator, 
  TrendingDown, 
  ShieldCheck, 
  AlertTriangle, 
  IndianRupee, 
  Sparkles, 
  CheckCircle2, 
  Leaf, 
  Info, 
  Percent, 
  ChevronRight,
  Droplets
} from "lucide-react";

export const EtlCalculatorView: React.FC = () => {
  const [selectedConfigId, setSelectedConfigId] = useState<string>("cotton_pbw");
  const [pestCount, setPestCount] = useState<number>(1);
  const [acreage, setAcreage] = useState<number>(3);

  const currentConfig: EtlCropConfig =
    ETL_CONFIGS.find((c) => c.id === selectedConfigId) || ETL_CONFIGS[0];

  const isAboveEtl = pestCount >= currentConfig.etlThresholdValue;

  // Financial calculations
  const totalCropValue = currentConfig.avgCropValuePerAcre * acreage;
  const unitsAbove = Math.max(0, pestCount - currentConfig.etlThresholdValue + 1);
  const estimatedYieldLossPct = isAboveEtl
    ? Math.min(65, Math.round(unitsAbove * currentConfig.standardYieldLossPerUnit))
    : 0;
  const estimatedFinancialLoss = Math.round((totalCropValue * estimatedYieldLossPct) / 100);

  // Financial savings when avoiding premature chemical spray (Below ETL)
  const chemicalSprayCostPerAcre = currentConfig.chemicalControl.costPerAcre;
  const biologicalCostPerAcre = currentConfig.biologicalControl.costPerAcre;
  const savingsPerAcre = chemicalSprayCostPerAcre - biologicalCostPerAcre;
  const totalFarmSavings = savingsPerAcre * acreage;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-br from-emerald-950/90 via-slate-900 to-emerald-950/80 border border-emerald-800/60 rounded-3xl p-6 sm:p-8 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="px-3 py-1 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded-full text-xs font-bold flex items-center gap-1.5">
                <Calculator className="w-3.5 h-3.5 text-emerald-400" />
                ICAR & CPCB Certified Decision Engine
              </span>
              <span className="px-2.5 py-0.5 bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded-full text-xs font-semibold">
                Financial Savings & Yield Protection
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              Economic Threshold Level (ETL) & Cost Calculator
            </h2>
            <p className="text-sm text-slate-300 max-w-2xl leading-relaxed">
              Prevents unnecessary chemical expenditure. Input live field pest sample counts to compute whether the crop has crossed official ICAR Economic Threshold Levels (ETL), saving thousands per acre in premature sprays.
            </p>
          </div>

          <div className="flex items-center gap-3 bg-slate-900/80 border border-slate-700/80 p-3.5 rounded-2xl shrink-0">
            <div className="p-2.5 bg-emerald-500/20 rounded-xl border border-emerald-500/30 text-emerald-400">
              <IndianRupee className="w-6 h-6" />
            </div>
            <div>
              <p className="text-xs text-slate-400 font-medium">Potential Spray Savings</p>
              <p className="text-xl font-extrabold text-emerald-300">
                ₹{savingsPerAcre.toLocaleString()}/acre
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Input Form & Crop Selector */}
        <div className="lg:col-span-6 space-y-6">
          {/* Crop Selector Card */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Leaf className="w-4 h-4 text-emerald-400" />
              1. Select Crop & Target Pest
            </h3>

            <div className="grid grid-cols-2 gap-2.5">
              {ETL_CONFIGS.map((cfg) => (
                <button
                  key={cfg.id}
                  onClick={() => {
                    setSelectedConfigId(cfg.id);
                    setPestCount(cfg.defaultVal);
                  }}
                  className={`p-3 rounded-xl text-left border transition-all ${
                    selectedConfigId === cfg.id
                      ? "bg-emerald-950/80 border-emerald-500 ring-2 ring-emerald-500/30 text-white shadow"
                      : "bg-slate-950/60 border-slate-800 hover:border-slate-700 text-slate-300"
                  }`}
                >
                  <p className="text-xs font-bold truncate">{cfg.cropName}</p>
                  <p className="text-[11px] text-emerald-400 truncate mt-0.5">{cfg.pestName.split("(")[0]}</p>
                  <p className="text-[10px] text-slate-400 mt-1">ETL: {cfg.etlThresholdValue} {cfg.unitLabel}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Pest Count Slider & Acreage */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-5">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Calculator className="w-4 h-4 text-emerald-400" />
                2. Field Sampling Count
              </h3>
              <span className="text-xs font-mono px-2 py-0.5 bg-slate-800 text-slate-300 rounded border border-slate-700">
                ICAR Protocol
              </span>
            </div>

            {/* Prompt description */}
            <div className="p-3 bg-slate-950/80 rounded-xl border border-slate-800 text-xs text-slate-300 leading-relaxed">
              <strong className="text-emerald-400 block mb-1">Sampling Instruction:</strong>
              {currentConfig.samplingPrompt}
            </div>

            {/* Slider */}
            <div className="space-y-2">
              <div className="flex justify-between items-baseline">
                <span className="text-xs text-slate-300">Observed Pest Count:</span>
                <span className="text-2xl font-black font-mono text-emerald-400">
                  {pestCount} <span className="text-xs font-normal text-slate-400">{currentConfig.unitLabel}</span>
                </span>
              </div>
              <input
                type="range"
                min={currentConfig.minVal}
                max={currentConfig.maxVal}
                step="1"
                value={pestCount}
                onChange={(e) => setPestCount(Number(e.target.value))}
                className="w-full accent-emerald-500 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-400">
                <span>0 (Clean)</span>
                <span className="text-amber-400 font-bold">ETL Threshold: {currentConfig.etlThresholdValue}</span>
                <span>{currentConfig.maxVal} (Severe)</span>
              </div>
            </div>

            {/* Farm Acreage input */}
            <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
              <div>
                <label className="text-xs font-bold text-slate-300 block">Total Cultivated Farm Area:</label>
                <span className="text-[11px] text-slate-400">Used for aggregate financial savings estimate</span>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  min="1"
                  max="100"
                  value={acreage}
                  onChange={(e) => setAcreage(Math.max(1, Number(e.target.value)))}
                  className="w-20 px-3 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-sm font-bold text-right text-emerald-400 focus:ring-2 focus:ring-emerald-500"
                />
                <span className="text-xs text-slate-400">Acres</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Dynamic ETL Evaluation & Action Trigger */}
        <div className="lg:col-span-6 space-y-6">
          {/* Status Verdict Card */}
          <div
            className={`rounded-2xl p-6 border shadow-xl transition-all ${
              isAboveEtl
                ? "bg-rose-950/70 border-rose-600/80 shadow-rose-950/40"
                : "bg-emerald-950/70 border-emerald-600/80 shadow-emerald-950/40"
            }`}
          >
            <div className="flex items-start justify-between gap-4">
              <div className="space-y-1">
                <span
                  className={`text-xs px-2.5 py-0.5 rounded-full font-bold uppercase tracking-wider ${
                    isAboveEtl
                      ? "bg-rose-500/20 text-rose-300 border border-rose-500/40"
                      : "bg-emerald-500/20 text-emerald-300 border border-emerald-500/40"
                  }`}
                >
                  {isAboveEtl ? "⚠️ CRITICAL: ETL EXCEEDED" : "✅ BELOW ECONOMIC THRESHOLD"}
                </span>
                <h3 className="text-xl font-extrabold text-white pt-1">
                  {isAboveEtl
                    ? "Urgent Targeted Intervention Required"
                    : "Do NOT Spray Chemical Pesticides Yet"}
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {currentConfig.etlThresholdDescription}
                </p>
              </div>

              <div
                className={`p-3 rounded-2xl border shrink-0 ${
                  isAboveEtl
                    ? "bg-rose-500/20 border-rose-500/40 text-rose-400"
                    : "bg-emerald-500/20 border-emerald-500/40 text-emerald-400"
                }`}
              >
                {isAboveEtl ? <AlertTriangle className="w-8 h-8" /> : <ShieldCheck className="w-8 h-8" />}
              </div>
            </div>

            {/* Financial comparison stats */}
            <div className="grid grid-cols-2 gap-3 mt-5 pt-4 border-t border-slate-700/60">
              <div className="p-3 bg-black/40 rounded-xl border border-slate-700/50">
                <span className="text-[10px] text-slate-400 uppercase font-semibold block">
                  {isAboveEtl ? "Estimated Yield Risk" : "Premature Spray Savings"}
                </span>
                <span className={`text-lg font-black ${isAboveEtl ? "text-rose-400" : "text-emerald-400"}`}>
                  {isAboveEtl ? `${estimatedYieldLossPct}% Potential Loss` : `₹${totalFarmSavings.toLocaleString()} Saved`}
                </span>
                <span className="text-[10px] text-slate-400 block mt-0.5">
                  {isAboveEtl ? `~₹${estimatedFinancialLoss.toLocaleString()} at risk on ${acreage} acres` : `For your ${acreage}-acre field`}
                </span>
              </div>

              <div className="p-3 bg-black/40 rounded-xl border border-slate-700/50">
                <span className="text-[10px] text-slate-400 uppercase font-semibold block">
                  Prescribed Strategy
                </span>
                <span className="text-sm font-bold text-white block mt-1">
                  {isAboveEtl ? "Chemical Knockdown" : "Biological / Cultural"}
                </span>
                <span className="text-[10px] text-slate-400 block mt-0.5">
                  {isAboveEtl ? `PHI: ${currentConfig.chemicalControl.waitingPeriodDays} days` : "Zero chemical residue"}
                </span>
              </div>
            </div>
          </div>

          {/* Action Recommendation Card */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-4">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-400" />
              Prescribed Action & CIBRC Safe Dosage
            </h4>

            {isAboveEtl ? (
              <div className="space-y-3">
                <div className="p-3.5 bg-rose-950/40 rounded-xl border border-rose-800/60 text-xs space-y-2">
                  <div className="flex justify-between items-start">
                    <strong className="text-rose-300 text-sm">
                      {currentConfig.chemicalControl.name}
                    </strong>
                    <span className="px-2 py-0.5 bg-rose-900 text-rose-200 rounded text-[10px] font-bold">
                      Cost: ₹{currentConfig.chemicalControl.costPerAcre}/acre
                    </span>
                  </div>
                  <p className="text-slate-200">
                    <strong>Dosage & Dilution:</strong> {currentConfig.chemicalControl.dosage}
                  </p>
                  <p className="text-slate-400 text-[11px]">
                    <strong>Active Compound:</strong> {currentConfig.chemicalControl.activeIngredient}
                  </p>
                  <p className="text-[10px] text-slate-400 font-mono">
                    CIBRC Reg: {currentConfig.chemicalControl.cibrcReg}
                  </p>
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="p-3.5 bg-emerald-950/40 rounded-xl border border-emerald-800/60 text-xs space-y-2">
                  <div className="flex justify-between items-start">
                    <strong className="text-emerald-300 text-sm">
                      {currentConfig.biologicalControl.name}
                    </strong>
                    <span className="px-2 py-0.5 bg-emerald-900 text-emerald-200 rounded text-[10px] font-bold">
                      Cost: ₹{currentConfig.biologicalControl.costPerAcre}/acre
                    </span>
                  </div>
                  <p className="text-slate-200">
                    <strong>Application:</strong> {currentConfig.biologicalControl.dosage}
                  </p>
                  <p className="text-emerald-400 font-semibold text-[11px]">
                    💡 Financial Benefit: You save ₹{savingsPerAcre}/acre by allowing natural predators & bio-inputs to suppress pest resurgence without destroying beneficial pollinators.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
