import React, { useState } from "react";
import { INITIAL_COMMUNITY_INCIDENTS, CommunityIncident } from "../data/communityAndEtlData";
import { 
  Users, 
  Radio, 
  Send, 
  MapPin, 
  ShieldAlert, 
  CheckCircle2, 
  AlertTriangle, 
  Phone, 
  Share2, 
  Clock, 
  Plus, 
  MessageSquare, 
  Sliders, 
  Check, 
  Bell,
  Sparkles,
  ExternalLink,
  Copy,
  Settings
} from "lucide-react";

export const CommunityAlertsView: React.FC = () => {
  const [incidents, setIncidents] = useState<CommunityIncident[]>(INITIAL_COMMUNITY_INCIDENTS);
  const [radiusKm, setRadiusKm] = useState<number>(5);
  const [selectedDistrict, setSelectedDistrict] = useState<string>("All Districts");
  const [broadcastStatus, setBroadcastStatus] = useState<"idle" | "broadcasting" | "sent">("idle");
  const [lastBroadcastMessage, setLastBroadcastMessage] = useState<string | null>(null);
  const [copiedMessage, setCopiedMessage] = useState<boolean>(false);
  const [showGatewaySettings, setShowGatewaySettings] = useState<boolean>(false);
  const [gatewayMode, setGatewayMode] = useState<"whatsapp" | "webhook">("whatsapp");
  const [webhookUrl, setWebhookUrl] = useState<string>("https://api.twilio.com/2010-04-01/Accounts/AC_DEMO/Messages.json");
  const [broadcastLog, setBroadcastLog] = useState<Array<{ time: string; text: string; recipients: number }>>([
    {
      time: "Today, 10:15 AM",
      text: "गुलाबी बोंड अळी सावधगिरी सूचना (Yavatmal District - Babhulgaon 5km cluster). 48 शेतकऱ्यांना WhatsApp संदेश वितरित.",
      recipients: 48,
    },
  ]);

  // Farmer Community verification "+1 Me Too"
  const handleVerifyIncident = (id: string) => {
    setIncidents((prev) =>
      prev.map((inc) => {
        if (inc.id === id) {
          const already = inc.hasUserVerified;
          const newCount = already ? inc.verificationsCount - 1 : inc.verificationsCount + 1;
          const shouldTriggerAlert = newCount >= 3;
          return {
            ...inc,
            verificationsCount: newCount,
            hasUserVerified: !already,
            alertTriggered: shouldTriggerAlert,
          };
        }
        return inc;
      })
    );
  };

  // Direct 1-Click WhatsApp group / contact broadcast
  const handleShareToWhatsApp = (text: string) => {
    const encoded = encodeURIComponent(text);
    window.open(`https://api.whatsapp.com/send?text=${encoded}`, "_blank", "noopener,noreferrer");
  };

  const handleCopyMessage = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedMessage(true);
    setTimeout(() => setCopiedMessage(false), 2500);
  };

  // Trigger automated broadcast via Twilio / WhatsApp Business API
  const handleTriggerBroadcast = (incident: CommunityIncident) => {
    setBroadcastStatus("broadcasting");
    const marathiMsg = `🚨 कृषी विभाग महाराष्ट्र - तत्काळ सतर्कता इशारा! तुमच्या परिसरातील (५ किमी परिघात) ${incident.village} येथे ३ पेक्षा अधिक शेतात ${incident.marathiName} आढळली आहे. शेतात त्वरित कामगंध सापळे तपासा आणि एकात्मिक कीड नियंत्रण (IPM) उपाय करा. मदत: 1800-180-1551`;
    setLastBroadcastMessage(marathiMsg);

    // If webhook mode is active, simulate or dispatch to webhook
    if (gatewayMode === "webhook" && webhookUrl) {
      console.log(`[SMS Gateway] Dispatched to webhook ${webhookUrl}:`, {
        village: incident.village,
        crop: incident.crop,
        disease: incident.marathiName,
        message: marathiMsg,
      });
    }

    setTimeout(() => {
      setBroadcastStatus("sent");
      setBroadcastLog((prev) => [
        {
          time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
          text: `WhatsApp/SMS Broadcast dispatched to ${incident.village} (${incident.gramPanchayat}) Cluster. 52 local farmers alerted via ${gatewayMode === "whatsapp" ? "WhatsApp Gateway" : "CDAC/Twilio Webhook"}.`,
          recipients: 52,
        },
        ...prev,
      ]);
      setTimeout(() => setBroadcastStatus("idle"), 4000);
    }, 1200);
  };

  const filteredIncidents = incidents.filter((inc) => {
    if (selectedDistrict === "All Districts") return true;
    return inc.district === selectedDistrict;
  });

  const highOutbreakIncidents = incidents.filter((i) => i.alertTriggered || i.verificationsCount >= 3);

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-br from-emerald-950/90 via-slate-900 to-emerald-950/80 border border-emerald-800/60 rounded-3xl p-6 sm:p-8 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="px-3 py-1 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded-full text-xs font-bold flex items-center gap-1.5">
                <Radio className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
                SIH26131 Community Protection Engine
              </span>
              <span className="px-2.5 py-0.5 bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded-full text-xs font-semibold">
                Demo Spatial Broadcast Simulation
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              Smart Community Alert & Geo-Radius Broadcasting
            </h2>
            <p className="text-sm text-slate-300 max-w-2xl leading-relaxed">
              Spatial pest outbreak containment network. When 3 or more farms confirm a critical pathogen within 5 km, automated village outbreak alerts and localized WhatsApp/SMS advisories are simulated for surrounding farmers.
            </p>
          </div>

          <div className="flex items-center gap-3 bg-slate-900/80 border border-slate-700/80 p-3.5 rounded-2xl shrink-0">
            <div className="p-2.5 bg-rose-500/20 rounded-xl border border-rose-500/30 text-rose-400">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <div>
              <p className="text-xs text-slate-400 font-medium">Active Outbreak Clusters</p>
              <p className="text-xl font-extrabold text-rose-300">
                {highOutbreakIncidents.length} Villages Flagged
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Grid: Left column (Broadcast Control & WhatsApp simulation) / Right column (Community Feed) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Automated 5km Radius Broadcast Hub */}
        <div className="lg:col-span-5 space-y-6">
          {/* Geo-Radius Controller */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Radio className="w-4 h-4 text-emerald-400" />
                Geo-Radius Alert Parameters
              </h3>
              <span className="text-xs font-mono px-2 py-0.5 bg-emerald-500/20 text-emerald-300 rounded border border-emerald-500/30">
                Auto-Trigger: ≥3 Farms
              </span>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-xs text-slate-300">
                <span>Broadcast Buffer Radius:</span>
                <span className="font-bold text-emerald-400">{radiusKm} Kilometers</span>
              </div>
              <input
                type="range"
                min="2"
                max="15"
                step="1"
                value={radiusKm}
                onChange={(e) => setRadiusKm(Number(e.target.value))}
                className="w-full accent-emerald-500 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-400">
                <span>2 km (Hamlet)</span>
                <span>5 km (Standard Gram Panchayat)</span>
                <span>15 km (Taluka Hub)</span>
              </div>
            </div>

            <div className="p-3.5 bg-slate-950/80 rounded-xl border border-slate-800 space-y-2 text-xs">
              <p className="font-semibold text-slate-200 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                Automated Gateway Integration
              </p>
              <div className="grid grid-cols-2 gap-2 text-[11px]">
                <div className="p-2 bg-slate-900 rounded border border-slate-800 text-slate-300">
                  <span className="text-slate-400 block text-[10px]">Primary Channel:</span>
                  <span className="font-bold text-emerald-300 flex items-center gap-1">
                    <MessageSquare className="w-3 h-3" /> WhatsApp Business API
                  </span>
                </div>
                <div className="p-2 bg-slate-900 rounded border border-slate-800 text-slate-300">
                  <span className="text-slate-400 block text-[10px]">Offline Fallback:</span>
                  <span className="font-bold text-amber-300 flex items-center gap-1">
                    <Phone className="w-3 h-3" /> Twilio / CDAC SMS
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Active Broadcast Preview (WhatsApp Mockup) */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-emerald-400" />
                Demo Spatial Broadcast Simulation
              </h3>
              <span className="text-[11px] text-amber-400 font-medium">Simulated Gateway Log</span>
            </div>

            <div className="bg-[#0b141a] rounded-xl p-4 border border-[#202c33] text-xs font-sans space-y-3 relative shadow-inner">
              <div className="flex items-center gap-2 border-b border-[#202c33] pb-2 text-slate-300">
                <div className="w-7 h-7 rounded-full bg-emerald-700 flex items-center justify-center font-bold text-white text-xs">
                  MH
                </div>
                <div>
                  <p className="font-bold text-slate-100 text-[11px]">MahaAgri Alert (Official)</p>
                  <p className="text-[10px] text-emerald-400">Verified Broadcast Channel (Simulated)</p>
                </div>
              </div>

              <div className="bg-[#1f2c34] p-3 rounded-xl rounded-tl-none text-slate-100 space-y-2 max-w-sm ml-2 border border-[#2a3942]">
                <p className="font-bold text-rose-400 flex items-center gap-1">
                  🚨 तत्काळ पीक संरक्षण इशारा!
                </p>
                <p className="text-[11px] leading-relaxed text-slate-200">
                  तुमच्या परिसरातील (५ किमी परिघात) <strong>बाभूळगाव ग्रामपंचायत</strong> येथे ३ पेक्षा अधिक शेतांमध्ये <strong>गुलाबी बोंड अळी (Pink Bollworm)</strong> चा प्रादुर्भाव निष्पन्न झाला आहे.
                </p>
                <div className="p-2 bg-black/30 rounded border border-slate-700/50 text-[10px] space-y-1">
                  <p className="font-semibold text-emerald-300">तातडीने करायचे उपाय (IPM):</p>
                  <p>• एकरी २ ते ४ कामगंध सापळे त्वरित लावा.</p>
                  <p>• प्रादुर्भाव जास्त असल्यास निंबोळी अर्क ५% किंवा ट्रायकोकार्ड वापरा.</p>
                </div>
                <p className="text-[9px] text-slate-400 text-right">10:15 AM ✓✓</p>
              </div>

              {broadcastStatus === "broadcasting" && (
                <div className="p-3 bg-emerald-950/90 border border-emerald-700 rounded-xl text-center space-y-1">
                  <p className="text-xs font-bold text-emerald-300 flex items-center justify-center gap-2">
                    <Radio className="w-4 h-4 animate-spin" />
                    Simulating Spatial Broadcast Dispatch to 48 Farmers...
                  </p>
                </div>
              )}

              {broadcastStatus === "sent" && (
                <div className="p-3 bg-emerald-900/90 border border-emerald-600 rounded-xl text-center space-y-1 animate-fade-in">
                  <p className="text-xs font-bold text-emerald-200 flex items-center justify-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    Demo Spatial Broadcast Simulation Dispatched (52 Farmers in Cluster Log)
                  </p>
                </div>
              )}

              {/* Real Action Buttons for WhatsApp / SMS Gateway */}
              <div className="pt-2 border-t border-[#202c33] flex items-center justify-between gap-2 flex-wrap">
                <button
                  type="button"
                  onClick={() => handleShareToWhatsApp(
                    lastBroadcastMessage || "🚨 कृषी विभाग महाराष्ट्र: बाभूळगाव येथे गुलाबी बोंड अळी सावधगिरी इशारा! शेतात त्वरित कामगंध सापळे तपासा."
                  )}
                  className="px-3 py-1.5 bg-[#25D366] hover:bg-[#20ba59] text-black font-bold rounded-lg text-xs flex items-center gap-1.5 shadow transition"
                  title="Open in WhatsApp Web / App"
                >
                  <MessageSquare className="w-3.5 h-3.5 fill-black" />
                  Forward to Village WhatsApp Group
                  <ExternalLink className="w-3 h-3 ml-0.5" />
                </button>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => handleCopyMessage(
                      lastBroadcastMessage || "🚨 कृषी विभाग महाराष्ट्र: बाभूळगाव येथे गुलाबी बोंड अळी सावधगिरी इशारा! शेतात त्वरित कामगंध सापळे तपासा."
                    )}
                    className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold flex items-center gap-1 border border-slate-700 transition"
                  >
                    {copiedMessage ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    {copiedMessage ? "Copied!" : "Copy Text"}
                  </button>

                  <button
                    type="button"
                    onClick={() => setShowGatewaySettings(!showGatewaySettings)}
                    className="p-1.5 text-slate-400 hover:text-emerald-400 hover:bg-slate-800 rounded-lg transition border border-transparent hover:border-slate-700"
                    title="Configure SMS/WhatsApp Gateway Webhook"
                  >
                    <Settings className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Gateway Configuration Drawer */}
              {showGatewaySettings && (
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-700 space-y-2.5 text-xs animate-in fade-in duration-150">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-white flex items-center gap-1.5">
                      <Settings className="w-3.5 h-3.5 text-emerald-400" />
                      Government & Enterprise Dispatch Gateway
                    </span>
                    <span className="text-[10px] text-emerald-400 font-mono">Status: Active</span>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setGatewayMode("whatsapp")}
                      className={`p-2 rounded-lg border text-left transition ${
                        gatewayMode === "whatsapp"
                          ? "bg-emerald-950 border-emerald-500 text-emerald-200"
                          : "bg-slate-900 border-slate-800 text-slate-400"
                      }`}
                    >
                      <p className="font-bold text-[11px]">WhatsApp Business API</p>
                      <p className="text-[9px] text-slate-500">Free Village Group Blast</p>
                    </button>
                    <button
                      type="button"
                      onClick={() => setGatewayMode("webhook")}
                      className={`p-2 rounded-lg border text-left transition ${
                        gatewayMode === "webhook"
                          ? "bg-emerald-950 border-emerald-500 text-emerald-200"
                          : "bg-slate-900 border-slate-800 text-slate-400"
                      }`}
                    >
                      <p className="font-bold text-[11px]">CDAC Kisan SMS / Twilio</p>
                      <p className="text-[9px] text-slate-500">Enterprise REST Webhook</p>
                    </button>
                  </div>

                  {gatewayMode === "webhook" && (
                    <div className="space-y-1">
                      <label className="text-[10px] text-slate-400 font-mono">Webhook Endpoint URL:</label>
                      <input
                        type="url"
                        value={webhookUrl}
                        onChange={(e) => setWebhookUrl(e.target.value)}
                        className="w-full px-2.5 py-1 bg-slate-900 border border-slate-700 rounded text-slate-200 text-xs font-mono"
                        placeholder="https://your-webhook-endpoint.com/sms"
                      />
                      <span className="text-[9px] text-slate-500 block">Payload will be dispatched via POST JSON to this endpoint on 5km cluster trigger.</span>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Broadcast Dispatch History Log */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-3">
            <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-emerald-400" />
              Recent Broadcast Transmissions
            </h4>
            <div className="space-y-2">
              {broadcastLog.map((log, idx) => (
                <div key={idx} className="p-2.5 bg-slate-950/80 rounded-xl border border-slate-800/80 text-xs space-y-1">
                  <div className="flex justify-between text-slate-400 text-[10px]">
                    <span>{log.time}</span>
                    <span className="text-emerald-400 font-bold">{log.recipients} Farmers Alerted</span>
                  </div>
                  <p className="text-slate-300 text-[11px]">{log.text}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Farmer Community Feed & Crowdsourced Verifications */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Users className="w-4 h-4 text-emerald-400" />
                  Gram Panchayat Community Feed
                </h3>
                <p className="text-xs text-slate-400">
                  Real-time crowdsourced field reports across Maharashtra talukas.
                </p>
              </div>

              {/* District Filter */}
              <select
                value={selectedDistrict}
                onChange={(e) => setSelectedDistrict(e.target.value)}
                className="px-3 py-1.5 bg-slate-800 border border-slate-700 rounded-lg text-xs font-semibold text-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              >
                <option value="All Districts">All Districts</option>
                <option value="Yavatmal">Yavatmal (विदर्भ)</option>
                <option value="Latur">Latur (मराठवाडा)</option>
                <option value="Kolhapur">Kolhapur (पश्चिम महाराष्ट्र)</option>
                <option value="Bhandara">Bhandara (पूर्व विदर्भ)</option>
                <option value="Nashik">Nashik (उत्तर महाराष्ट्र)</option>
              </select>
            </div>

            {/* Incidents List */}
            <div className="space-y-3.5">
              {filteredIncidents.map((incident) => {
                const isTriggered = incident.verificationsCount >= 3;
                return (
                  <div
                    key={incident.id}
                    className={`p-4 rounded-xl border transition-all ${
                      isTriggered
                        ? "bg-slate-950/90 border-rose-600/80 shadow-rose-950/30 shadow-lg"
                        : "bg-slate-950/60 border-slate-800 hover:border-slate-700"
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-start gap-3">
                        <img
                          src={incident.imageUrl}
                          alt={incident.crop}
                          className="w-16 h-16 rounded-lg object-cover border border-slate-700 shrink-0"
                        />
                        <div className="space-y-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-xs font-bold text-white">
                              {incident.crop}
                            </span>
                            <span
                              className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                                incident.severity === "Critical"
                                  ? "bg-rose-500/20 text-rose-300 border border-rose-500/40"
                                  : "bg-amber-500/20 text-amber-300 border border-amber-500/40"
                              }`}
                            >
                              {incident.severity} Severity
                            </span>
                            {isTriggered && (
                              <span className="text-[10px] px-2 py-0.5 rounded-full font-extrabold bg-rose-600 text-white flex items-center gap-1 animate-pulse">
                                <AlertTriangle className="w-3 h-3" />
                                5km Cluster Alert
                              </span>
                            )}
                          </div>

                          <p className="text-sm font-semibold text-emerald-400">
                            {incident.diseaseOrPest}
                          </p>
                          <p className="text-xs text-slate-300 font-medium">
                            {incident.marathiName}
                          </p>

                          <div className="flex items-center gap-3 text-[11px] text-slate-400 flex-wrap pt-0.5">
                            <span className="flex items-center gap-1 text-slate-300">
                              <MapPin className="w-3 h-3 text-rose-400" />
                              {incident.village}, {incident.taluka} ({incident.district})
                            </span>
                            <span>•</span>
                            <span className="text-slate-400">Reported {incident.reportedAgo}</span>
                            <span>•</span>
                            <span className="text-slate-400">By {incident.farmerName}</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Bottom verification action row */}
                    <div className="mt-3 pt-3 border-t border-slate-800/80 flex items-center justify-between flex-wrap gap-2">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleVerifyIncident(incident.id)}
                          className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition ${
                            incident.hasUserVerified
                              ? "bg-emerald-600 text-white shadow-emerald-900/40 shadow"
                              : "bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700"
                          }`}
                        >
                          <Check className="w-3.5 h-3.5" />
                          {incident.hasUserVerified ? "Verified (+1 Counted)" : "I am seeing this too"}
                        </button>
                        <span className="text-xs text-slate-400 font-medium">
                          <strong className="text-emerald-400 font-extrabold">
                            {incident.verificationsCount}
                          </strong>{" "}
                          farmers confirmed
                        </span>
                      </div>

                      <div className="flex items-center gap-2 flex-wrap">
                        <button
                          type="button"
                          onClick={() => handleShareToWhatsApp(
                            `🚨 कृषी सतर्कता: ${incident.village} (${incident.gramPanchayat}) येथे ${incident.crop} पिकावर ${incident.marathiName} आढळली आहे. त्वरित शेत तपासा!`
                          )}
                          className="px-2.5 py-1.5 bg-[#25D366]/20 hover:bg-[#25D366]/30 text-[#25D366] border border-[#25D366]/40 rounded-lg text-xs font-bold flex items-center gap-1 transition"
                          title="Share to WhatsApp Group"
                        >
                          <MessageSquare className="w-3.5 h-3.5" />
                          WhatsApp
                        </button>

                        {isTriggered && (
                          <button
                            onClick={() => handleTriggerBroadcast(incident)}
                            className="px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow transition"
                          >
                            <Radio className="w-3.5 h-3.5" />
                            Broadcast 5km Alert Now
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
