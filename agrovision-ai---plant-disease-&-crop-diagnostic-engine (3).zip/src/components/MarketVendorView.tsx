import React, { useState } from "react";
import { 
  MAHA_KRISHI_STORES, 
  SAMPLE_PESTICIDE_QR_DATABASE, 
  KrishiSevaKendraStore, 
  PesticideQrBatch 
} from "../data/communityAndEtlData";
import { 
  Store, 
  QrCode, 
  ShieldCheck, 
  AlertTriangle, 
  MapPin, 
  Phone, 
  Search, 
  CheckCircle2, 
  ExternalLink, 
  BadgePercent, 
  Camera, 
  FileText, 
  RefreshCw,
  Sparkles,
  Navigation,
  Map,
  List,
  Clock
} from "lucide-react";

export const MarketVendorView: React.FC = () => {
  // Store Locator State
  const [selectedDistrict, setSelectedDistrict] = useState<string>("All");
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [filterType, setFilterType] = useState<string>("All");
  const [viewMode, setViewMode] = useState<"list" | "map">("list");
  const [selectedMapStore, setSelectedMapStore] = useState<KrishiSevaKendraStore | null>(MAHA_KRISHI_STORES[0]);

  // QR Code Scanner State
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [selectedBatch, setSelectedBatch] = useState<PesticideQrBatch>(SAMPLE_PESTICIDE_QR_DATABASE[0]);
  const [reportedCount, setReportedCount] = useState<number>(0);
  const [reportSuccess, setReportSuccess] = useState<boolean>(false);

  // Filtered stores
  const filteredStores = MAHA_KRISHI_STORES.filter((store) => {
    if (selectedDistrict !== "All" && store.district !== selectedDistrict) return false;
    if (searchTerm.trim() !== "") {
      const q = searchTerm.toLowerCase();
      const matchesStore = store.storeName.toLowerCase().includes(q) || store.taluka.toLowerCase().includes(q);
      const matchesItem = store.stockItems.some((item) => item.itemName.toLowerCase().includes(q));
      if (!matchesStore && !matchesItem) return false;
    }
    if (filterType === "Biological") {
      return store.stockItems.some((item) => item.type === "Biological" || item.type === "Pheromone Trap");
    }
    return true;
  });

  const handleSimulateScan = (batch: PesticideQrBatch) => {
    setIsScanning(true);
    setTimeout(() => {
      setSelectedBatch(batch);
      setIsScanning(false);
      setReportSuccess(false);
    }, 600);
  };

  const handleReportCounterfeit = () => {
    setReportedCount((prev) => prev + 1);
    setReportSuccess(true);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-br from-emerald-950/90 via-slate-900 to-emerald-950/80 border border-emerald-800/60 rounded-3xl p-6 sm:p-8 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="px-3 py-1 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded-full text-xs font-bold flex items-center gap-1.5">
                <Store className="w-3.5 h-3.5 text-emerald-400" />
                MahaAgri Authorized Market & Quality Assurance
              </span>
              <span className="px-2.5 py-0.5 bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded-full text-xs font-semibold">
                CIBRC Anti-Counterfeit Database
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              Smart Market & Input Vendor Integration
            </h2>
            <p className="text-sm text-slate-300 max-w-2xl leading-relaxed">
              Connects farmers directly with genuine biological controls and certified inputs. Verify pesticide authenticity using the CIBRC QR Code Scanner before purchasing to stop fake chemicals in rural Maharashtra.
            </p>
          </div>

          <div className="flex items-center gap-3 bg-slate-900/80 border border-slate-700/80 p-3.5 rounded-2xl shrink-0">
            <div className="p-2.5 bg-emerald-500/20 rounded-xl border border-emerald-500/30 text-emerald-400">
              <QrCode className="w-6 h-6" />
            </div>
            <div>
              <p className="text-xs text-slate-400 font-medium">Verified MahaAgri Kendras</p>
              <p className="text-xl font-extrabold text-emerald-300">
                100% Authorized
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Grid: Section 1: Fake Pesticide QR Scanner / Section 2: Store Locator */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Fake Pesticide QR Code Scanner */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <QrCode className="w-4 h-4 text-emerald-400" />
                Pesticide Bottle QR Verifier
              </h3>
              <span className="text-xs font-mono px-2 py-0.5 bg-slate-800 text-slate-300 rounded border border-slate-700">
                CIBRC Live Registry
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Test bottle packaging QR codes against the Central Insecticides Board (CIBRC) & MahaAgri input database:
            </p>

            {/* Interactive Sample QR selector buttons */}
            <div className="space-y-2">
              <span className="text-[11px] text-slate-400 font-semibold block">Select Specimen Batch to Scan:</span>
              <div className="grid grid-cols-2 gap-2">
                {SAMPLE_PESTICIDE_QR_DATABASE.map((b) => (
                  <button
                    key={b.qrCodeId}
                    onClick={() => handleSimulateScan(b)}
                    className={`p-2 rounded-lg text-left border transition text-xs ${
                      selectedBatch.qrCodeId === b.qrCodeId
                        ? "bg-emerald-950 border-emerald-500 text-white"
                        : "bg-slate-950/60 border-slate-800 text-slate-300 hover:border-slate-700"
                    }`}
                  >
                    <p className="font-bold truncate">{b.productName.split(" ")[0]}</p>
                    <span
                      className={`text-[10px] font-bold ${
                        b.status === "GENUINE_CERTIFIED"
                          ? "text-emerald-400"
                          : b.status === "COUNTERFEIT_DETECTED"
                          ? "text-rose-400"
                          : "text-amber-400"
                      }`}
                    >
                      {b.status === "GENUINE_CERTIFIED" ? "✓ Genuine" : b.status === "COUNTERFEIT_DETECTED" ? "✗ Counterfeit" : "⚠️ Expired"}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Scanner Viewport / Verification Card */}
            <div className="relative bg-slate-950 rounded-xl p-4 border border-slate-800 space-y-4">
              {isScanning ? (
                <div className="h-48 flex flex-col items-center justify-center gap-3">
                  <RefreshCw className="w-8 h-8 text-emerald-400 animate-spin" />
                  <p className="text-xs font-semibold text-slate-300">
                    Querying CIBRC National Cryptographic Database...
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {/* Status Banner */}
                  <div
                    className={`p-3 rounded-xl border flex items-start gap-3 ${
                      selectedBatch.status === "GENUINE_CERTIFIED"
                        ? "bg-emerald-950/80 border-emerald-600/80 text-emerald-200"
                        : selectedBatch.status === "COUNTERFEIT_DETECTED"
                        ? "bg-rose-950/90 border-rose-600/90 text-rose-200"
                        : "bg-amber-950/80 border-amber-600/80 text-amber-200"
                    }`}
                  >
                    {selectedBatch.status === "GENUINE_CERTIFIED" ? (
                      <ShieldCheck className="w-6 h-6 text-emerald-400 shrink-0 mt-0.5" />
                    ) : (
                      <AlertTriangle className="w-6 h-6 text-rose-400 shrink-0 mt-0.5" />
                    )}
                    <div className="space-y-1">
                      <p className="font-black text-sm">
                        {selectedBatch.status === "GENUINE_CERTIFIED"
                          ? "GENUINE & CIBRC REGISTERED"
                          : selectedBatch.status === "COUNTERFEIT_DETECTED"
                          ? "CRITICAL: FAKE / UNAPPROVED PESTICIDE"
                          : "EXPIRED CHEMICAL BATCH"}
                      </p>
                      <p className="text-xs leading-relaxed opacity-90">
                        {selectedBatch.status === "GENUINE_CERTIFIED"
                          ? "Official hologram and chemical formula validated by MahaAgri Department."
                          : selectedBatch.flagReason}
                      </p>
                    </div>
                  </div>

                  {/* Batch Details table */}
                  <div className="space-y-1.5 text-xs text-slate-300">
                    <div className="flex justify-between py-1 border-b border-slate-800">
                      <span className="text-slate-400">Product Name:</span>
                      <span className="font-bold text-white">{selectedBatch.productName}</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-800">
                      <span className="text-slate-400">Batch Number:</span>
                      <span className="font-mono text-emerald-400">{selectedBatch.batchNumber}</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-800">
                      <span className="text-slate-400">Mfg / Exp Date:</span>
                      <span>{selectedBatch.manufacturingDate} — {selectedBatch.expiryDate}</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-800">
                      <span className="text-slate-400">CIBRC Reg No:</span>
                      <span className="font-mono text-[11px] truncate max-w-[200px]">{selectedBatch.cibrcRegistrationNumber}</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-800">
                      <span className="text-slate-400">Security Hologram:</span>
                      <span className="font-bold text-emerald-300">
                        {selectedBatch.hologramVerified ? "✓ Verified Cryptographic Seal" : "✗ Missing / Tampered"}
                      </span>
                    </div>
                  </div>

                  {/* Actions */}
                  {selectedBatch.status === "COUNTERFEIT_DETECTED" && (
                    <div className="pt-2">
                      <button
                        onClick={handleReportCounterfeit}
                        className="w-full py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-xs font-bold transition flex items-center justify-center gap-2 shadow"
                      >
                        <AlertTriangle className="w-4 h-4" />
                        Report Counterfeit to District Agriculture Officer (DAO)
                      </button>
                      {reportSuccess && (
                        <p className="text-[11px] text-emerald-400 font-semibold text-center mt-2 animate-fade-in">
                          ✓ Official Complaint #MH-DAO-{Date.now().toString().slice(-4)} logged. Krishi Department enforcement alerted.
                        </p>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right Column: Authorized Bio-Pesticide Store Locator (Krishi Seva Kendra) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Store className="w-4 h-4 text-emerald-400" />
                  MahaAgri Authorized Krishi Seva Kendra Locator
                </h3>
                <p className="text-xs text-slate-400">
                  Find nearest authorized vendors stocking biological controls and subsidized IPM inputs.
                </p>
              </div>

              {/* Controls: Mode Switcher & Filters */}
              <div className="flex items-center gap-2 flex-wrap">
                <div className="flex bg-slate-950 p-0.5 rounded-lg border border-slate-800">
                  <button
                    type="button"
                    onClick={() => setViewMode("list")}
                    className={`px-2.5 py-1 rounded-md text-xs font-bold flex items-center gap-1.5 transition ${
                      viewMode === "list"
                        ? "bg-emerald-600 text-white shadow-sm"
                        : "text-slate-400 hover:text-slate-200"
                    }`}
                  >
                    <List className="w-3.5 h-3.5" />
                    List
                  </button>
                  <button
                    type="button"
                    onClick={() => setViewMode("map")}
                    className={`px-2.5 py-1 rounded-md text-xs font-bold flex items-center gap-1.5 transition ${
                      viewMode === "map"
                        ? "bg-emerald-600 text-white shadow-sm"
                        : "text-slate-400 hover:text-slate-200"
                    }`}
                  >
                    <Map className="w-3.5 h-3.5" />
                    Live Map
                  </button>
                </div>

                <select
                  value={selectedDistrict}
                  onChange={(e) => setSelectedDistrict(e.target.value)}
                  className="px-3 py-1.5 bg-slate-800 border border-slate-700 rounded-lg text-xs font-semibold text-slate-200"
                >
                  <option value="All">All Maharashtra</option>
                  <option value="Yavatmal">Yavatmal</option>
                  <option value="Latur">Latur</option>
                  <option value="Kolhapur">Kolhapur</option>
                  <option value="Nashik">Nashik</option>
                </select>

                <select
                  value={filterType}
                  onChange={(e) => setFilterType(e.target.value)}
                  className="px-3 py-1.5 bg-slate-800 border border-slate-700 rounded-lg text-xs font-semibold text-slate-200"
                >
                  <option value="All">All Inputs</option>
                  <option value="Biological">Bio-Pesticides Only</option>
                </select>
              </div>
            </div>

            {/* Interactive Live Map Mode */}
            {viewMode === "map" && (
              <div className="space-y-3">
                <div className="relative w-full h-80 bg-slate-950 border border-slate-800 rounded-xl overflow-hidden shadow-inner flex flex-col justify-between p-4">
                  {/* Subtle Map Grid Background */}
                  <div className="absolute inset-0 opacity-20 bg-[radial-gradient(#10b981_1px,transparent_1px)] [background-size:16px_16px] pointer-events-none" />
                  
                  {/* Map Header Status */}
                  <div className="relative z-10 flex items-center justify-between bg-slate-900/90 backdrop-blur px-3 py-1.5 rounded-lg border border-slate-800 text-[11px]">
                    <div className="flex items-center gap-2 text-slate-300">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                      <span>Maharashtra State Krishi Seva Kendra Network ({filteredStores.length} Active Nodes)</span>
                    </div>
                    <span className="text-[10px] text-slate-400 font-mono">GPS Ground-Truth Verified</span>
                  </div>

                  {/* Visual Map Pins */}
                  <div className="relative z-10 my-auto grid grid-cols-2 sm:grid-cols-4 gap-3 py-4">
                    {filteredStores.map((store) => {
                      const isSelected = selectedMapStore?.id === store.id;
                      return (
                        <button
                          key={store.id}
                          type="button"
                          onClick={() => setSelectedMapStore(store)}
                          className={`p-3 rounded-xl border text-left transition relative flex flex-col justify-between group ${
                            isSelected
                              ? "bg-emerald-950/90 border-emerald-500 shadow-lg shadow-emerald-950/50 scale-[1.02]"
                              : "bg-slate-900/80 border-slate-800 hover:border-slate-700 hover:bg-slate-800/80"
                          }`}
                        >
                          <div className="flex items-start justify-between">
                            <div className={`p-1.5 rounded-lg ${isSelected ? "bg-emerald-600 text-white" : "bg-slate-800 text-slate-400 group-hover:text-emerald-400"}`}>
                              <MapPin className="w-4 h-4" />
                            </div>
                            <span className="text-[10px] font-mono text-slate-400 bg-slate-950/80 px-1.5 py-0.5 rounded">
                              {store.distanceKm} km
                            </span>
                          </div>
                          <div className="mt-2">
                            <p className={`text-xs font-bold truncate ${isSelected ? "text-emerald-300" : "text-white"}`}>
                              {store.storeName}
                            </p>
                            <p className="text-[10px] text-slate-400 truncate">
                              {store.taluka}, {store.district}
                            </p>
                          </div>
                        </button>
                      );
                    })}
                  </div>

                  {/* Map Footer Instructions */}
                  <div className="relative z-10 flex items-center justify-between text-[11px] text-slate-400 bg-slate-900/90 backdrop-blur px-3 py-1.5 rounded-lg border border-slate-800">
                    <span>Click any store pin above to view live inventory & driving navigation</span>
                    <a
                      href="https://www.google.com/maps/search/Krishi+Seva+Kendra+Maharashtra"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-emerald-400 hover:underline flex items-center gap-1 font-semibold"
                    >
                      Browse All on Google Maps <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                </div>

                {/* Selected Map Store Detail Card */}
                {selectedMapStore && (
                  <div className="p-4 bg-slate-950/90 border border-emerald-500/40 rounded-xl space-y-3 animate-in fade-in duration-200">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="text-sm font-bold text-white">{selectedMapStore.storeName}</h4>
                          <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 rounded-full text-[10px] font-bold">
                            ✓ MahaAgri Licensed
                          </span>
                        </div>
                        <p className="text-xs text-slate-400 flex items-center gap-1 mt-0.5">
                          <MapPin className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                          {selectedMapStore.address}
                        </p>
                        <p className="text-[11px] text-slate-400 flex items-center gap-1 mt-0.5">
                          <Clock className="w-3 h-3 text-slate-500" />
                          {selectedMapStore.operatingHours} • Lat: {selectedMapStore.coordinates.lat}, Lng: {selectedMapStore.coordinates.lng}
                        </p>
                      </div>

                      <div className="flex items-center gap-2">
                        <a
                          href={`https://www.google.com/maps/dir/?api=1&destination=${selectedMapStore.coordinates.lat},${selectedMapStore.coordinates.lng}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="px-3 py-1.5 bg-sky-700 hover:bg-sky-600 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition"
                          title="Open Google Maps Driving Directions"
                        >
                          <Navigation className="w-3.5 h-3.5" />
                          Google Maps Navigation
                        </a>
                        <a
                          href={`tel:${selectedMapStore.contactNumber}`}
                          className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-600 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition"
                        >
                          <Phone className="w-3.5 h-3.5" />
                          Call Store
                        </a>
                      </div>
                    </div>

                    {/* Active Subsidies */}
                    {selectedMapStore.subsidiesOffered.length > 0 && (
                      <div className="flex items-center gap-1.5 flex-wrap pt-2 border-t border-slate-800">
                        <BadgePercent className="w-3.5 h-3.5 text-amber-400" />
                        <span className="text-[11px] text-amber-300 font-semibold">
                          Active Government Schemes:
                        </span>
                        {selectedMapStore.subsidiesOffered.map((sub, sIdx) => (
                          <span
                            key={sIdx}
                            className="px-2 py-0.5 bg-amber-950/80 text-amber-200 border border-amber-800/60 rounded text-[10px]"
                          >
                            {sub}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* Stores List (List Mode) */}
            {viewMode === "list" && (
            <div className="space-y-4">
              {filteredStores.map((store) => (
                <div
                  key={store.id}
                  className="p-4 bg-slate-950/70 border border-slate-800 rounded-xl space-y-3 hover:border-slate-700 transition"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h4 className="text-sm font-bold text-white">{store.storeName}</h4>
                        <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 rounded-full text-[10px] font-bold">
                          ✓ MahaAgri Licensed
                        </span>
                        <span className="text-[11px] text-slate-400">
                          ({store.distanceKm} km away)
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-rose-400 shrink-0" />
                        {store.address}
                      </p>
                      <p className="text-[11px] text-slate-400 font-mono">
                        License: {store.licenseNumber} | Owner: {store.ownerName}
                      </p>
                      <p className="text-[10px] text-slate-500 flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {store.operatingHours}
                      </p>
                    </div>

                    <div className="flex flex-col sm:flex-row items-end sm:items-center gap-2 shrink-0">
                      <a
                        href={`https://www.google.com/maps/dir/?api=1&destination=${store.coordinates.lat},${store.coordinates.lng}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-bold flex items-center gap-1.5 transition"
                        title="Open Google Maps Driving Directions"
                      >
                        <Navigation className="w-3.5 h-3.5 text-sky-400" />
                        Directions
                      </a>
                      <a
                        href={`tel:${store.contactNumber}`}
                        className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-600 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition"
                      >
                        <Phone className="w-3.5 h-3.5" />
                        Call Store
                      </a>
                    </div>
                  </div>

                  {/* Subsidies */}
                  {store.subsidiesOffered.length > 0 && (
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <BadgePercent className="w-3.5 h-3.5 text-amber-400" />
                      <span className="text-[11px] text-amber-300 font-semibold">
                        Schemes Active:
                      </span>
                      {store.subsidiesOffered.map((sub, sIdx) => (
                        <span
                          key={sIdx}
                          className="px-2 py-0.5 bg-amber-950/80 text-amber-200 border border-amber-800/60 rounded text-[10px]"
                        >
                          {sub}
                        </span>
                      ))}
                    </div>
                  )}

                  {/* Stock table */}
                  <div className="border-t border-slate-800/80 pt-2 space-y-1">
                    <p className="text-[11px] font-bold text-slate-300 uppercase tracking-wider">
                      Verified Stock Availability:
                    </p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                      {store.stockItems.map((item, iIdx) => (
                        <div
                          key={iIdx}
                          className="p-2 bg-slate-900 rounded border border-slate-800/80 flex items-center justify-between"
                        >
                          <div>
                            <p className="font-semibold text-slate-200 text-[11px]">{item.itemName}</p>
                            <span className="text-[10px] text-slate-400">{item.type}</span>
                          </div>
                          <div className="text-right">
                            <span className="text-emerald-400 font-bold text-xs">{item.price}</span>
                            <span className="block text-[9px] text-emerald-300">● In Stock</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
