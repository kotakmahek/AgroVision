import React, { useRef } from "react";
import { 
  X, 
  Printer, 
  CheckCircle2, 
  ShieldCheck, 
  AlertTriangle, 
  FileText, 
  Building2, 
  FlaskConical,
  Droplets,
  Calendar,
  Clock,
  Sparkles,
  Info
} from "lucide-react";
import { DiagnosticReport } from "../types";

interface AgriDealerPrescriptionModalProps {
  report: DiagnosticReport;
  isOpen: boolean;
  onClose: () => void;
}

export const AgriDealerPrescriptionModal: React.FC<AgriDealerPrescriptionModalProps> = ({
  report,
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  const printAreaRef = useRef<HTMLDivElement>(null);

  const handlePrint = () => {
    window.print();
  };

  const crop = report.crop_details;
  const diagnoses = report.diagnoses && report.diagnoses.length > 0 
    ? report.diagnoses 
    : [
        {
          disease_name: report.diagnosis.disease_name,
          causal_agent: report.diagnosis.causal_agent || report.diagnosis.casual_agent || "Pathogen",
          severity_level: report.diagnosis.severity_level,
          estimated_affected_area_percentage: report.diagnosis.estimated_affected_area_percentage || 20,
          key_symptoms: report.diagnosis.key_symptoms || [],
          remediation: report.remediation,
        }
      ];

  // Extract all chemical and biological formulations
  interface PrescribedItem {
    id: number;
    category: "Chemical Fungicide / Insecticide" | "Biological / Organic Input" | "Fertigation / Micro-nutrient";
    genericName: string;
    targetCondition: string;
    dosagePerLiter: string;
    knapsackTankDosage: string; // 16-liter tank
    perAcreDosage: string; // 200-liter water
    waitingPeriodPHI: string;
    cibrcStatus: "Approved" | "Recommended Bio-Control" | "Standard Practice";
  }

  const prescribedItems: PrescribedItem[] = [];
  let itemIdCounter = 1;

  diagnoses.forEach((d) => {
    const chemicalMethods = d.treatment_plan?.chemical_methods || d.remediation?.chemical_treatment || [];
    chemicalMethods.forEach((method) => {
      // Parse out dosages if possible
      let dosagePerL = "2.0 g / L";
      let knapsack = "32 g / 16L tank";
      let perAcre = "400 g / 200L water";
      let phi = "7 - 10 Days";

      if (method.toLowerCase().includes("mancozeb")) {
        dosagePerL = "2.0 – 2.5 g / L";
        knapsack = "35 – 40 g / 16L tank";
        perAcre = "500 g in 200L water";
        phi = "10 Days";
      } else if (method.toLowerCase().includes("copper") || method.toLowerCase().includes("coc")) {
        dosagePerL = "2.5 – 3.0 g / L";
        knapsack = "40 – 50 g / 16L tank";
        perAcre = "600 g in 200L water";
        phi = "7 Days";
      } else if (method.toLowerCase().includes("azoxystrobin")) {
        dosagePerL = "1.0 ml / L";
        knapsack = "16 ml / 16L tank";
        perAcre = "200 ml in 200L water";
        phi = "5 Days";
      } else if (method.toLowerCase().includes("carbendazim")) {
        dosagePerL = "1.0 g / L";
        knapsack = "16 g / 16L tank";
        perAcre = "250 g in 200L water";
        phi = "14 Days";
      } else if (method.toLowerCase().includes("hexaconazole")) {
        dosagePerL = "1.0 – 1.5 ml / L";
        knapsack = "20 ml / 16L tank";
        perAcre = "250 ml in 200L water";
        phi = "14 Days";
      } else if (method.toLowerCase().includes("chlorantraniliprole") || method.toLowerCase().includes("coragen")) {
        dosagePerL = "0.3 – 0.4 ml / L";
        knapsack = "6 ml / 16L tank";
        perAcre = "60 ml in 200L water";
        phi = "3 Days";
      }

      prescribedItems.push({
        id: itemIdCounter++,
        category: "Chemical Fungicide / Insecticide",
        genericName: method,
        targetCondition: d.disease_name || d.condition_name || "Pathogen Control",
        dosagePerLiter: dosagePerL,
        knapsackTankDosage: knapsack,
        perAcreDosage: perAcre,
        waitingPeriodPHI: phi,
        cibrcStatus: "Approved",
      });
    });

    const organicMethods = d.treatment_plan?.organic_methods || d.remediation?.organic_treatment || [];
    organicMethods.forEach((method) => {
      let dosagePerL = "5.0 ml / L";
      let knapsack = "80 ml / 16L tank";
      let perAcre = "1000 ml in 200L water";
      let phi = "0 Days (Safe)";

      if (method.toLowerCase().includes("trichoderma")) {
        dosagePerL = "5.0 g / L";
        knapsack = "80 g / 16L tank";
        perAcre = "1000 g in 200L water";
        phi = "0 Days";
      } else if (method.toLowerCase().includes("pseudomonas")) {
        dosagePerL = "5.0 g / L";
        knapsack = "80 g / 16L tank";
        perAcre = "1000 g in 200L water";
        phi = "0 Days";
      }

      prescribedItems.push({
        id: itemIdCounter++,
        category: "Biological / Organic Input",
        genericName: method,
        targetCondition: `${d.disease_name || "Foliar disease"} (Bio-Control)`,
        dosagePerLiter: dosagePerL,
        knapsackTankDosage: knapsack,
        perAcreDosage: perAcre,
        waitingPeriodPHI: phi,
        cibrcStatus: "Recommended Bio-Control",
      });
    });
  });

  // Fallback if empty
  if (prescribedItems.length === 0) {
    prescribedItems.push({
      id: 1,
      category: "Chemical Fungicide / Insecticide",
      genericName: "Mancozeb 75% WP",
      targetCondition: "Foliar Blight & Leaf Spot",
      dosagePerLiter: "2.0 – 2.5 g / L",
      knapsackTankDosage: "35 – 40 g / 16L tank",
      perAcreDosage: "500 g in 200L water",
      waitingPeriodPHI: "10 Days",
      cibrcStatus: "Approved",
    });
    prescribedItems.push({
      id: 2,
      category: "Biological / Organic Input",
      genericName: "Neem Oil Formulation (Azadirachtin 1500 PPM)",
      targetCondition: "Foliar Sucking Pest & Mite Repellent",
      dosagePerLiter: "5.0 ml / L",
      knapsackTankDosage: "80 ml / 16L tank",
      perAcreDosage: "1000 ml in 200L water",
      waitingPeriodPHI: "0 Days",
      cibrcStatus: "Recommended Bio-Control",
    });
  }

  const currentDate = new Date().toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
  const currentTime = new Date().toLocaleTimeString("en-IN", {
    hour: "2-digit",
    minute: "2-digit",
  });

  const prescriptionId = `RX-AV26-${Math.floor(1000 + Math.random() * 9000)}-IND`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto print:p-0 print:bg-white print:static print:overflow-visible">
      {/* Container / Modal Card */}
      <div 
        ref={printAreaRef}
        className="agri-dealer-slip-container bg-white text-slate-900 rounded-2xl shadow-2xl w-full max-w-4xl border border-slate-300 overflow-hidden my-auto print:border-none print:shadow-none print:rounded-none print:max-w-none print:w-full print:m-0"
      >
        {/* Modal Toolbar (hidden in print) */}
        <div className="bg-slate-900 text-white px-5 py-3 flex items-center justify-between border-b border-slate-800 print:hidden">
          <div className="flex items-center gap-2">
            <Building2 className="w-5 h-5 text-emerald-400" />
            <div>
              <span className="text-sm font-bold text-white block">
                Agri-Input Dealer Verification & Prescription Slip
              </span>
              <span className="text-[11px] text-slate-400">
                Printable sheet formatted for Krishi Seva Kendra / Local Fertilizer & Chemical Retailers
              </span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              id="dealer-modal-print-btn"
              className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition shadow"
              title="Send to Printer / Save as PDF"
            >
              <Printer className="w-4 h-4" />
              <span>Print Slip</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
              title="Close Preview"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Prescription Body */}
        <div className="p-6 sm:p-8 space-y-6 text-slate-900 bg-white font-sans text-xs sm:text-sm print:p-6 print:space-y-4">
          
          {/* Official Letterhead Header */}
          <div className="border-b-2 border-slate-900 pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-emerald-600 inline-block print:border print:border-slate-900" />
                <h1 className="text-xl sm:text-2xl font-black tracking-tight text-slate-900 uppercase font-serif">
                  AgroVision AI — Crop Health Prescription
                </h1>
              </div>
              <p className="text-xs font-semibold text-slate-700 tracking-wide uppercase">
                Krishi Seva Kendra & Agri-Input Dealer Medicine Verification Sheet
              </p>
              <p className="text-[11px] text-slate-500">
                Issued in compliance with CIBRC (Central Insecticides Board & Registration Committee) & ICAR Package of Practices
              </p>
            </div>

            <div className="text-left sm:text-right font-mono text-xs text-slate-700 space-y-1 bg-slate-50 p-3 rounded-lg border border-slate-200 print:bg-transparent print:p-0 print:border-none">
              <div><strong className="text-slate-900">Rx Ref ID:</strong> {prescriptionId}</div>
              <div><strong className="text-slate-900">Date:</strong> {currentDate} | {currentTime}</div>
              <div><strong className="text-slate-900">Validation:</strong> SIH Compliant Verified</div>
            </div>
          </div>

          {/* Specimen & Farmer Clinical Diagnosis Block */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 border border-slate-300 rounded-xl p-4 bg-slate-50/50 print:bg-transparent">
            <div>
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Target Crop Specimen</span>
              <span className="text-base font-bold text-slate-900 block">{crop.common_name}</span>
              <span className="text-xs italic text-slate-600 block">{crop.scientific_name}</span>
            </div>
            <div>
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Pathology / Health Status</span>
              <div className="flex items-center gap-1.5 mt-0.5">
                <span className="px-2 py-0.5 rounded text-xs font-extrabold uppercase bg-rose-100 text-rose-800 border border-rose-300 print:border-slate-800">
                  {crop.overall_status || "DISEASED"}
                </span>
                <span className="text-xs text-slate-700 font-mono">
                  (Conf: {(report.confidence_score * 100).toFixed(0)}%)
                </span>
              </div>
              <span className="text-[11px] text-slate-600 block mt-1">
                Leaf Condition: {crop.leaf_condition}
              </span>
            </div>
            <div>
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Diagnosed Pathogen(s)</span>
              <div className="mt-0.5 space-y-1">
                {diagnoses.map((d, idx) => (
                  <div key={idx} className="text-xs text-slate-900">
                    <strong>{d.disease_name || d.condition_name}</strong>
                    <span className="text-[11px] text-slate-600 ml-1">
                      ({d.causal_agent || d.casual_agent} — {d.severity_level || d.severity} Severity)
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Rx Prescribed Formulations Table */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wide flex items-center gap-2">
                <FlaskConical className="w-4 h-4 text-emerald-700" />
                <span>Authorized Agro-Chemical & Bio-Pesticide Dispensation Schedule</span>
              </h2>
              <span className="text-[11px] text-slate-600 italic">
                *Local dealer must verify active ingredient percentage and batch validity before dispensing
              </span>
            </div>

            <div className="overflow-x-auto border border-slate-300 rounded-lg">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-100 text-slate-800 border-b border-slate-300 font-bold uppercase text-[10px]">
                    <th className="p-2.5 border-r border-slate-200">#</th>
                    <th className="p-2.5 border-r border-slate-200">Prescribed Active Formulation</th>
                    <th className="p-2.5 border-r border-slate-200">Target Purpose</th>
                    <th className="p-2.5 border-r border-slate-200">Dosage per Litre</th>
                    <th className="p-2.5 border-r border-slate-200">16L Sprayer Tank</th>
                    <th className="p-2.5 border-r border-slate-200">Per Acre (200L)</th>
                    <th className="p-2.5 border-r border-slate-200">Waiting Period (PHI)</th>
                    <th className="p-2.5 text-center">Dealer Check</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 font-sans">
                  {prescribedItems.map((item) => (
                    <tr key={item.id} className="hover:bg-slate-50">
                      <td className="p-2.5 font-mono text-slate-600 border-r border-slate-200">{item.id}</td>
                      <td className="p-2.5 font-bold text-slate-900 border-r border-slate-200">
                        <div>{item.genericName}</div>
                        <span className="text-[10px] font-normal text-emerald-800 font-mono">
                          {item.cibrcStatus}
                        </span>
                      </td>
                      <td className="p-2.5 text-slate-700 border-r border-slate-200">{item.targetCondition}</td>
                      <td className="p-2.5 font-mono font-bold text-slate-900 border-r border-slate-200">{item.dosagePerLiter}</td>
                      <td className="p-2.5 font-mono text-slate-800 border-r border-slate-200">{item.knapsackTankDosage}</td>
                      <td className="p-2.5 font-mono text-slate-800 border-r border-slate-200">{item.perAcreDosage}</td>
                      <td className="p-2.5 text-slate-700 font-medium border-r border-slate-200">{item.waitingPeriodPHI}</td>
                      <td className="p-2.5 text-center">
                        <div className="w-4 h-4 border border-slate-500 rounded mx-auto print:border-slate-800" />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Field Application & Safety Instructions for Farmer */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div className="border border-slate-300 rounded-lg p-3.5 space-y-1.5 bg-slate-50/50 print:bg-transparent">
              <h3 className="font-bold text-slate-900 flex items-center gap-1.5 uppercase text-[11px]">
                <Droplets className="w-3.5 h-3.5 text-blue-600" />
                <span>Field Spraying Guidelines for Farmer</span>
              </h3>
              <ul className="list-disc list-inside space-y-1 text-slate-700">
                <li>Spray during morning (7:00 AM – 9:30 AM) or cool evening (after 4:30 PM).</li>
                <li>Use clean, neutral water (pH 6.5–7.2) for tank mixing. Avoid muddy pond water.</li>
                <li>Use a hollow cone nozzle and ensure thorough under-canopy leaf coverage.</li>
                <li>Maintain recommended Pre-Harvest Interval (PHI) before picking fruits/harvesting.</li>
              </ul>
            </div>

            <div className="border border-slate-300 rounded-lg p-3.5 space-y-1.5 bg-slate-50/50 print:bg-transparent">
              <h3 className="font-bold text-slate-900 flex items-center gap-1.5 uppercase text-[11px]">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                <span>Chemical Safety & Handling Precautions</span>
              </h3>
              <ul className="list-disc list-inside space-y-1 text-slate-700">
                <li>Wear protective rubber gloves, face mask, and eye goggles during mixing.</li>
                <li>Do not combine Copper Oxychloride with alkaline insecticides or sulfur sprays.</li>
                <li>Triple rinse empty chemical containers and puncture them; dispose safely.</li>
                <li>In case of accidental skin contact or poisoning, call Kisan Helpline 1800-180-1551.</li>
              </ul>
            </div>
          </div>

          {/* Regional Advisory Script for Farmer Understanding */}
          {report.localized_advisory?.summary_script && (
            <div className="border-l-4 border-emerald-600 pl-3 py-1 bg-emerald-50/40 print:bg-transparent text-slate-800 text-xs">
              <span className="font-bold block text-emerald-900 uppercase text-[10px]">
                Farmer Voice Summary ({report.localized_advisory.language})
              </span>
              <p className="mt-0.5 leading-relaxed font-sans text-slate-700">
                "{report.localized_advisory.summary_script}"
              </p>
            </div>
          )}

          {/* Official Dealer Verification & Endorsement Box */}
          <div className="border-2 border-slate-800 rounded-xl p-4 bg-slate-50 print:bg-transparent space-y-4">
            <div className="flex items-center justify-between border-b border-slate-300 pb-2">
              <span className="font-bold text-slate-900 uppercase tracking-wide text-xs flex items-center gap-1.5">
                <Building2 className="w-4 h-4 text-slate-700" />
                Agri-Input Dealer Verification & Dispensation Endorsement
              </span>
              <span className="text-[10px] text-slate-500 font-mono">
                Mandatory for Krishi Seva Kendra Records
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 text-xs">
              <div>
                <span className="text-[10px] text-slate-500 font-semibold uppercase block">Dealer / Kendra Name</span>
                <div className="border-b border-slate-400 mt-4 text-slate-400 font-mono text-[11px]">
                  _________________________
                </div>
              </div>

              <div>
                <span className="text-[10px] text-slate-500 font-semibold uppercase block">Retail License No.</span>
                <div className="border-b border-slate-400 mt-4 text-slate-400 font-mono text-[11px]">
                  _________________________
                </div>
              </div>

              <div>
                <span className="text-[10px] text-slate-500 font-semibold uppercase block">Trade Name & Batch No.</span>
                <div className="border-b border-slate-400 mt-4 text-slate-400 font-mono text-[11px]">
                  _________________________
                </div>
              </div>

              <div>
                <span className="text-[10px] text-slate-500 font-semibold uppercase block">Dispensed Quantity & Bill No.</span>
                <div className="border-b border-slate-400 mt-4 text-slate-400 font-mono text-[11px]">
                  _________________________
                </div>
              </div>
            </div>

            <div className="pt-2 flex flex-col sm:flex-row sm:items-end justify-between gap-6">
              <div className="space-y-1">
                <span className="text-[10px] text-slate-500 uppercase block">Farmer Signature / Thumb:</span>
                <div className="w-48 h-10 border-b border-dashed border-slate-400 flex items-end">
                  <span className="text-[10px] text-slate-400 italic">Signature of Farmer</span>
                </div>
              </div>

              <div className="flex items-center gap-6">
                <div className="w-36 h-20 border-2 border-dashed border-slate-400 rounded-lg flex flex-col items-center justify-center text-center p-1 text-[10px] text-slate-400">
                  <span>Dealer Rubber Stamp & Date</span>
                </div>

                <div className="space-y-1 text-right">
                  <span className="text-[10px] text-slate-500 uppercase block">Authorized Dealer Sign:</span>
                  <div className="w-44 h-10 border-b border-dashed border-slate-400 flex items-end justify-end">
                    <span className="text-[10px] text-slate-400 italic">Dispensed By</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Footer Disclaimer */}
          <div className="text-[10px] text-slate-500 text-center border-t border-slate-200 pt-3">
            AgroVision AI is an intelligent decision-support platform designed for Indian agriculture under the Smart India Hackathon (SIH) framework. All prescriptions should be verified by the licensed agri-dealer or local Krishi Vigyan Kendra (KVK) officer before field application.
          </div>

        </div>
      </div>
    </div>
  );
};
