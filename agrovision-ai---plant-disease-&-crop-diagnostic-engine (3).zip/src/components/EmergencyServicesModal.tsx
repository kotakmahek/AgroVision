import React, { useState } from "react";
import { EMERGENCY_SERVICES } from "../data/emergencyServices";
import { 
  PhoneCall, 
  ExternalLink, 
  MapPin, 
  X, 
  AlertOctagon, 
  Building2, 
  LifeBuoy,
  Search
} from "lucide-react";

interface EmergencyServicesModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const STATE_AGRICULTURE_HELPLINES = [
  { state: "Uttar Pradesh", phone: "1800-180-1551 / 0522-2207238" },
  { state: "Maharashtra", phone: "1800-233-4000 (Kisan Care)" },
  { state: "Punjab", phone: "0172-2970605 (Dept of Agriculture)" },
  { state: "Tamil Nadu", phone: "1800-425-4444 (Uzhavan Helpdesk)" },
  { state: "Andhra Pradesh / Telangana", phone: "1902 / 1800-425-3536" },
  { state: "Gujarat", phone: "1800-233-0222 (iKhedut)" },
  { state: "Madhya Pradesh", phone: "0755-2558823" },
  { state: "Rajasthan", phone: "1800-180-1551" },
  { state: "Karnataka", phone: "080-22212861 (Raitha Mitra)" },
  { state: "West Bengal", phone: "1800-103-6002 (Matir Katha)" },
];

export const EmergencyServicesModal: React.FC<EmergencyServicesModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [searchTerm, setSearchTerm] = useState("");

  if (!isOpen) return null;

  const filteredStates = STATE_AGRICULTURE_HELPLINES.filter((s) =>
    s.state.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in text-white">
      <div className="bg-slate-900 border border-emerald-700/60 rounded-2xl w-full max-w-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 bg-gradient-to-r from-rose-950 via-slate-900 to-emerald-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-rose-600 text-white rounded-xl shadow">
              <LifeBuoy className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                Agricultural Emergency Services & District Helplines
              </h2>
              <p className="text-xs text-rose-300">
                Direct links, 24x7 phone dialers, and localized GPS maps for Indian farmers
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Top Priority: Kisan Call Centre Callout */}
          <div className="p-4 bg-rose-950/40 border-2 border-rose-600/50 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 bg-rose-600 text-white text-[11px] font-bold rounded-full uppercase">
                  National Priority
                </span>
                <span className="text-xs font-semibold text-rose-200">Toll-Free in 22 Indian Languages</span>
              </div>
              <h3 className="text-lg font-black text-white">Kisan Call Centre (KCC): 1800-180-1551</h3>
              <p className="text-xs text-slate-300">
                Operated by agriculture scientists & agronomists. Free advice on pest outbreaks, crop compensation, and weather alerts.
              </p>
            </div>
            <a
              href="tel:18001801551"
              className="px-5 py-2.5 bg-rose-600 hover:bg-rose-500 text-white font-bold text-sm rounded-xl shadow-lg flex items-center gap-2 shrink-0 transition"
            >
              <PhoneCall className="w-4 h-4" />
              Dial 1800-180-1551
            </a>
          </div>

          {/* National Services Directory */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-emerald-400 mb-3 flex items-center gap-2">
              <Building2 className="w-4 h-4" />
              Certified National Agricultural Centers & Portals
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {EMERGENCY_SERVICES.map((service, idx) => (
                <div
                  key={idx}
                  className="p-4 bg-slate-950/70 border border-slate-800 rounded-xl space-y-2.5 hover:border-emerald-700/50 transition flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-bold text-emerald-300">{service.name}</span>
                      {service.badge && (
                        <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 font-medium">
                          {service.badge}
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-400 leading-relaxed">{service.description}</p>
                    {service.timing && (
                      <p className="text-[11px] text-slate-500 mt-1">🕒 {service.timing}</p>
                    )}
                  </div>

                  <div className="pt-2 flex items-center gap-2 border-t border-slate-800/80">
                    {service.phone && (
                      <a
                        href={`tel:${service.phone.replace(/[^0-9]/g, "")}`}
                        className="flex-1 py-1.5 px-2.5 bg-emerald-700 hover:bg-emerald-600 text-white rounded-lg text-xs font-semibold text-center flex items-center justify-center gap-1.5 transition"
                      >
                        <PhoneCall className="w-3.5 h-3.5" />
                        Call {service.phone}
                      </a>
                    )}
                    {service.url && (
                      <a
                        href={service.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="py-1.5 px-3 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-medium flex items-center justify-center gap-1 transition"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        Portal
                      </a>
                    )}
                    {service.mapsQuery && (
                      <a
                        href={`https://www.google.com/maps/search/${encodeURIComponent(service.mapsQuery)}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="py-1.5 px-3 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-medium flex items-center justify-center gap-1 transition"
                      >
                        <MapPin className="w-3.5 h-3.5 text-rose-400" />
                        Map
                      </a>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* State-Level Agricultural Helpline Directory */}
          <div className="pt-2">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-2">
                <MapPin className="w-4 h-4 text-emerald-400" />
                State Agriculture Department Helplines
              </h3>
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                <input
                  type="text"
                  placeholder="Filter state (e.g. Punjab, Maharashtra)..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-8 pr-3 py-1 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-emerald-400"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-48 overflow-y-auto pr-1">
              {filteredStates.map((st, i) => (
                <div
                  key={i}
                  className="p-2.5 bg-slate-950 border border-slate-800 rounded-lg flex items-center justify-between text-xs"
                >
                  <span className="font-semibold text-slate-200">{st.state}</span>
                  <span className="text-emerald-400 font-mono text-[11px]">{st.phone}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold transition"
          >
            Close Emergency Panel
          </button>
        </div>
      </div>
    </div>
  );
};
