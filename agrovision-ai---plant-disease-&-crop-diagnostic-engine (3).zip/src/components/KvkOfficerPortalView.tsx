import React, { useState } from "react";
import { 
  Building2, 
  ShieldCheck, 
  CheckCircle2, 
  AlertTriangle, 
  Radio, 
  FileText, 
  Users, 
  MapPin, 
  Search, 
  Filter, 
  Award, 
  Check, 
  X,
  Sparkles
} from "lucide-react";

interface KvkClusterApproval {
  id: string;
  district: string;
  taluka: string;
  crop: string;
  pathogen: string;
  aiConfidence: number;
  farmsReported: number;
  radiusKm: number;
  status: "PENDING_OFFICER_REVIEW" | "APPROVED_BROADCAST" | "REJECTED";
  submittedTime: string;
  recommendedAction: string;
}

export const KvkOfficerPortalView: React.FC = () => {
  const [officerName, setOfficerName] = useState<string>("Dr. Rajendra Sonawane, Senior Pathologist (KVK Yavatmal)");
  const [clusters, setClusters] = useState<KvkClusterApproval[]>([
    {
      id: "KVK-CLUST-2024-01",
      district: "Yavatmal",
      taluka: "Babhulgaon",
      crop: "Cotton (कापूस)",
      pathogen: "Pink Bollworm (Pectinophora gossypiella)",
      aiConfidence: 94,
      farmsReported: 5,
      radiusKm: 5,
      status: "PENDING_OFFICER_REVIEW",
      submittedTime: "18 mins ago",
      recommendedAction: "Authorize emergency WhatsApp broadcast to 52 farmers in Babhulgaon Gram Panchayat and deploy pheromone trap demonstration kit.",
    },
    {
      id: "KVK-CLUST-2024-02",
      district: "Latur",
      taluka: "Ausa",
      crop: "Soybean (सोयाबीन)",
      pathogen: "Asian Soybean Rust (Phakopsora pachyrhizi)",
      aiConfidence: 89,
      farmsReported: 3,
      radiusKm: 5,
      status: "APPROVED_BROADCAST",
      submittedTime: "2 hours ago",
      recommendedAction: "Community broadcast approved. Hexaconazole 5% EC advisory issued with 14-day PHI guideline.",
    },
    {
      id: "KVK-CLUST-2024-03",
      district: "Kolhapur",
      taluka: "Hatkanangale",
      crop: "Sugarcane (ऊस)",
      pathogen: "Red Rot (Colletotrichum falcatum)",
      aiConfidence: 92,
      farmsReported: 4,
      radiusKm: 7,
      status: "PENDING_OFFICER_REVIEW",
      submittedTime: "3 hours ago",
      recommendedAction: "Rogueing protocol mandate and field visit scheduled by Agricultural Officer.",
    },
  ]);

  const handleApprove = (id: string) => {
    setClusters((prev) =>
      prev.map((c) => (c.id === id ? { ...c, status: "APPROVED_BROADCAST" } : c))
    );
  };

  const handleReject = (id: string) => {
    setClusters((prev) =>
      prev.map((c) => (c.id === id ? { ...c, status: "REJECTED" } : c))
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-br from-emerald-950/90 via-slate-900 to-emerald-950/80 border border-emerald-800/60 rounded-3xl p-6 sm:p-8 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="px-3 py-1 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded-full text-xs font-bold flex items-center gap-1.5">
                <Building2 className="w-3.5 h-3.5 text-emerald-400" />
                Department of Agriculture, Govt. of Maharashtra
              </span>
              <span className="px-2.5 py-0.5 bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded-full text-xs font-semibold">
                Human-in-the-Loop Oversight
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              KVK & State Officer Verification Portal
            </h2>
            <p className="text-sm text-slate-300 max-w-2xl leading-relaxed">
              Provides Krishi Vigyan Kendra (KVK) scientists and District Agriculture Officers regulatory compliance controls. Review AI-flagged village clusters, validate diagnoses, and approve official WhatsApp community broadcasts.
            </p>
          </div>

          <div className="bg-slate-900/80 border border-slate-700/80 p-3.5 rounded-2xl shrink-0 flex items-center gap-3">
            <div className="p-2.5 bg-emerald-500/20 rounded-xl border border-emerald-500/30 text-emerald-400">
              <Award className="w-6 h-6" />
            </div>
            <div>
              <p className="text-xs text-slate-400 font-medium">Certified KVK Evaluator</p>
              <p className="text-xs font-bold text-white max-w-[200px] truncate">{officerName}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Cluster Approvals Queue */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-lg space-y-5">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              Pending Outbreak Clusters for State Sanction
            </h3>
            <p className="text-xs text-slate-400">
              AI-detected multi-farm clusters awaiting official agricultural officer sign-off.
            </p>
          </div>

          <span className="px-3 py-1 bg-slate-800 border border-slate-700 rounded-full text-xs text-slate-300 font-semibold">
            {clusters.filter((c) => c.status === "PENDING_OFFICER_REVIEW").length} Pending Sanctions
          </span>
        </div>

        <div className="space-y-4">
          {clusters.map((cluster) => {
            const isPending = cluster.status === "PENDING_OFFICER_REVIEW";
            const isApproved = cluster.status === "APPROVED_BROADCAST";
            return (
              <div
                key={cluster.id}
                className={`p-5 rounded-2xl border transition ${
                  isPending
                    ? "bg-slate-950/80 border-amber-600/60 shadow-lg"
                    : isApproved
                    ? "bg-slate-950/60 border-emerald-600/60"
                    : "bg-slate-950/40 border-slate-800 opacity-60"
                }`}
              >
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div className="space-y-1.5">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-mono text-xs text-slate-400 font-bold">{cluster.id}</span>
                      <span className="text-xs font-bold text-white">{cluster.crop}</span>
                      <span
                        className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                          isApproved
                            ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/40"
                            : isPending
                            ? "bg-amber-500/20 text-amber-300 border border-amber-500/40"
                            : "bg-slate-800 text-slate-400"
                        }`}
                      >
                        {cluster.status.replace(/_/g, " ")}
                      </span>
                    </div>

                    <h4 className="text-sm font-extrabold text-emerald-400">
                      {cluster.pathogen}
                    </h4>

                    <div className="flex items-center gap-3 text-xs text-slate-300 flex-wrap">
                      <span className="flex items-center gap-1 text-slate-200">
                        <MapPin className="w-3.5 h-3.5 text-rose-400" />
                        {cluster.taluka} Taluka, {cluster.district} ({cluster.radiusKm} km radius)
                      </span>
                      <span>•</span>
                      <span>AI Model Confidence: <strong>{cluster.aiConfidence}%</strong></span>
                      <span>•</span>
                      <span>{cluster.farmsReported} Confirmed Field Specimens</span>
                      <span>•</span>
                      <span className="text-slate-400">{cluster.submittedTime}</span>
                    </div>

                    <p className="text-xs text-slate-300 pt-1 leading-relaxed">
                      <strong className="text-amber-300">Action Plan:</strong> {cluster.recommendedAction}
                    </p>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2 shrink-0">
                    {isPending ? (
                      <>
                        <button
                          onClick={() => handleApprove(cluster.id)}
                          className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow transition"
                        >
                          <Check className="w-4 h-4" />
                          Approve & Broadcast
                        </button>
                        <button
                          onClick={() => handleReject(cluster.id)}
                          className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-medium border border-slate-700 transition"
                        >
                          <X className="w-4 h-4" />
                          Reject
                        </button>
                      </>
                    ) : isApproved ? (
                      <div className="flex items-center gap-1.5 text-emerald-400 text-xs font-bold bg-emerald-950 px-3 py-1.5 rounded-xl border border-emerald-800">
                        <CheckCircle2 className="w-4 h-4" />
                        Official State Broadcast Dispatched
                      </div>
                    ) : (
                      <span className="text-slate-500 text-xs font-medium">Audit Closed</span>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
