import React from "react";
import { SupportedLanguage } from "../types";
import { 
  Sprout, 
  Languages, 
  Wifi, 
  WifiOff, 
  PhoneCall, 
  Database,
  ShieldCheck,
  Zap
} from "lucide-react";

interface HeaderProps {
  currentLanguage: SupportedLanguage;
  onLanguageChange: (lang: SupportedLanguage) => void;
  isOfflineMode: boolean;
  onToggleOffline: () => void;
  onOpenEmergency: () => void;
  onOpenOfflineCache: () => void;
  savedCount: number;
}

const LANGUAGES: { id: SupportedLanguage; label: string; native: string }[] = [
  { id: "Hindi", label: "Hindi", native: "हिन्दी" },
  { id: "Tamil", label: "Tamil", native: "தமிழ்" },
  { id: "Marathi", label: "Marathi", native: "मराठी" },
  { id: "Telugu", label: "Telugu", native: "తెలుగు" },
  { id: "Bengali", label: "Bengali", native: "বাংলা" },
  { id: "Gujarati", label: "Gujarati", native: "ગુજરાતી" },
  { id: "Punjabi", label: "Punjabi", native: "ਪੰਜਾਬੀ" },
  { id: "Kannada", label: "Kannada", native: "ಕನ್ನಡ" },
  { id: "English", label: "English", native: "English" },
];

export const Header: React.FC<HeaderProps> = ({
  currentLanguage,
  onLanguageChange,
  isOfflineMode,
  onToggleOffline,
  onOpenEmergency,
  onOpenOfflineCache,
  savedCount,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-emerald-950/95 backdrop-blur border-b border-emerald-800/60 text-white shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-4">
        {/* Brand identity */}
        <div className="flex items-center gap-3 min-w-0">
          <div className="h-12 w-12 rounded-xl bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center text-emerald-400 shrink-0 shadow-inner">
            <Sprout className="w-7 h-7 stroke-[2.2]" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h1 className="text-xl sm:text-2xl font-black tracking-tight font-['Outfit',sans-serif] text-emerald-100 flex items-center gap-1.5">
                AgroVision <span className="text-emerald-400 font-extrabold">AI</span>
              </h1>
              <span className="hidden sm:inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-800/80 text-emerald-300 border border-emerald-600/40">
                <ShieldCheck className="w-3 h-3 text-emerald-400" />
                Grounded Reference Data
              </span>
              <span className="hidden md:inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium bg-amber-950/80 text-amber-300 border border-amber-700/40">
                <Zap className="w-3 h-3 text-amber-400" />
                Live Gemini Analysis
              </span>
            </div>
            <p className="text-xs text-emerald-300/80 truncate max-w-md hidden sm:block">
              Precision Agricultural Pathology & Localized Treatment for Indian Crops
            </p>
          </div>
        </div>

        {/* Right actions: Language, Offline Cache, Emergency Call */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          {/* Language selector */}
          <div className="relative flex items-center">
            <Languages className="w-4 h-4 text-emerald-400 absolute left-2.5 pointer-events-none" />
            <select
              id="language-selector"
              value={currentLanguage}
              onChange={(e) => onLanguageChange(e.target.value as SupportedLanguage)}
              className="pl-8 pr-3 py-1.5 bg-emerald-900/80 hover:bg-emerald-900 border border-emerald-700/70 rounded-lg text-xs font-semibold text-emerald-100 focus:outline-none focus:ring-2 focus:ring-emerald-400 transition cursor-pointer appearance-none"
              title="Select Regional Advisory Language"
            >
              {LANGUAGES.map((lang) => (
                <option key={lang.id} value={lang.id} className="bg-emerald-950 text-white">
                  {lang.native} ({lang.label})
                </option>
              ))}
            </select>
          </div>

          {/* Offline switch / cache */}
          <button
            id="toggle-offline-btn"
            onClick={onToggleOffline}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition ${
              isOfflineMode
                ? "bg-amber-500/20 text-amber-200 border-amber-500/50"
                : "bg-emerald-900/50 text-emerald-300 border-emerald-700/50 hover:bg-emerald-800/60"
            }`}
            title="Toggle Offline Edge Diagnostic Simulation"
          >
            {isOfflineMode ? (
              <>
                <WifiOff className="w-3.5 h-3.5 text-amber-400" />
                <span className="hidden md:inline">Offline Mode</span>
              </>
            ) : (
              <>
                <Wifi className="w-3.5 h-3.5 text-emerald-400" />
                <span className="hidden md:inline">Online Cloud</span>
              </>
            )}
          </button>

          {/* SQLite Cache / Records */}
          <button
            id="open-cache-btn"
            onClick={onOpenOfflineCache}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-emerald-900/60 text-emerald-200 border border-emerald-700/60 hover:bg-emerald-800 transition"
            title="Open Offline Cache & History"
          >
            <Database className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden sm:inline">Cache</span>
            {savedCount > 0 && (
              <span className="px-1.5 py-0.2 bg-emerald-500 text-emerald-950 text-[10px] font-bold rounded-full">
                {savedCount}
              </span>
            )}
          </button>

          {/* Emergency Helplines CTA */}
          <button
            id="emergency-services-btn"
            onClick={onOpenEmergency}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-bold bg-rose-600 hover:bg-rose-500 text-white shadow-sm transition animate-pulse duration-1000"
            title="Emergency Agricultural Helplines (Kisan Call Centre 1800-180-1551)"
          >
            <PhoneCall className="w-3.5 h-3.5" />
            <span>Emergency Help</span>
          </button>
        </div>
      </div>
    </header>
  );
};
