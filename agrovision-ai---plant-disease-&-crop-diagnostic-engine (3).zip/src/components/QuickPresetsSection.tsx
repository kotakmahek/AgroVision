import React from "react";
import { QUICK_TEST_PRESETS } from "../data/sampleCrops";
import { QuickTestPreset } from "../types";

interface QuickPresetsSectionProps {
  onSelectPreset: (preset: QuickTestPreset) => void;
  selectedPresetId?: string;
}

export const QuickPresetsSection: React.FC<QuickPresetsSectionProps> = ({
  onSelectPreset,
  selectedPresetId,
}) => {
  return (
    <div className="p-4 bg-slate-900 rounded-xl border border-slate-800">
      <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
        <h3 className="text-white font-bold flex items-center gap-2 text-sm tracking-wide">
          <span>⚡</span>
          <span>QUICK TEST PRESETS (INSTANT CLICK-TO-TEST)</span>
        </h3>
        <span className="text-[11px] text-emerald-400 bg-emerald-950/60 px-2.5 py-0.5 rounded-full border border-emerald-800/60 font-medium">
          6 Standard Specimens
        </span>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        {QUICK_TEST_PRESETS.map((preset) => {
          const isSelected = selectedPresetId === preset.id;
          return (
            <div
              key={preset.id}
              onClick={() => onSelectPreset(preset)}
              className={`cursor-pointer bg-slate-800 hover:bg-slate-700 border rounded-lg p-2 transition-all transform hover:-translate-y-1 ${
                isSelected
                  ? "border-emerald-500 ring-2 ring-emerald-500/40 bg-slate-800/95"
                  : "border-slate-700 hover:border-emerald-500"
              }`}
            >
              <div className="relative w-full h-24 mb-2 rounded overflow-hidden bg-black/40">
                <img
                  src={preset.image}
                  alt={preset.diseaseName}
                  className="w-full h-full object-cover"
                />
                <span
                  className={`absolute top-1 right-1 text-[10px] px-1.5 py-0.5 rounded text-white font-semibold shadow-sm ${preset.badgeColor}`}
                >
                  {preset.category}
                </span>
              </div>

              <h4 className="text-xs font-bold text-slate-100 truncate">
                {preset.cropName}: {preset.diseaseName}
              </h4>
              <p className="text-[11px] text-emerald-400 font-medium truncate mt-0.5">
                {preset.marathiName}
              </p>
            </div>
          );
        })}
      </div>
    </div>
  );
};
