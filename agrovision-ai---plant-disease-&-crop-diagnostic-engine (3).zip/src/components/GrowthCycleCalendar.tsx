import React, { useState } from "react";
import {
  Calendar,
  Clock,
  ShieldCheck,
  Sprout,
  AlertTriangle,
  CheckCircle2,
  Filter,
  Sparkles,
  Printer,
  ChevronRight,
  TrendingUp,
  Droplets,
  Layers,
  Bug,
  Info
} from "lucide-react";
import { CropGrowthCalendar, GrowthStageItem, PreventativeAction } from "../types";
import { getGrowthCalendarForCrop } from "../data/growthCalendarData";

interface GrowthCycleCalendarProps {
  cropCommonName: string;
  diagnosedDiseases?: string[];
  onOpenEmergency?: () => void;
}

export const GrowthCycleCalendar: React.FC<GrowthCycleCalendarProps> = ({
  cropCommonName,
  diagnosedDiseases = []
}) => {
  const calendar: CropGrowthCalendar = getGrowthCalendarForCrop(cropCommonName);

  // State: selected stage for detailed inspection
  const [selectedStageIndex, setSelectedStageIndex] = useState<number>(1); // Default to vegetative (stage 2)
  // State: crop age simulator slider (in days)
  const [simulatedCropAge, setSimulatedCropAge] = useState<number>(35);
  // State: filter by preventative action type
  const [actionFilter, setActionFilter] = useState<string>("all");

  // Determine which stage corresponds to simulatedCropAge
  const currentSimulatedStage = calendar.stages.find(
    (s) => simulatedCropAge >= s.minDays && simulatedCropAge <= s.maxDays
  ) || calendar.stages[calendar.stages.length - 1];

  const activeStage = calendar.stages[selectedStageIndex] || calendar.stages[0];

  // Filter actions for the active stage
  const filteredActions = activeStage.preventativeActions.filter((act) => {
    if (actionFilter === "all") return true;
    return act.type.toLowerCase().includes(actionFilter.toLowerCase());
  });

  // Action type badge styling helper
  const getActionTypeBadge = (type: PreventativeAction["type"]) => {
    switch (type) {
      case "Organic / Bio-Control":
        return "bg-emerald-950 text-emerald-300 border-emerald-800";
      case "Chemical Prophylactic":
        return "bg-amber-950 text-amber-300 border-amber-800";
      case "Cultural Practice":
        return "bg-sky-950 text-sky-300 border-sky-800";
      case "Fertigation":
        return "bg-indigo-950 text-indigo-300 border-indigo-800";
      default:
        return "bg-slate-800 text-slate-300 border-slate-700";
    }
  };

  const handlePrintSchedule = () => {
    window.print();
  };

  return (
    <div
      id="growth-cycle-calendar-container"
      className="bg-slate-900/90 border border-emerald-800/40 rounded-2xl p-5 sm:p-6 shadow-xl space-y-6 text-slate-100"
    >
      {/* Section Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div className="space-y-1">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-950 text-emerald-300 border border-emerald-800 flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-emerald-400" />
              Agronomic Growth Cycle Calendar
            </span>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-800 text-slate-300 border border-slate-700 flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-amber-400" />
              {calendar.totalDurationDays} Days Total Cycle
            </span>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-indigo-950 text-indigo-300 border border-indigo-800 flex items-center gap-1">
              <TrendingUp className="w-3.5 h-3.5 text-indigo-400" />
              Yield Protection Engine
            </span>
          </div>
          <h3 className="text-xl sm:text-2xl font-black tracking-tight text-white font-['Outfit',sans-serif]">
            {calendar.cropName} Preventative Health & Treatment Timeline
          </h3>
          <p className="text-xs text-slate-400 max-w-2xl">
            {calendar.seasonRecommendation}. Applying proactive treatments during these critical physiological windows safeguards chlorophyll integrity and prevents up to 85% of downstream crop losses.
          </p>
        </div>

        <button
          onClick={handlePrintSchedule}
          className="self-start sm:self-center px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white rounded-xl text-xs font-medium border border-slate-700 flex items-center gap-2 transition shrink-0"
          title="Print or Export Preventative Spray Calendar"
        >
          <Printer className="w-4 h-4 text-emerald-400" />
          <span>Print Calendar</span>
        </button>
      </div>

      {/* Interactive Crop Age Simulator Slider */}
      <div className="p-4 sm:p-5 bg-gradient-to-r from-slate-950 via-slate-900 to-emerald-950/40 border border-slate-800 rounded-2xl space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-emerald-400" />
            <span className="text-xs sm:text-sm font-bold text-white">
              Simulate Current Crop Age:
            </span>
            <span className="px-2.5 py-0.5 rounded-lg bg-emerald-600 text-white font-mono font-bold text-xs shadow">
              Day {simulatedCropAge}
            </span>
          </div>
          <div className="text-xs text-emerald-300 font-medium flex items-center gap-1.5">
            <span>Current Stage:</span>
            <strong className="text-white bg-slate-800 px-2 py-0.5 rounded border border-slate-700">
              {currentSimulatedStage.stageName}
            </strong>
          </div>
        </div>

        {/* Range Slider */}
        <div className="space-y-1">
          <input
            type="range"
            min={0}
            max={calendar.totalDurationDays}
            value={simulatedCropAge}
            onChange={(e) => {
              const val = Number(e.target.value);
              setSimulatedCropAge(val);
              // Auto-select corresponding stage
              const matchedIdx = calendar.stages.findIndex(
                (s) => val >= s.minDays && val <= s.maxDays
              );
              if (matchedIdx !== -1 && matchedIdx !== selectedStageIndex) {
                setSelectedStageIndex(matchedIdx);
              }
            }}
            className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
          />
          <div className="flex justify-between text-[11px] text-slate-500 font-mono px-0.5">
            <span>Sowing (Day 0)</span>
            <span>Day {Math.round(calendar.totalDurationDays * 0.25)}</span>
            <span>Flowering (Day {Math.round(calendar.totalDurationDays * 0.5)})</span>
            <span>Bulking (Day {Math.round(calendar.totalDurationDays * 0.75)})</span>
            <span>Harvest (Day {calendar.totalDurationDays})</span>
          </div>
        </div>

        {/* Dynamic Urgency / Co-Infection Alert for this Age */}
        <div className="p-3 bg-emerald-950/40 border border-emerald-800/50 rounded-xl flex items-start gap-2.5 text-xs text-slate-200">
          <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
          <div>
            <span className="font-bold text-emerald-300">
              Optimal Action Window at Day {simulatedCropAge}:{" "}
            </span>
            <span>
              {simulatedCropAge <= 25 &&
                "Focus on seed bed solarization, biological seed coating with Trichoderma, and 40-mesh netting against insect vectors."}
              {simulatedCropAge > 25 && simulatedCropAge <= 50 &&
                "Critical preventative phase! Prune bottom suckers, stake stems, and spray Mancozeb or Neem oil before the canopy becomes dense."}
              {simulatedCropAge > 50 && simulatedCropAge <= 75 &&
                "Reproductive setting window: Apply Boron + Calcium Nitrate to prevent blossom drop. Apply dual-action preventative fungicide for fruit protection."}
              {simulatedCropAge > 75 && simulatedCropAge <= 100 &&
                "Yield bulking period: Maintain balanced drip moisture, apply Sulphate of Potash, and monitor pheromone traps against borers."}
              {simulatedCropAge > 100 &&
                "Harvest flushes: Perform clean early-morning pickings, discard infected culls, and sanitize soil post-final pick."}
            </span>
            {diagnosedDiseases.length > 0 && (
              <p className="mt-1 text-amber-300 font-semibold flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span>
                  Pathology Alert ({diagnosedDiseases.join(", ")}): Ensure prophylactic coverage right now to stop spores from spreading into the next physiological stage!
                </span>
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Stage Stepper Navigation Bar */}
      <div className="space-y-2">
        <span className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
          <Layers className="w-3.5 h-3.5 text-emerald-400" />
          Select Growth Phase to Inspect Prophylactic Plan:
        </span>
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
          {calendar.stages.map((stage, idx) => {
            const isSelected = selectedStageIndex === idx;
            const isSimulatedCurrent = currentSimulatedStage.id === stage.id;

            return (
              <button
                key={stage.id}
                onClick={() => setSelectedStageIndex(idx)}
                className={`p-3 rounded-xl border text-left transition relative flex flex-col justify-between ${
                  isSelected
                    ? "bg-emerald-950/80 border-emerald-500 shadow-md ring-1 ring-emerald-400 text-white"
                    : "bg-slate-950/70 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700"
                }`}
              >
                {isSimulatedCurrent && (
                  <span className="absolute -top-2 right-2 text-[9px] font-extrabold uppercase bg-emerald-500 text-emerald-950 px-1.5 py-0.2 rounded shadow">
                    Active Age
                  </span>
                )}
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[10px] font-mono font-bold text-emerald-400">
                    Phase {idx + 1}
                  </span>
                  <span className="text-[10px] font-mono text-slate-400">
                    {stage.dayRange.split(" – ")[0]}
                  </span>
                </div>
                <p className="text-xs font-bold leading-snug line-clamp-2">
                  {stage.stageName}
                </p>
              </button>
            );
          })}
        </div>
      </div>

      {/* Active Stage Detailed Breakdown */}
      <div className="bg-slate-950/90 border border-slate-800 rounded-2xl p-5 space-y-5">
        {/* Stage Overview Banner */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-4 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800">
                {activeStage.dayRange}
              </span>
              <h4 className="text-lg font-black text-white">
                {activeStage.stageName}
              </h4>
            </div>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 leading-relaxed">
              {activeStage.description}
            </p>
          </div>

          <div className="bg-rose-950/40 border border-rose-900/60 rounded-xl p-3 shrink-0 max-w-md">
            <span className="text-[11px] font-bold text-rose-300 uppercase tracking-wider flex items-center gap-1 mb-1">
              <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
              Primary Vulnerability & Risk Window
            </span>
            <p className="text-xs text-rose-200 leading-snug">
              {activeStage.vulnerability}
            </p>
          </div>
        </div>

        {/* Filter for Preventative Action Categories */}
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs font-bold text-slate-400 flex items-center gap-1.5">
              <Filter className="w-3.5 h-3.5 text-emerald-400" />
              Filter Interventions:
            </span>
            {[
              { label: "All Interventions", value: "all" },
              { label: "Organic / Bio-Control", value: "organic" },
              { label: "Chemical Prophylactic", value: "chemical" },
              { label: "Cultural / Staking", value: "cultural" },
              { label: "Fertigation / Soil", value: "fertigation" },
            ].map((f) => (
              <button
                key={f.value}
                onClick={() => setActionFilter(f.value)}
                className={`px-2.5 py-1 text-xs font-semibold rounded-lg transition border ${
                  actionFilter === f.value
                    ? "bg-emerald-600 text-white border-emerald-500 shadow"
                    : "bg-slate-900 text-slate-400 border-slate-800 hover:text-white"
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>

          <div className="text-xs text-slate-400">
            Showing <strong className="text-emerald-400">{filteredActions.length}</strong> preventative protocols
          </div>
        </div>

        {/* Action Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {filteredActions.map((action, actIdx) => (
            <div
              key={actIdx}
              className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex flex-col justify-between space-y-3 hover:border-slate-700 transition"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <span
                    className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded border ${getActionTypeBadge(
                      action.type
                    )}`}
                  >
                    {action.type}
                  </span>
                  {action.dosage && (
                    <span className="text-[10px] font-mono text-amber-300 bg-amber-950/60 px-1.5 py-0.5 rounded border border-amber-900/60">
                      {action.dosage}
                    </span>
                  )}
                </div>

                <div className="space-y-1">
                  <span className="text-[11px] font-bold text-slate-400 block">
                    Target Threat:{" "}
                    <span className="text-slate-200">{action.targetPathogen}</span>
                  </span>
                  <p className="text-xs text-slate-100 font-sans leading-relaxed">
                    {action.action}
                  </p>
                </div>
              </div>

              {/* Yield Protection Impact */}
              <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs">
                <span className="text-[11px] text-slate-400 flex items-center gap-1">
                  <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
                  Yield Protection:
                </span>
                <span className="text-xs font-bold text-emerald-300 font-mono">
                  {action.yieldBenefit}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Critical Watchout Box for the Stage */}
        <div className="p-4 bg-amber-950/20 border border-amber-800/40 rounded-xl flex items-start gap-3">
          <Info className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <h5 className="text-xs font-bold uppercase tracking-wider text-amber-300">
              Critical Agronomist Watchout for {activeStage.stageName}
            </h5>
            <p className="text-xs text-slate-300 leading-relaxed">
              {activeStage.criticalWatchout}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
