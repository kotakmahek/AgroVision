import React, { useState } from "react";
import { 
  OFFLINE_DISEASE_REGISTRY, 
  generateOfflineDiagnosticReport 
} from "../data/offlineKnowledge";
import { DiagnosticReport, SupportedLanguage } from "../types";
import { 
  Database, 
  X, 
  Trash2, 
  Download, 
  HardDrive, 
  CheckCircle2, 
  Cpu, 
  ExternalLink,
  Search
} from "lucide-react";

interface OfflineCacheModalProps {
  isOpen: boolean;
  onClose: () => void;
  savedReports: DiagnosticReport[];
  onSelectReport: (report: DiagnosticReport) => void;
  onClearHistory: () => void;
  currentLanguage: SupportedLanguage;
}

export const OfflineCacheModal: React.FC<OfflineCacheModalProps> = ({
  isOpen,
  onClose,
  savedReports,
  onSelectReport,
  onClearHistory,
  currentLanguage,
}) => {
  const [activeTab, setActiveTab] = useState<"history" | "registry">("history");
  const [searchFilter, setSearchFilter] = useState("");

  if (!isOpen) return null;

  const handleRunOfflinePreset = (diseaseId: string) => {
    const report = generateOfflineDiagnosticReport(diseaseId, currentLanguage);
    onSelectReport(report);
    onClose();
  };

  const handleExportCache = () => {
    const exportData = {
      app: "AgroVision AI - SIH Edge Database",
      version: "2.5-Edge",
      exportedAt: new Date().toISOString(),
      offlineRegistryCount: OFFLINE_DISEASE_REGISTRY.length,
      userScansCount: savedReports.length,
      userScans: savedReports,
      preloadedRegistry: OFFLINE_DISEASE_REGISTRY,
    };

    const blob = new Blob([JSON.stringify(exportData, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `AgroVision_Offline_Database_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const filteredRegistry = OFFLINE_DISEASE_REGISTRY.filter(
    (e) =>
      e.cropName.toLowerCase().includes(searchFilter.toLowerCase()) ||
      e.diseaseName.toLowerCase().includes(searchFilter.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in text-white">
      <div className="bg-slate-900 border border-emerald-700/60 rounded-2xl w-full max-w-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 bg-gradient-to-r from-emerald-950 via-slate-900 to-slate-900 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-emerald-700 text-white rounded-xl shadow">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                Offline SQLite Cache & Edge Classifier
              </h2>
              <p className="text-xs text-emerald-300">
                Resilient diagnostic storage for zero-connectivity rural farmlands (SIH Edge Spec)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-slate-800 bg-slate-950/60 px-6 pt-3 gap-2">
          <button
            onClick={() => setActiveTab("history")}
            className={`pb-3 px-3 text-xs font-bold border-b-2 transition flex items-center gap-2 ${
              activeTab === "history"
                ? "border-emerald-500 text-emerald-400"
                : "border-transparent text-slate-400 hover:text-slate-200"
            }`}
          >
            <HardDrive className="w-4 h-4" />
            <span>Saved Scans History ({savedReports.length})</span>
          </button>
          <button
            onClick={() => setActiveTab("registry")}
            className={`pb-3 px-3 text-xs font-bold border-b-2 transition flex items-center gap-2 ${
              activeTab === "registry"
                ? "border-emerald-500 text-emerald-400"
                : "border-transparent text-slate-400 hover:text-slate-200"
            }`}
          >
            <Cpu className="w-4 h-4" />
            <span>Preloaded Edge Knowledge Base ({OFFLINE_DISEASE_REGISTRY.length})</span>
          </button>
        </div>

        {/* Body Content */}
        <div className="p-6 overflow-y-auto space-y-4 flex-1">
          {activeTab === "history" ? (
            <div>
              {savedReports.length === 0 ? (
                <div className="text-center py-12 text-slate-500 space-y-2">
                  <Database className="w-12 h-12 mx-auto opacity-40 text-emerald-500" />
                  <p className="text-sm font-medium text-slate-400">No cached diagnostic reports yet.</p>
                  <p className="text-xs max-w-sm mx-auto">
                    Every diagnostic scan you perform is automatically saved locally to your device storage for offline recall in the field.
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
                    <span>Stored Local Records</span>
                    <div className="flex gap-2">
                      <button
                        onClick={handleExportCache}
                        className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded flex items-center gap-1 text-xs"
                      >
                        <Download className="w-3.5 h-3.5 text-emerald-400" />
                        Export JSON
                      </button>
                      <button
                        onClick={onClearHistory}
                        className="px-2.5 py-1 bg-rose-950 hover:bg-rose-900 text-rose-300 rounded flex items-center gap-1 text-xs border border-rose-800"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        Clear
                      </button>
                    </div>
                  </div>

                  <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
                    {savedReports.map((item, idx) => (
                      <div
                        key={item.id || idx}
                        onClick={() => {
                          onSelectReport(item);
                          onClose();
                        }}
                        className="p-3.5 bg-slate-950 border border-slate-800 rounded-xl hover:border-emerald-600/60 cursor-pointer transition flex items-center justify-between gap-3 group"
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          {item.imageUrl ? (
                            <img
                              src={item.imageUrl}
                              alt="Crop leaf"
                              className="w-12 h-12 rounded-lg object-cover bg-black shrink-0 border border-slate-800"
                            />
                          ) : (
                            <div className="w-12 h-12 rounded-lg bg-emerald-950/60 border border-emerald-800/50 flex items-center justify-center shrink-0 text-emerald-400">
                              <Cpu className="w-6 h-6" />
                            </div>
                          )}
                          <div className="min-w-0">
                            <div className="flex items-center gap-2">
                              <h4 className="text-xs font-bold text-white group-hover:text-emerald-300 transition truncate">
                                {item.crop_details?.common_name} — {item.diagnosis?.disease_name}
                              </h4>
                              <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-800 text-slate-400 font-mono">
                                {(item.confidence_score * 100).toFixed(0)}%
                              </span>
                            </div>
                            <p className="text-[11px] text-slate-400 truncate">
                              Severity: {item.diagnosis?.severity_level} • {item.timestamp || "Recent Scan"}
                            </p>
                          </div>
                        </div>
                        <span className="text-xs text-emerald-400 font-medium shrink-0 group-hover:translate-x-1 transition">
                          View →
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="space-y-3">
              <div className="flex items-center justify-between gap-3 mb-2">
                <p className="text-xs text-slate-400">
                  Built-in offline agricultural pathology knowledge base for top Indian commercial crops:
                </p>
                <div className="relative w-48">
                  <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2 top-2" />
                  <input
                    type="text"
                    placeholder="Search crops..."
                    value={searchFilter}
                    onChange={(e) => setSearchFilter(e.target.value)}
                    className="w-full pl-7 pr-2 py-1 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-emerald-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-80 overflow-y-auto pr-1">
                {filteredRegistry.map((item) => (
                  <div
                    key={item.id}
                    className="p-3.5 bg-slate-950 border border-slate-800 rounded-xl space-y-2 flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-emerald-300">{item.cropName}</span>
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800">
                          {item.condition}
                        </span>
                      </div>
                      <h5 className="text-sm font-semibold text-white mt-0.5">{item.diseaseName}</h5>
                      <p className="text-[11px] text-slate-400 italic font-mono">{item.causalAgent}</p>
                    </div>

                    <button
                      onClick={() => handleRunOfflinePreset(item.id)}
                      className="mt-2 w-full py-1.5 px-3 bg-emerald-800/80 hover:bg-emerald-700 text-white text-xs font-semibold rounded-lg transition flex items-center justify-center gap-1.5"
                    >
                      <span>Load Edge Advisory ({currentLanguage})</span>
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex items-center justify-between">
          <span className="text-xs text-slate-500">
            Smart India Hackathon (SIH) Offline-Resilient Diagnostic Mode
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-semibold transition"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
