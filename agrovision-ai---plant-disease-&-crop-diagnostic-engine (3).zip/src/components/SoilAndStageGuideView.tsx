import React, { useState } from "react";
import { 
  CROP_GROWTH_STAGES, 
  NUTRIENT_DEFICIENCY_GUIDES, 
  NutrientDeficiencyGuide 
} from "../data/communityAndEtlData";
import { 
  Sprout, 
  Layers, 
  Sparkles, 
  AlertCircle, 
  CheckCircle2, 
  Info, 
  Sliders, 
  Leaf, 
  FlaskConical, 
  Droplets,
  ChevronRight
} from "lucide-react";

export const SoilAndStageGuideView: React.FC = () => {
  const [selectedStageIdx, setSelectedStageIdx] = useState<number>(2); // Flowering stage by default (highest risk)
  const [selectedNutrientId, setSelectedNutrientId] = useState<string>("def-nitrogen");
  const [leafZoneFilter, setLeafZoneFilter] = useState<string>("All");

  const currentStage = CROP_GROWTH_STAGES[selectedStageIdx];
  const currentNutrient: NutrientDeficiencyGuide =
    NUTRIENT_DEFICIENCY_GUIDES.find((n) => n.id === selectedNutrientId) || NUTRIENT_DEFICIENCY_GUIDES[0];

  const filteredNutrients = NUTRIENT_DEFICIENCY_GUIDES.filter((n) => {
    if (leafZoneFilter === "All") return true;
    return n.affectedLeafZone === leafZoneFilter;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-br from-emerald-950/90 via-slate-900 to-emerald-950/80 border border-emerald-800/60 rounded-3xl p-6 sm:p-8 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="px-3 py-1 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded-full text-xs font-bold flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-emerald-400" />
                Phenological Risk & Soil Intelligence
              </span>
              <span className="px-2.5 py-0.5 bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded-full text-xs font-semibold">
                Maharashtra Soil Health Protocol
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              Crop Growth Stage & Soil NPK Deficiency Guide
            </h2>
            <p className="text-sm text-slate-300 max-w-2xl leading-relaxed">
              Pathology changes drastically by growth stage. Early Blight or Bollworm during flowering causes 3.2x higher economic damage than vegetative stages. Compare leaf discoloration against classic N-P-K-Zn deficiency symptoms.
            </p>
          </div>

          <div className="flex items-center gap-3 bg-slate-900/80 border border-slate-700/80 p-3.5 rounded-2xl shrink-0">
            <div className="p-2.5 bg-emerald-500/20 rounded-xl border border-emerald-500/30 text-emerald-400">
              <FlaskConical className="w-6 h-6" />
            </div>
            <div>
              <p className="text-xs text-slate-400 font-medium">Nutrient Reference Profiles</p>
              <p className="text-xl font-extrabold text-emerald-300">
                6 Essential Elements
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Part 1: Crop Growth Stage Context & Vulnerability Engine */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-lg space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Sprout className="w-4 h-4 text-emerald-400" />
              1. Crop Growth Stage & Economic Loss Multiplier
            </h3>
            <p className="text-xs text-slate-400">
              Select current stage to see how AI risk models calibrate damage thresholds:
            </p>
          </div>
          <span className="text-xs font-bold text-emerald-400 bg-emerald-950/80 px-3 py-1 rounded-full border border-emerald-800/80">
            Current Stage Multiplier: {currentStage.vulnerabilityMultiplier}x Damage Impact
          </span>
        </div>

        {/* Growth Stages Timeline Selector */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
          {CROP_GROWTH_STAGES.map((stg, idx) => {
            const isSelected = idx === selectedStageIdx;
            return (
              <button
                key={stg.stage}
                onClick={() => setSelectedStageIdx(idx)}
                className={`p-3 rounded-xl text-left border transition-all ${
                  isSelected
                    ? "bg-emerald-950/90 border-emerald-500 ring-2 ring-emerald-500/40 text-white shadow-lg"
                    : "bg-slate-950/60 border-slate-800 hover:border-slate-700 text-slate-300"
                }`}
              >
                <span className="text-[10px] font-mono text-slate-400 block">{stg.durationDays}</span>
                <p className="text-xs font-bold truncate mt-0.5">{stg.stage}</p>
                <div className="mt-2 flex items-center justify-between">
                  <span
                    className={`text-[10px] px-1.5 py-0.5 rounded font-bold ${
                      stg.vulnerabilityMultiplier >= 3
                        ? "bg-rose-500/20 text-rose-300"
                        : stg.vulnerabilityMultiplier >= 2
                        ? "bg-amber-500/20 text-amber-300"
                        : "bg-emerald-500/20 text-emerald-300"
                    }`}
                  >
                    {stg.vulnerabilityLevel}
                  </span>
                  <span className="text-xs font-black font-mono text-emerald-400">
                    {stg.vulnerabilityMultiplier}x
                  </span>
                </div>
              </button>
            );
          })}
        </div>

        {/* Active Stage Impact Card */}
        <div className="p-4 bg-slate-950/80 rounded-xl border border-slate-800 space-y-3">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              Stage Intelligence: {currentStage.stage} ({currentStage.durationDays})
            </h4>
            <span className="text-xs text-amber-400 font-semibold">
              ⚠️ Critical Threats: {currentStage.criticalThreats}
            </span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            {currentStage.guidance}
          </p>
        </div>
      </div>

      {/* Part 2: NPK & Micronutrient Deficiency Visual Overlay */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-lg space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <FlaskConical className="w-4 h-4 text-emerald-400" />
              2. NPK & Micronutrient Deficiency Visual Overlay Guide
            </h3>
            <p className="text-xs text-slate-400">
              Correlate leaf discoloration patterns with soil nutrition deficiencies in Maharashtra soils.
            </p>
          </div>

          {/* Leaf Zone Filter */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400">Affected Leaf Zone:</span>
            <select
              value={leafZoneFilter}
              onChange={(e) => setLeafZoneFilter(e.target.value)}
              className="px-3 py-1.5 bg-slate-800 border border-slate-700 rounded-lg text-xs font-semibold text-slate-200"
            >
              <option value="All">All Leaf Zones</option>
              <option value="Older Lower Leaves">Older Lower Leaves (N, P, K, Mg)</option>
              <option value="Middle Canopy">Middle Canopy (Zn)</option>
              <option value="Young New Leaves / Shoot Tip">Young New Leaves (Fe)</option>
            </select>
          </div>
        </div>

        {/* Nutrients Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
          {filteredNutrients.map((nut) => {
            const isSelected = nut.id === selectedNutrientId;
            return (
              <button
                key={nut.id}
                onClick={() => setSelectedNutrientId(nut.id)}
                className={`p-3 rounded-xl text-left border transition-all ${
                  isSelected
                    ? "bg-slate-800 border-emerald-500 ring-2 ring-emerald-500/40 text-white shadow-lg"
                    : "bg-slate-950/60 border-slate-800 hover:border-slate-700 text-slate-300"
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="w-7 h-7 rounded-lg bg-slate-800 flex items-center justify-center font-bold text-xs text-emerald-400 border border-slate-700">
                    {nut.symbol}
                  </span>
                  <span className="text-[9px] px-1.5 py-0.5 rounded bg-slate-900 text-slate-400 border border-slate-800">
                    {nut.category}
                  </span>
                </div>
                <p className="text-xs font-bold text-white mt-2 truncate">{nut.nutrient}</p>
                <p className="text-[10px] text-slate-400 truncate">{nut.marathiTitle}</p>
              </button>
            );
          })}
        </div>

        {/* Detailed Deficiency Comparison Card */}
        <div className={`p-5 rounded-2xl border ${currentNutrient.bgColor} ${currentNutrient.borderColor} space-y-4`}>
          <div className="flex items-start justify-between flex-wrap gap-3">
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-1 rounded-lg bg-black/40 text-emerald-300 border border-emerald-500/40 font-black text-sm">
                  {currentNutrient.symbol}
                </span>
                <h4 className="text-lg font-black text-white">
                  {currentNutrient.nutrient} — {currentNutrient.marathiTitle}
                </h4>
              </div>
              <p className="text-xs text-slate-300 mt-1 flex items-center gap-1.5">
                <Leaf className="w-3.5 h-3.5 text-emerald-400" />
                Primary Location: <strong>{currentNutrient.affectedLeafZone}</strong>
              </p>
            </div>

            <span className="px-3 py-1 bg-black/50 text-slate-200 border border-slate-700 rounded-full text-xs font-semibold">
              Visual Cue: {currentNutrient.visualCue}
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs pt-2">
            <div className="p-3 bg-black/40 rounded-xl border border-slate-700/50 space-y-1.5">
              <strong className="text-emerald-400 block text-xs">Symptom Diagnostic Signs:</strong>
              <p className="text-slate-200 leading-relaxed">{currentNutrient.symptomsEnglish}</p>
              <p className="text-emerald-300/90 text-[11px] pt-1 border-t border-slate-800 font-medium">
                {currentNutrient.symptomsMarathi}
              </p>
            </div>

            <div className="p-3 bg-black/40 rounded-xl border border-slate-700/50 space-y-2">
              <strong className="text-amber-300 block text-xs">Actionable Remedial Protocols:</strong>
              <div className="space-y-1 text-slate-200">
                <p>
                  <span className="text-slate-400 font-bold">Soil Amendment:</span> {currentNutrient.remedySoil}
                </p>
                <p>
                  <span className="text-slate-400 font-bold">Foliar Emergency Spray:</span> {currentNutrient.remedyFoliarSpray}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
