import React, { useState, useRef } from "react";
import { QUICK_TEST_PRESETS, SAMPLE_CROPS, SampleCrop } from "../data/sampleCrops";
import { FIELD_TEST_PRESETS, FieldTestPreset } from "../data/fieldTestSamples";
import { QuickTestPreset, SupportedLanguage } from "../types";
import { ensureJpegDataUrl, fetchImageAsInlineData, getImageSizeKb, compressImage } from "../utils/imageUtils";
import { getRealWorldWeather, POPULAR_AGRI_LOCATIONS, RealWorldWeatherData } from "../utils/weatherService";
import { QuickPresetsSection } from "./QuickPresetsSection";
import { 
  Upload, 
  Camera, 
  Sprout, 
  MapPin, 
  Sparkles, 
  AlertCircle, 
  CheckCircle2, 
  Info,
  Loader2,
  ChevronRight,
  ShieldCheck,
  Zap,
  HelpCircle,
  Thermometer,
  Droplets,
  Plus,
  Trash2,
  Layers,
  FlaskConical,
  CloudSun,
  LocateFixed,
  RefreshCw
} from "lucide-react";

interface UploadScanSectionProps {
  onAnalyze: (payload: {
    imageBase64: string;
    images?: Array<{ dataUrl: string; angleLabel: string }>;
    mimeType: string;
    language: SupportedLanguage;
    region: string;
    cropHint: string;
    location?: string;
    humidity?: number;
    temperature?: number;
    lat?: number;
    lon?: number;
  }) => void;
  isLoading: boolean;
  onOpenCamera: () => void;
  currentLanguage: SupportedLanguage;
  isOfflineMode: boolean;
}

const INDIAN_STATES = [
  "General India (National Standard)",
  "Punjab & Haryana (North Indo-Gangetic)",
  "Maharashtra (Western Ghats & Deccan)",
  "Uttar Pradesh & Bihar (Central Plains)",
  "Tamil Nadu & Kerala (Southern Humid)",
  "Andhra Pradesh & Telangana (Krishna-Godavari)",
  "Gujarat (Saurashtra & Coastal)",
  "Madhya Pradesh & Chhattisgarh (Malwa)",
  "Rajasthan (Arid & Semi-Arid)",
  "West Bengal & Assam (Eastern Humid)",
  "Karnataka (Southern Plateau)",
];

const ANGLE_LABELS = [
  "Affected Leaf (Top Surface)",
  "Leaf Underside / Abaxial",
  "Whole Plant / Canopy Overview",
  "Stem / Node / Fruit Close-Up",
];

export const UploadScanSection: React.FC<UploadScanSectionProps> = ({
  onAnalyze,
  isLoading,
  onOpenCamera,
  currentLanguage,
  isOfflineMode,
}) => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [selectedMime, setSelectedMime] = useState<string>("image/jpeg");
  const [extraImages, setExtraImages] = useState<Array<{ dataUrl: string; angleLabel: string }>>([]);
  const [region, setRegion] = useState<string>("Maharashtra (Western Ghats & Deccan)");
  const [growthStage, setGrowthStage] = useState<string>("Flowering & Squaring (55-85 days - Critical Peak)");
  const [cropHint, setCropHint] = useState<string>("");
  const [dragOver, setDragOver] = useState<boolean>(false);
  const [selectedPreset, setSelectedPreset] = useState<QuickTestPreset | null>(null);
  const [selectedFieldPreset, setSelectedFieldPreset] = useState<FieldTestPreset | null>(null);
  const [presetCategoryTab, setPresetCategoryTab] = useState<"field_benchmarks" | "standard">("field_benchmarks");
  
  // Real-world weather integration state
  const [realWeather, setRealWeather] = useState<RealWorldWeatherData | null>(null);
  const [isFetchingWeather, setIsFetchingWeather] = useState<boolean>(false);
  const [selectedCoords, setSelectedCoords] = useState<{ lat: number; lon: number } | null>(null);

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const extraFileInputRef = useRef<HTMLInputElement | null>(null);

  const fetchLiveWeather = async (lat: number, lon: number, locationName?: string) => {
    setIsFetchingWeather(true);
    setSelectedCoords({ lat, lon });
    try {
      const weather = await getRealWorldWeather(lat, lon);
      if (locationName) {
        weather.cityName = locationName;
      }
      setRealWeather(weather);
    } catch (err) {
      console.error("Failed to fetch live real-world weather:", err);
    } finally {
      setIsFetchingWeather(false);
    }
  };

  const handleFetchGpsWeather = () => {
    if (typeof navigator === "undefined" || !navigator.geolocation) {
      const hub = POPULAR_AGRI_LOCATIONS[0];
      fetchLiveWeather(hub.lat, hub.lon, hub.name);
      return;
    }
    setIsFetchingWeather(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        fetchLiveWeather(pos.coords.latitude, pos.coords.longitude);
      },
      (err) => {
        console.warn("Geolocation unavailable or denied, falling back to regional hub:", err);
        const hub = POPULAR_AGRI_LOCATIONS[0];
        fetchLiveWeather(hub.lat, hub.lon, hub.name);
      },
      { timeout: 8000 }
    );
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedPreset(null);
      setSelectedFieldPreset(null);
      processFile(file);
    }
  };

  const handleExtraFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      try {
        // Compress large camera image before adding to extra images
        const compressed = await compressImage(file, 1280);
        const nextAngle = ANGLE_LABELS[Math.min(extraImages.length + 1, ANGLE_LABELS.length - 1)];
        setExtraImages((prev) => [...prev, { dataUrl: compressed, angleLabel: nextAngle }].slice(0, 3));
      } catch (err) {
        console.warn("compressImage fallback for secondary angle:", err);
        const reader = new FileReader();
        reader.onload = async (ev) => {
          if (ev.target?.result) {
            const raw = ev.target.result as string;
            const rasterized = await ensureJpegDataUrl(raw);
            const nextAngle = ANGLE_LABELS[Math.min(extraImages.length + 1, ANGLE_LABELS.length - 1)];
            setExtraImages((prev) => [...prev, { dataUrl: rasterized, angleLabel: nextAngle }].slice(0, 3));
          }
        };
        reader.readAsDataURL(file);
      }
    }
  };

  const removeExtraImage = (idx: number) => {
    setExtraImages((prev) => prev.filter((_, i) => i !== idx));
  };

  const processFile = async (file: File) => {
    if (!file.type.startsWith("image/")) {
      alert("Please upload a valid image file (JPEG, PNG, WEBP).");
      return;
    }
    setSelectedPreset(null);
    setSelectedFieldPreset(null);
    setSelectedMime("image/jpeg");

    try {
      // BUG-04: Compress large 1080p, 4K, or 10MB mobile camera files before base64 upload
      const compressed = await compressImage(file, 1280);
      setSelectedImage(compressed);
    } catch (err) {
      console.warn("compressImage fallback, using ensureJpegDataUrl:", err);
      const reader = new FileReader();
      reader.onload = async (e) => {
        if (e.target?.result) {
          const raw = e.target.result as string;
          const rasterized = await ensureJpegDataUrl(raw);
          setSelectedImage(rasterized);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      setSelectedPreset(null);
      setSelectedFieldPreset(null);
      processFile(file);
    }
  };

  const handleSelectQuickPreset = async (preset: QuickTestPreset) => {
    setSelectedFieldPreset(null);
    setSelectedPreset(preset);
    setExtraImages([]);
    setCropHint(`${preset.samplePayload.crop} - ${preset.diseaseName} (${preset.marathiName})`);
    setRegion("Maharashtra (Western Ghats & Deccan)");
    try {
      const inline = await fetchImageAsInlineData(preset.image);
      setSelectedMime(inline.inlineData.mimeType);
      setSelectedImage(`data:${inline.inlineData.mimeType};base64,${inline.inlineData.data}`);
    } catch {
      const rasterized = await ensureJpegDataUrl(preset.image);
      setSelectedMime("image/jpeg");
      setSelectedImage(rasterized);
    }
  };

  const handleSelectFieldPreset = async (preset: FieldTestPreset) => {
    setSelectedPreset(null);
    setSelectedFieldPreset(preset);
    setCropHint(`${preset.simulatedPayload.crop} - ${preset.expectedCondition} (${preset.cropMarathi})`);
    setRegion("Maharashtra (Western Ghats & Deccan)");
    setGrowthStage(preset.simulatedPayload.growthStage);
    
    try {
      const inline = await fetchImageAsInlineData(preset.primaryImage);
      setSelectedMime(inline.inlineData.mimeType);
      setSelectedImage(`data:${inline.inlineData.mimeType};base64,${inline.inlineData.data}`);
    } catch {
      const rasterized = await ensureJpegDataUrl(preset.primaryImage);
      setSelectedMime("image/jpeg");
      setSelectedImage(rasterized);
    }

    if (preset.additionalAngles && preset.additionalAngles.length > 0) {
      const loadedExtras: Array<{ dataUrl: string; angleLabel: string }> = [];
      for (const angle of preset.additionalAngles) {
        try {
          const inline = await fetchImageAsInlineData(angle.image);
          loadedExtras.push({
            dataUrl: `data:${inline.inlineData.mimeType};base64,${inline.inlineData.data}`,
            angleLabel: angle.label,
          });
        } catch {
          const raster = await ensureJpegDataUrl(angle.image);
          loadedExtras.push({
            dataUrl: raster,
            angleLabel: angle.label,
          });
        }
      }
      setExtraImages(loadedExtras);
    } else {
      setExtraImages([]);
    }
  };

  const handleSelectSample = async (sample: SampleCrop) => {
    setSelectedPreset(null);
    setSelectedFieldPreset(null);
    setExtraImages([]);
    setCropHint(sample.crop);
    setSelectedMime("image/jpeg");
    const rasterized = await ensureJpegDataUrl(sample.imageUrl);
    setSelectedImage(rasterized);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedImage) return;

    // Prepare main image
    const readyImage = await ensureJpegDataUrl(selectedImage);
    const combinedHint = [
      cropHint.trim(),
      `Growth Stage: ${growthStage}`,
      selectedFieldPreset ? `Field Protocol: ${selectedFieldPreset.groundTruthSource}` : null,
    ].filter(Boolean).join(" | ");

    // Prepare multi-image array
    const allImages: Array<{ dataUrl: string; angleLabel: string }> = [
      { dataUrl: readyImage, angleLabel: ANGLE_LABELS[0] },
      ...extraImages,
    ];

    onAnalyze({
      imageBase64: readyImage,
      images: allImages,
      mimeType: "image/jpeg",
      language: currentLanguage,
      region,
      cropHint: combinedHint,
      location: realWeather?.cityName || selectedFieldPreset?.simulatedPayload.location || selectedPreset?.samplePayload.location,
      humidity: realWeather?.humidity ?? selectedFieldPreset?.simulatedPayload.humidity ?? selectedPreset?.samplePayload.humidity,
      temperature: realWeather?.temp ?? selectedFieldPreset?.simulatedPayload.temperature ?? selectedPreset?.samplePayload.temperature,
      lat: selectedCoords?.lat,
      lon: selectedCoords?.lon,
    });
  };

  return (
    <div className="max-w-4xl mx-auto my-6 space-y-6">
      {/* Informative Welcome Banner tailored for Indian Farming Conditions & SIH */}
      <div className="bg-gradient-to-br from-emerald-950/90 via-slate-900 to-emerald-950/70 border border-emerald-800/60 rounded-3xl p-6 sm:p-8 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 space-y-4">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="px-3 py-1 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded-full text-xs font-bold flex items-center gap-1.5 shadow-sm">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              Smart India Hackathon (SIH) Standard
            </span>
            <span className="px-3 py-1 bg-slate-800/80 text-slate-300 border border-slate-700/60 rounded-full text-xs font-medium">
              Grounded in ICAR & PlantDoc Research
            </span>
            <span className="px-3 py-1 bg-sky-500/20 text-sky-300 border border-sky-500/40 rounded-full text-xs font-medium">
              Multi-Angle Screening Active
            </span>
            {isOfflineMode && (
              <span className="px-3 py-1 bg-amber-500/20 text-amber-300 border border-amber-500/40 rounded-full text-xs font-semibold">
                Offline Classification Active
              </span>
            )}
          </div>

          <div className="space-y-2">
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black text-white tracking-tight font-['Outfit',sans-serif]">
              AI-Assisted Crop Disease & <span className="text-emerald-400">Pest Screening</span>
            </h2>
            <p className="text-slate-300 text-sm sm:text-base max-w-2xl leading-relaxed">
              Upload real field photographs from multiple angles (leaf surface, underside, canopy). Visual screening is verified against ICAR compendiums with explicit quality checks and low-confidence thresholds.
            </p>
          </div>

          {/* Core Workflow Checklist */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
            <div className="p-3 bg-slate-950/60 border border-emerald-900/40 rounded-xl flex items-start gap-2 text-xs text-slate-300">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span>
                <strong className="text-emerald-200 block">1. Quality & Crop Check</strong>
                Filters out blur, glare & non-crop images
              </span>
            </div>
            <div className="p-3 bg-slate-950/60 border border-emerald-900/40 rounded-xl flex items-start gap-2 text-xs text-slate-300">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span>
                <strong className="text-emerald-200 block">2. Research-Grounded Screening</strong>
                Cross-referenced with ICAR & PlantDoc
              </span>
            </div>
            <div className="p-3 bg-slate-950/60 border border-emerald-900/40 rounded-xl flex items-start gap-2 text-xs text-slate-300">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span>
                <strong className="text-emerald-200 block">3. Actionable Management</strong>
                CIBRC dosages, KVK dialer & Marathi voice
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Upload / Scan Form */}
      <form onSubmit={handleSubmit} className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
        {/* Upload Zone */}
        <div className="space-y-3">
          <label className="text-sm font-bold text-slate-200 flex items-center justify-between">
            <span className="flex items-center gap-2">
              <Upload className="w-4 h-4 text-emerald-400" />
              Primary Specimen Photograph
            </span>
            <span className="text-xs text-slate-400 font-normal">
              Diffused daylight photo of infected leaf surface
            </span>
          </label>

          <div
            onDragOver={(e) => {
              e.preventDefault();
              setDragOver(true);
            }}
            onDragLeave={() => setDragOver(false)}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`border-2 border-dashed rounded-2xl p-6 sm:p-8 text-center cursor-pointer transition-all duration-200 flex flex-col items-center justify-center min-h-[220px] ${
              dragOver
                ? "border-emerald-400 bg-emerald-950/40"
                : selectedImage
                ? "border-emerald-600/70 bg-emerald-950/20"
                : "border-slate-700 hover:border-emerald-500/60 bg-slate-950/60 hover:bg-slate-950"
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleFileChange}
            />

            {selectedImage ? (
              <div className="space-y-3">
                <div className="relative inline-block">
                  <img
                    src={selectedImage}
                    alt="Selected leaf"
                    className="max-h-48 max-w-xs object-contain rounded-xl border border-emerald-500/40 shadow-md bg-black"
                  />
                  <div className="absolute top-2 right-2 bg-emerald-600 text-white p-1 rounded-full shadow">
                    <CheckCircle2 className="w-4 h-4" />
                  </div>
                  <div className="absolute bottom-2 left-2 flex items-center gap-1.5 flex-wrap">
                    <span className="bg-black/85 px-2 py-0.5 rounded text-[10px] text-emerald-300 font-medium border border-emerald-900/60">
                      {ANGLE_LABELS[0]}
                    </span>
                    <span className="bg-black/85 px-2 py-0.5 rounded text-[10px] text-slate-300 font-mono border border-slate-800">
                      {getImageSizeKb(selectedImage)} KB • 3G/4G Fast Uplink
                    </span>
                  </div>
                </div>
                <p className="text-xs text-emerald-300 font-medium">
                  Primary photo loaded. Click to replace or add secondary angles below.
                </p>
              </div>
            ) : (
              <div className="space-y-3 max-w-sm mx-auto">
                <div className="w-14 h-14 rounded-2xl bg-emerald-950/80 border border-emerald-700/50 flex items-center justify-center mx-auto text-emerald-400 shadow-inner">
                  <Upload className="w-7 h-7" />
                </div>
                <div>
                  <p className="text-sm font-bold text-slate-200">
                    Drag and drop leaf photo, or <span className="text-emerald-400 underline">browse device</span>
                  </p>
                  <p className="text-xs text-slate-400 mt-1">
                    Supports JPG, PNG, WEBP outdoor field photos
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Multi-Angle Image Strip (Allows up to 3 additional angles) */}
          <div className="p-4 bg-slate-950/70 border border-slate-800 rounded-2xl space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-emerald-400" />
                Multi-Angle Field Scouting (Recommended for 18% Higher Field Accuracy)
              </span>
              <span className="text-[11px] text-slate-400">
                {1 + extraImages.length}/4 Photos
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {/* Primary angle card */}
              <div className="p-2 bg-slate-900 border border-emerald-700/60 rounded-xl space-y-1.5 text-center">
                <span className="text-[10px] font-bold text-emerald-400 block truncate">
                  1. Leaf Top (Primary)
                </span>
                {selectedImage ? (
                  <img src={selectedImage} alt="Angle 1" className="h-20 w-full object-cover rounded-lg bg-black" />
                ) : (
                  <div className="h-20 w-full rounded-lg bg-slate-950 border border-dashed border-slate-800 flex items-center justify-center text-[10px] text-slate-500">
                    Required
                  </div>
                )}
              </div>

              {/* Extra images */}
              {extraImages.map((extra, idx) => (
                <div key={idx} className="p-2 bg-slate-900 border border-slate-700 rounded-xl space-y-1.5 text-center relative group">
                  <div className="flex items-center justify-between text-[10px] font-bold text-slate-300">
                    <span className="truncate">{idx + 2}. {extra.angleLabel.split(" ")[0]}</span>
                    <button
                      type="button"
                      onClick={() => removeExtraImage(idx)}
                      className="text-slate-500 hover:text-rose-400 p-0.5 transition"
                      title="Remove angle"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                  <img src={extra.dataUrl} alt={`Angle ${idx + 2}`} className="h-20 w-full object-cover rounded-lg bg-black" />
                </div>
              ))}

              {/* Add extra angle button */}
              {extraImages.length < 3 && (
                <button
                  type="button"
                  onClick={() => extraFileInputRef.current?.click()}
                  className="h-28 rounded-xl border-2 border-dashed border-slate-800 hover:border-emerald-600/60 bg-slate-950 hover:bg-slate-900/80 flex flex-col items-center justify-center gap-1.5 transition text-slate-400 hover:text-emerald-300"
                >
                  <input
                    ref={extraFileInputRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handleExtraFileChange}
                  />
                  <Plus className="w-5 h-5 text-emerald-400" />
                  <span className="text-[11px] font-bold">Add Another Angle</span>
                  <span className="text-[9px] text-slate-500">Underside / Canopy</span>
                </button>
              )}
            </div>
          </div>

          {/* Active Preset Metadata Banner */}
          {(selectedFieldPreset || selectedPreset) && (
            <div className="p-3 bg-emerald-950/80 border border-emerald-500/40 rounded-2xl flex items-center justify-between flex-wrap gap-2 text-xs animate-in fade-in duration-200">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="px-2 py-0.5 rounded text-[11px] font-bold text-white bg-emerald-700">
                  {selectedFieldPreset ? selectedFieldPreset.fieldConditionTag : selectedPreset?.category}
                </span>
                <span className="text-slate-200">
                  Selected Preset: <strong className="text-emerald-300">{selectedFieldPreset?.cropEnglish || selectedPreset?.cropName}</strong> — {selectedFieldPreset?.expectedCondition || selectedPreset?.diseaseName}
                </span>
                <span className="text-emerald-400 font-bold">({selectedFieldPreset?.cropMarathi || selectedPreset?.marathiName})</span>
              </div>
              <div className="flex items-center gap-3 text-slate-300 text-[11px] font-medium">
                <span className="flex items-center gap-1 text-slate-200">
                  <MapPin className="w-3.5 h-3.5 text-emerald-400" />
                  {selectedFieldPreset?.simulatedPayload.location || selectedPreset?.samplePayload.location}
                </span>
                <span className="flex items-center gap-1 text-sky-300">
                  <Droplets className="w-3.5 h-3.5 text-sky-400" />
                  {selectedFieldPreset?.simulatedPayload.humidity || selectedPreset?.samplePayload.humidity}% RH
                </span>
                <span className="flex items-center gap-1 text-amber-300">
                  <Thermometer className="w-3.5 h-3.5 text-amber-400" />
                  {selectedFieldPreset?.simulatedPayload.temperature || selectedPreset?.samplePayload.temperature}°C
                </span>
              </div>
            </div>
          )}

          {/* Quick Action: Live Camera Snapshot */}
          <div className="flex items-center justify-center pt-1">
            <button
              id="open-field-camera-btn"
              type="button"
              onClick={onOpenCamera}
              className="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-emerald-300 rounded-xl text-xs font-bold border border-emerald-700/50 shadow-sm flex items-center gap-2 transition hover:scale-[1.02]"
            >
              <Camera className="w-4 h-4 text-emerald-400" />
              <span>Use Live Field Camera Scanner</span>
            </button>
          </div>
        </div>

        {/* Preset Selector with Field Benchmarks */}
        <div className="pt-2 border-t border-slate-800 space-y-3">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-200">Evaluation Test Suites:</span>
              <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs font-semibold">
                <button
                  type="button"
                  onClick={() => setPresetCategoryTab("field_benchmarks")}
                  className={`px-3 py-1 rounded-lg transition ${presetCategoryTab === "field_benchmarks" ? "bg-emerald-600 text-white" : "text-slate-400 hover:text-white"}`}
                >
                  Real-World Outdoor Field Presets ({FIELD_TEST_PRESETS.length})
                </button>
                <button
                  type="button"
                  onClick={() => setPresetCategoryTab("standard")}
                  className={`px-3 py-1 rounded-lg transition ${presetCategoryTab === "standard" ? "bg-emerald-600 text-white" : "text-slate-400 hover:text-white"}`}
                >
                  Standard Lab Presets ({QUICK_TEST_PRESETS.length})
                </button>
              </div>
            </div>
            
            <button
              type="button"
              onClick={() => handleSelectSample(SAMPLE_CROPS.find(s => s.isInvalidTest) || SAMPLE_CROPS[0])}
              className="text-[11px] text-slate-400 hover:text-rose-400 transition underline underline-offset-2"
              title="Test system rejection with non-agricultural photo"
            >
              Non-Crop Rejection Test
            </button>
          </div>

          {/* Field Benchmarks Grid */}
          {presetCategoryTab === "field_benchmarks" ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {FIELD_TEST_PRESETS.map((fp) => {
                const isSelected = selectedFieldPreset?.id === fp.id;
                return (
                  <div
                    key={fp.id}
                    onClick={() => handleSelectFieldPreset(fp)}
                    className={`p-3 rounded-2xl border cursor-pointer transition text-left space-y-2 ${
                      isSelected
                        ? "bg-emerald-950/70 border-emerald-500 shadow-md"
                        : "bg-slate-950/60 border-slate-800 hover:border-slate-700 hover:bg-slate-950"
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-900 text-emerald-300 border border-slate-800">
                        {fp.cropEnglish} ({fp.cropMarathi})
                      </span>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                        fp.expectedOutcome.includes("Rejection")
                          ? "bg-rose-500/20 text-rose-300 border border-rose-500/30"
                          : fp.expectedOutcome.includes("Low-Confidence")
                          ? "bg-amber-500/20 text-amber-300 border border-amber-500/30"
                          : "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
                      }`}>
                        {fp.expectedOutcome}
                      </span>
                    </div>

                    <div>
                      <h4 className="text-xs font-bold text-white line-clamp-1">
                        {fp.title}
                      </h4>
                      <p className="text-[10px] text-slate-400 line-clamp-1 mt-0.5">
                        {fp.lightingCondition}
                      </p>
                    </div>

                    <div className="flex items-center justify-between text-[10px] text-slate-500 pt-1 border-t border-slate-800/60">
                      <span>Source: {fp.groundTruthSource.split(" ")[0]}</span>
                      <span className="text-emerald-400 font-semibold">Click to Test</span>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <QuickPresetsSection
              onSelectPreset={handleSelectQuickPreset}
              selectedPresetId={selectedPreset?.id}
            />
          )}
        </div>

        {/* Agricultural Context (Region, Growth Stage, & Crop Hint) */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2 border-t border-slate-800">
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-emerald-400" />
              Agro-Climatic State
            </label>
            <select
              value={region}
              onChange={(e) => setRegion(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-400 transition"
            >
              {INDIAN_STATES.map((st) => (
                <option key={st} value={st} className="bg-slate-900">
                  {st}
                </option>
              ))}
            </select>
            <p className="text-[10px] text-slate-500">
              Calibrates regional weather & ICAR limits.
            </p>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
              <Sprout className="w-3.5 h-3.5 text-emerald-400" />
              Crop Growth Stage
            </label>
            <select
              value={growthStage}
              onChange={(e) => setGrowthStage(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-400 transition"
            >
              <option value="Sowing & Seedling (0-25 days)">Sowing & Seedling (0-25d)</option>
              <option value="Vegetative Growth (25-55 days)">Vegetative Growth (25-55d)</option>
              <option value="Flowering & Squaring (55-85 days - Critical Peak)">Flowering & Squaring (55-85d, 3.2x Risk)</option>
              <option value="Boll / Pod / Grain Formation (85-120 days)">Boll / Pod Formation (85-120d, 2.5x Risk)</option>
              <option value="Maturity & Pre-Harvest (120+ days)">Maturity & Pre-Harvest (120+d)</option>
            </select>
            <p className="text-[10px] text-slate-500">
              Calibrates economic vulnerability multiplier.
            </p>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
              <Sprout className="w-3.5 h-3.5 text-emerald-400" />
              Crop Hint / Notes (Optional)
            </label>
            <input
              type="text"
              placeholder="e.g. Cotton, Soybean, Paddy"
              value={cropHint}
              onChange={(e) => setCropHint(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-emerald-400 transition"
            />
            <p className="text-[10px] text-slate-500">
              Optional farmer field observation.
            </p>
          </div>
        </div>

        {/* Real-World Field Weather Integration (Pre-Screening Feed) */}
        <div className="bg-slate-950/80 border border-sky-900/40 rounded-2xl p-4 space-y-3">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div className="flex items-center gap-2">
              <div className="p-1.5 rounded-lg bg-sky-950 border border-sky-800/60 text-sky-400">
                <CloudSun className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                  Real-World Field Weather Feed
                  <span className="px-2 py-0.5 rounded-full bg-sky-500/10 text-sky-400 border border-sky-500/20 text-[10px] font-medium">
                    Pre-Screening Input
                  </span>
                </h4>
                <p className="text-[10px] text-slate-400">
                  Fetch live temperature & humidity to calibrate spore germination & pest outbreak risk before calling Gemini AI.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleFetchGpsWeather}
                disabled={isFetchingWeather}
                className="px-3 py-1.5 rounded-xl bg-sky-600/20 hover:bg-sky-600/30 text-sky-300 border border-sky-500/30 text-xs font-semibold flex items-center gap-1.5 transition disabled:opacity-50"
              >
                {isFetchingWeather ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <LocateFixed className="w-3.5 h-3.5 text-sky-400" />
                )}
                <span>Detect Live GPS Weather</span>
              </button>
            </div>
          </div>

          {/* Quick Regional Agricultural Hub Selector */}
          <div className="flex items-center gap-2 flex-wrap text-xs pt-1">
            <span className="text-[11px] text-slate-400 font-medium">Or select agricultural hub:</span>
            <div className="flex items-center gap-1.5 flex-wrap">
              {POPULAR_AGRI_LOCATIONS.map((loc) => (
                <button
                  key={loc.name}
                  type="button"
                  onClick={() => fetchLiveWeather(loc.lat, loc.lon, loc.name)}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-medium border transition ${
                    realWeather?.cityName.includes(loc.name) || selectedCoords?.lat === loc.lat
                      ? "bg-sky-600 text-white border-sky-500 shadow-sm"
                      : "bg-slate-900/80 text-slate-300 border-slate-800 hover:border-slate-700 hover:text-white"
                  }`}
                >
                  {loc.name}
                </button>
              ))}
            </div>
          </div>

          {/* Real-World Weather Display Card */}
          {realWeather && (
            <div className="mt-2 bg-gradient-to-r from-sky-950/40 via-slate-900/60 to-emerald-950/30 border border-sky-800/40 rounded-xl p-3 flex items-center justify-between flex-wrap gap-3">
              <div className="flex items-center gap-4 flex-wrap">
                <div className="flex items-center gap-1.5">
                  <Thermometer className="w-4 h-4 text-amber-400" />
                  <span className="text-xs font-semibold text-slate-300">Temp:</span>
                  <span className="text-xs font-bold text-amber-300">{realWeather.temp}°C</span>
                </div>

                <div className="flex items-center gap-1.5">
                  <Droplets className="w-4 h-4 text-sky-400" />
                  <span className="text-xs font-semibold text-slate-300">Humidity:</span>
                  <span className="text-xs font-bold text-sky-300">{realWeather.humidity}% RH</span>
                </div>

                <div className="flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-xs font-medium text-slate-300">{realWeather.cityName}</span>
                </div>

                <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">
                  {realWeather.source || "Live Feed"}
                </span>
              </div>

              <div className="text-[10px] font-semibold">
                {realWeather.humidity >= 80 ? (
                  <span className="text-amber-400 flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5" /> High humidity: Elevated spore germination risk (&gt;80% RH)
                  </span>
                ) : (
                  <span className="text-emerald-400 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Favorable microclimate baseline active
                  </span>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Submit Button & Scanning State */}
        <div className="pt-4 border-t border-slate-800">
          <button
            id="run-crop-analysis-btn"
            type="submit"
            disabled={!selectedImage || isLoading}
            className={`w-full py-3.5 px-6 rounded-2xl font-bold text-sm text-white shadow-xl flex items-center justify-center gap-2.5 transition ${
              !selectedImage || isLoading
                ? "bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700"
                : "bg-emerald-600 hover:bg-emerald-500 shadow-emerald-950/80 hover:scale-[1.01]"
            }`}
          >
            {isLoading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin text-emerald-300" />
                <span>Screening Crop via ICAR Grounded Engine...</span>
              </>
            ) : (
              <>
                <Zap className="w-5 h-5 text-amber-300" />
                <span>
                  Screen Crop Specimen ({extraImages.length > 0 ? `${1 + extraImages.length} Angles` : "1 Photo"} • {currentLanguage})
                </span>
                <ChevronRight className="w-4 h-4 ml-1" />
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};
