import React, { useState, useEffect } from "react";
import {
  Volume2,
  VolumeX,
  Play,
  Square,
  Pause,
  RotateCcw,
  Sliders,
  CheckCircle2,
  Radio,
  Mic,
} from "lucide-react";
import { speechEngine } from "../utils/speechEngine";

interface MarathiSpeechPlayerProps {
  marathiScript: string;
  defaultLangCode?: string;
  title?: string;
  subTitle?: string;
  variant?: "banner" | "compact" | "card";
  className?: string;
}

export const MarathiSpeechPlayer: React.FC<MarathiSpeechPlayerProps> = ({
  marathiScript,
  defaultLangCode = "mr-IN",
  title = "मराठी ऑडिओ सल्लागार (AgroVision Voice Advisory)",
  subTitle = "शेतकऱ्यांसाठी पीक संरक्षण व फवारणी मार्गदर्शन (Web Speech Engine)",
  variant = "card",
  className = "",
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [rate, setRate] = useState<number>(0.9); // default slow pace for field clarity
  const [pitch, setPitch] = useState<number>(1.0);
  const [activeVoiceName, setActiveVoiceName] = useState<string>("");
  const [isSupported, setIsSupported] = useState(true);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    setIsSupported(speechEngine.isSupported());
    
    // Check available Marathi/Hindi voice
    const checkVoice = () => {
      const voice = speechEngine.findBestMarathiVoice();
      if (voice) {
        setActiveVoiceName(voice.name);
      }
    };

    checkVoice();
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      window.speechSynthesis.addEventListener("voiceschanged", checkVoice);
    }

    return () => {
      speechEngine.stop();
      if (typeof window !== "undefined" && "speechSynthesis" in window) {
        window.speechSynthesis.removeEventListener("voiceschanged", checkVoice);
      }
    };
  }, []);

  const handlePlayToggle = () => {
    if (!marathiScript || marathiScript.trim().length === 0) return;

    if (isPlaying) {
      if (isPaused) {
        speechEngine.resume();
        setIsPaused(false);
      } else {
        speechEngine.pause();
        setIsPaused(true);
      }
      return;
    }

    speechEngine.speak(marathiScript, defaultLangCode, {
      rate,
      pitch,
      onStart: () => {
        setIsPlaying(true);
        setIsPaused(false);
      },
      onEnd: () => {
        setIsPlaying(false);
        setIsPaused(false);
      },
      onError: (err) => {
        console.error("Speech playback error:", err);
        setIsPlaying(false);
        setIsPaused(false);
      },
      onPause: () => setIsPaused(true),
      onResume: () => setIsPaused(false),
    });
  };

  const handleStop = () => {
    speechEngine.stop();
    setIsPlaying(false);
    setIsPaused(false);
  };

  const handleCopyScript = () => {
    navigator.clipboard.writeText(marathiScript);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (!isSupported) {
    return (
      <div className="p-3 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-400 flex items-center gap-2">
        <VolumeX className="w-4 h-4 text-slate-500" />
        <span>Web Speech API is not available on this browser.</span>
      </div>
    );
  }

  // Compact Pill Button Variant (for embedding into alert banners)
  if (variant === "compact") {
    return (
      <div className={`inline-flex items-center gap-2 ${className}`}>
        <button
          onClick={handlePlayToggle}
          className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 shadow ${
            isPlaying && !isPaused
              ? "bg-rose-600 hover:bg-rose-500 text-white animate-pulse"
              : "bg-emerald-600 hover:bg-emerald-500 text-white"
          }`}
          title={isPlaying && !isPaused ? "Pause Audio" : "Play Marathi Voice"}
        >
          {isPlaying && !isPaused ? (
            <Pause className="w-3.5 h-3.5 fill-current" />
          ) : (
            <Volume2 className="w-3.5 h-3.5" />
          )}
          <span>{isPlaying && !isPaused ? "थांबवा" : "मराठी ऑडिओ ऐका"}</span>
        </button>

        {isPlaying && (
          <button
            onClick={handleStop}
            className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs"
            title="Stop Speech"
          >
            <Square className="w-3 h-3 fill-current" />
          </button>
        )}
      </div>
    );
  }

  // Full High-Performance Audio Console Variant
  return (
    <div
      className={`bg-gradient-to-r from-slate-950 via-slate-900 to-emerald-950/80 border border-emerald-600/50 rounded-2xl p-4 sm:p-5 shadow-xl space-y-3.5 ${className}`}
    >
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2.5 border-b border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className={`p-2 rounded-xl border ${
            isPlaying && !isPaused
              ? "bg-emerald-500/20 border-emerald-400 text-emerald-300"
              : "bg-slate-800/80 border-slate-700 text-slate-300"
          }`}>
            <Volume2 className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs sm:text-sm font-bold text-white tracking-tight flex items-center gap-1.5">
                {title}
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-800 font-mono font-bold">
                mr-IN
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-medium">
              {subTitle}
            </p>
          </div>
        </div>

        {/* Status indicator badge */}
        <div className="flex items-center gap-2">
          {isPlaying && (
            <div className="flex items-center gap-1.5 px-2.5 py-1 bg-emerald-950/80 rounded-full border border-emerald-600/50 text-[11px] text-emerald-300 font-mono">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              <span>{isPaused ? "Paused" : "Speaking Marathi Voice"}</span>
            </div>
          )}
          {activeVoiceName && (
            <span className="text-[10px] text-slate-400 font-mono hidden md:inline truncate max-w-[150px]" title={activeVoiceName}>
              Voice: {activeVoiceName}
            </span>
          )}
        </div>
      </div>

      {/* Spoken Marathi Transcript Text Box */}
      <div className="p-3.5 bg-slate-950/90 rounded-xl border border-slate-800 space-y-2">
        <div className="flex items-center justify-between text-xs text-slate-400">
          <span className="font-semibold text-emerald-400 flex items-center gap-1.5">
            <Radio className="w-3.5 h-3.5" />
            मराठी ध्वनी संदेश (Spoken Audio Script):
          </span>
          <button
            onClick={handleCopyScript}
            className="text-[11px] text-slate-400 hover:text-white transition flex items-center gap-1"
          >
            {copied ? (
              <>
                <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                <span className="text-emerald-400">Copied</span>
              </>
            ) : (
              <span>Copy Script</span>
            )}
          </button>
        </div>
        <p className="text-sm text-slate-100 font-sans leading-relaxed tracking-wide selection:bg-emerald-700">
          "{marathiScript}"
        </p>
      </div>

      {/* Playback Controls & Speed Tuner */}
      <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
        {/* Main Audio Transport Controls */}
        <div className="flex items-center gap-2">
          <button
            id="play-marathi-tts-btn"
            onClick={handlePlayToggle}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 shadow transition ${
              isPlaying && !isPaused
                ? "bg-amber-600 hover:bg-amber-500 text-white"
                : isPaused
                ? "bg-emerald-600 hover:bg-emerald-500 text-white animate-pulse"
                : "bg-emerald-600 hover:bg-emerald-500 text-white"
            }`}
          >
            {isPlaying && !isPaused ? (
              <>
                <Pause className="w-4 h-4 fill-current" />
                <span>थांबवा (Pause)</span>
              </>
            ) : isPaused ? (
              <>
                <Play className="w-4 h-4 fill-current ml-0.5" />
                <span>पुढे चालू ठेवा (Resume)</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-current ml-0.5" />
                <span>ऐका (Play Marathi Audio)</span>
              </>
            )}
          </button>

          {isPlaying && (
            <button
              onClick={handleStop}
              className="p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl text-xs border border-slate-700 transition"
              title="Stop playback"
            >
              <Square className="w-4 h-4 fill-current" />
            </button>
          )}

          <button
            onClick={() => {
              handleStop();
              setTimeout(() => {
                speechEngine.speak(marathiScript, defaultLangCode, {
                  rate,
                  pitch,
                  onStart: () => setIsPlaying(true),
                  onEnd: () => setIsPlaying(false),
                });
              }, 100);
            }}
            className="p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl text-xs border border-slate-700 transition"
            title="Restart playback from beginning"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>

        {/* Speed Adjustment Buttons */}
        <div className="flex items-center gap-2 text-xs">
          <span className="text-slate-400 font-medium">गती (Speed):</span>
          {[0.8, 0.9, 1.0, 1.2].map((s) => (
            <button
              key={s}
              onClick={() => {
                setRate(s);
                if (isPlaying) {
                  // Restart with new rate
                  speechEngine.speak(marathiScript, defaultLangCode, {
                    rate: s,
                    pitch,
                    onStart: () => setIsPlaying(true),
                    onEnd: () => setIsPlaying(false),
                  });
                }
              }}
              className={`px-2.5 py-1 rounded-lg text-xs font-mono font-bold transition border ${
                rate === s
                  ? "bg-emerald-600 text-white border-emerald-500 shadow-sm"
                  : "bg-slate-900 text-slate-400 border-slate-800 hover:text-white"
              }`}
            >
              {s}x
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
