/**
 * Dedicated Real-World Field Test Samples for SIH Demo Mode
 * Represents genuine farm conditions (outdoor sunlight, wind, shadows, complex backgrounds, blur, low-confidence).
 */

export interface FieldTestPreset {
  id: string;
  title: string;
  fieldConditionTag: string;
  cropEnglish: string;
  cropMarathi: string;
  expectedCondition: string;
  expectedOutcome: "High-Confidence Disease Screening" | "Quality Check Rejection" | "Low-Confidence / Needs Expert" | "Healthy Crop Verified";
  lightingCondition: string;
  fieldSetting: string;
  primaryImage: string;
  additionalAngles?: {
    label: string;
    image: string;
  }[];
  groundTruthSource: string;
  simulatedPayload: {
    crop: string;
    location: string;
    humidity: number;
    temperature: number;
    growthStage: string;
  };
}

export const FIELD_TEST_PRESETS: FieldTestPreset[] = [
  {
    id: "field_cotton_pbw",
    title: "Cotton Field: Pink Bollworm (Harsh Sunlight)",
    fieldConditionTag: "Real Outdoor Farm — Yavatmal",
    cropEnglish: "Cotton",
    cropMarathi: "कापूस",
    expectedCondition: "Pink Bollworm Damage (Pectinophora gossypiella)",
    expectedOutcome: "High-Confidence Disease Screening",
    lightingCondition: "Midday direct sunlight with leaf glare and shadows",
    fieldSetting: "Black cotton soil (Vertisol) field, 72 days post-sowing, squaring stage",
    primaryImage: "/assets/presets/cotton_bollworm.jpg",
    groundTruthSource: "ICAR-CICR Cotton Pest Surveillance Protocol (Bulletin 42)",
    simulatedPayload: {
      crop: "Cotton (BT Cotton)",
      location: "Ralegaon, Yavatmal, Maharashtra",
      humidity: 82,
      temperature: 31,
      growthStage: "Flowering & Boll Formation (Critical Stage)",
    },
  },
  {
    id: "field_tomato_early_blight",
    title: "Tomato Field: Early Blight (Outdoor Garden)",
    fieldConditionTag: "Real Outdoor Farm — Nashik",
    cropEnglish: "Tomato",
    cropMarathi: "टोमॅटो",
    expectedCondition: "Early Blight (Alternaria solani)",
    expectedOutcome: "High-Confidence Disease Screening",
    lightingCondition: "Diffused morning sunlight with soil background clutter",
    fieldSetting: "Drip-irrigated open field ridge with mulch and weeds",
    primaryImage: "/assets/presets/tomato_blight.jpg",
    groundTruthSource: "PlantDoc Dataset (IIT Kharagpur Field Benchmark) & PlantVillage",
    simulatedPayload: {
      crop: "Tomato (Abhinav Variety)",
      location: "Dindori, Nashik, Maharashtra",
      humidity: 86,
      temperature: 27,
      growthStage: "Vegetative / Early Fruiting",
    },
  },
  {
    id: "field_soybean_rust",
    title: "Soybean Canopy: Rust Pustules (Lower Foliage)",
    fieldConditionTag: "Real Rainfed Field — Latur",
    cropEnglish: "Soybean",
    cropMarathi: "सोयाबीन",
    expectedCondition: "Asian Soybean Rust (Phakopsora pachyrhizi)",
    expectedOutcome: "High-Confidence Disease Screening",
    lightingCondition: "Overcast monsoon sky with canopy shadow occlusion",
    fieldSetting: "High density canopy planting, lower leaves touching wet soil",
    primaryImage: "/assets/presets/soybean_rust.jpg",
    groundTruthSource: "ICAR-IISR Indore Disease Compendium",
    simulatedPayload: {
      crop: "Soybean (JS-335)",
      location: "Ausa, Latur, Maharashtra",
      humidity: 91,
      temperature: 25,
      growthStage: "Pod Filling Stage (R4-R5)",
    },
  },
  {
    id: "field_rice_blast",
    title: "Paddy Basin: Leaf Blast (Water Reflections)",
    fieldConditionTag: "Flooded Paddy — Bhandara",
    cropEnglish: "Rice / Paddy",
    cropMarathi: "भात",
    expectedCondition: "Rice Leaf Blast (Magnaporthe oryzae)",
    expectedOutcome: "High-Confidence Disease Screening",
    lightingCondition: "High humidity morning haze with water surface glare",
    fieldSetting: "Submerged paddy basin with spindle lesions across leaves",
    primaryImage: "/assets/presets/rice_blast.jpg",
    groundTruthSource: "ICAR-NRRI Cuttack Blast Diagnostic Bulletin",
    simulatedPayload: {
      crop: "Rice (PKV HMT)",
      location: "Sakoli, Bhandara, Maharashtra",
      humidity: 89,
      temperature: 28,
      growthStage: "Tillering / Active Vegetative",
    },
  },
  {
    id: "field_healthy_maize",
    title: "Maize Field: Certified Healthy (No Pathogen)",
    fieldConditionTag: "Control Test — Kolhapur",
    cropEnglish: "Corn / Maize",
    cropMarathi: "मका",
    expectedCondition: "Healthy Leaf (0% Lesions)",
    expectedOutcome: "Healthy Crop Verified",
    lightingCondition: "Even outdoor daylight",
    fieldSetting: "Fertile irrigated field, vigorous dark green lamina",
    primaryImage: "/assets/presets/healthy_maize.jpg",
    groundTruthSource: "ICAR-IARI Division of Plant Pathology Baseline",
    simulatedPayload: {
      crop: "Maize (Kaveri 50)",
      location: "Shirol, Kolhapur, Maharashtra",
      humidity: 65,
      temperature: 29,
      growthStage: "Knee-High Vegetative (V6)",
    },
  },
  {
    id: "test_blurry_rejection",
    title: "Quality Test: Blurry / Out-of-Focus Mobile Photo",
    fieldConditionTag: "Quality Pipeline Test — Motion Blur",
    cropEnglish: "Unknown Crop",
    cropMarathi: "अस्पष्ट पीक",
    expectedCondition: "Unusable Image (Blurred)",
    expectedOutcome: "Quality Check Rejection",
    lightingCondition: "Severe motion shake and defocus blur",
    fieldSetting: "Simulates walking in a windy field with unstable mobile camera",
    primaryImage: "data:image/svg+xml;utf8," + encodeURIComponent(`
      <svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600">
        <defs>
          <filter id="blurTest" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="18" />
          </filter>
        </defs>
        <rect width="600" height="600" fill="#2d3748"/>
        <g filter="url(#blurTest)">
          <path d="M150,450 Q300,100 450,450 Z" fill="#22c55e" opacity="0.6"/>
          <circle cx="300" cy="300" r="100" fill="#854d0e"/>
        </g>
        <rect x="50" y="480" width="500" height="80" rx="10" fill="#0f172a" opacity="0.9"/>
        <text x="300" y="515" fill="#f87171" font-family="sans-serif" font-size="16" font-weight="bold" text-anchor="middle">TEST SPECIMEN: Severe Camera Motion Blur</text>
        <text x="300" y="542" fill="#94a3b8" font-family="sans-serif" font-size="12" text-anchor="middle">Used to verify Image Quality Pipeline rejection (is_usable: false)</text>
      </svg>
    `),
    groundTruthSource: "Quality Pipeline Validation Standard",
    simulatedPayload: {
      crop: "Unclear Crop",
      location: "Maharashtra",
      humidity: 70,
      temperature: 30,
      growthStage: "Unknown",
    },
  },
  {
    id: "test_low_confidence_unknown",
    title: "Ambiguity Test: Unrecognized Weed / Ambiguous Spots",
    fieldConditionTag: "Uncertainty Test — Low Confidence",
    cropEnglish: "Wild Weed / Non-Catalogue Species",
    cropMarathi: "अनोळखी तण",
    expectedCondition: "Unable to Confidently Identify (Confidence < 60%)",
    expectedOutcome: "Low-Confidence / Needs Expert",
    lightingCondition: "Partial shadow under tree canopy",
    fieldSetting: "Field border non-target weed with superficial mechanical tears",
    primaryImage: "data:image/svg+xml;utf8," + encodeURIComponent(`
      <svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600">
        <rect width="600" height="600" fill="#1e293b"/>
        <g transform="translate(300, 300) rotate(45)">
          <ellipse cx="0" cy="0" rx="90" ry="180" fill="#3f6212" stroke="#65a30d" stroke-width="4"/>
          <!-- Random non-pathological tears & dust -->
          <line x1="-30" y1="-50" x2="10" y2="-40" stroke="#713f12" stroke-width="3"/>
          <circle cx="20" cy="30" r="14" fill="#78350f" opacity="0.7"/>
          <line x1="-40" y1="60" x2="0" y2="90" stroke="#713f12" stroke-width="2"/>
        </g>
        <rect x="40" y="490" width="520" height="75" rx="10" fill="#020617" opacity="0.95"/>
        <text x="300" y="522" fill="#fbbf24" font-family="sans-serif" font-size="15" font-weight="bold" text-anchor="middle">TEST SPECIMEN: Ambiguous / Unsupported Leaf</text>
        <text x="300" y="547" fill="#cbd5e1" font-family="sans-serif" font-size="12" text-anchor="middle">Tests refusal to guess when confidence is low (&lt;60%)</text>
      </svg>
    `),
    groundTruthSource: "Uncertainty Quantification Benchmark",
    simulatedPayload: {
      crop: "Unknown Species",
      location: "Maharashtra",
      humidity: 60,
      temperature: 30,
      growthStage: "Unknown",
    },
  },
];
