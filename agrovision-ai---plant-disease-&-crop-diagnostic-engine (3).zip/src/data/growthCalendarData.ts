import { CropGrowthCalendar, GrowthStageItem } from "../types";

export const CROP_GROWTH_CALENDARS: Record<string, CropGrowthCalendar> = {
  tomato: {
    cropName: "Tomato",
    totalDurationDays: 125,
    seasonRecommendation: "Kharif (June–Nov) & Rabi (Oct–March) across Indian agro-climatic zones",
    stages: [
      {
        id: "stage-1",
        stageName: "Nursery & Seedling Establishment",
        dayRange: "Day 0 – 25 DAS",
        minDays: 0,
        maxDays: 25,
        description: "Primary germination and root system development in nursery beds before main field transplanting.",
        vulnerability: "Extremely susceptible to soil-borne Damping-Off (Pythium, Rhizoctonia) and early whitefly viral transmission.",
        preventativeActions: [
          {
            type: "Organic / Bio-Control",
            action: "Treat nursery seeds with Trichoderma viride @ 4g/kg seed to establish protective fungal root colony.",
            dosage: "4g per kg seed",
            targetPathogen: "Pythium Damping-Off & Seedling Blight",
            yieldBenefit: "+15% Initial Seedling Stand & Vigor"
          },
          {
            type: "Cultural Practice",
            action: "Raise nursery beds 15cm above ground with 40-mesh nylon insect netting to physically block whitefly vector.",
            targetPathogen: "Tomato Leaf Curl Virus (ToLCV) Vector",
            yieldBenefit: "Prevents Early Nursery Viral Infection"
          },
          {
            type: "Chemical Prophylactic",
            action: "Drench nursery bed with Copper Oxychloride 50% WP if persistent evening rains occur.",
            dosage: "2.5g per Liter water",
            targetPathogen: "Rhizoctonia & Phytophthora Root Rot",
            yieldBenefit: "Eliminates nursery collar rot casualties"
          }
        ],
        criticalWatchout: "Never allow nursery water stagnation. Water seedlings early morning rather than evening."
      },
      {
        id: "stage-2",
        stageName: "Vegetative & Foliage Canopy Growth",
        dayRange: "Day 25 – 50 DAT",
        minDays: 25,
        maxDays: 50,
        description: "Intense rapid stem elongation, branch multiplication, and foliage density expansion post-transplanting.",
        vulnerability: "Lower foliage in contact with damp soil is primary entry gateway for Alternaria solani (Early Blight) and Red Spider Mites.",
        preventativeActions: [
          {
            type: "Cultural Practice",
            action: "Erect staking stakes/trellis ropes and prune bottom 15cm sucker foliage to prevent soil splash inoculation.",
            targetPathogen: "Alternaria solani (Early Blight Soil Splash)",
            yieldBenefit: "Reduces 60% of lower canopy lesion starts"
          },
          {
            type: "Chemical Prophylactic",
            action: "Preventative protective foliar spray of Mancozeb 75% WP or Chlorothalonil 75% WP before canopy closure.",
            dosage: "2g per Liter water (Mancozeb)",
            targetPathogen: "Early Blight & Septoria Leaf Spot",
            yieldBenefit: "Safeguards green photosynthetic leaf area"
          },
          {
            type: "Organic / Bio-Control",
            action: "Foliar mist of cold-pressed Neem Oil (1500 ppm) with sticker to suppress spider mite eggs and nymph colonization.",
            dosage: "5ml per Liter water + 0.5ml sticker",
            targetPathogen: "Tetranychidae Red Spider Mites & Thrips",
            yieldBenefit: "Stops mite population outbreak before flowering"
          }
        ],
        criticalWatchout: "Inspect leaf undersides every 3 days. Dry hot weather (>32°C) accelerates spider mite generation cycle to 5 days."
      },
      {
        id: "stage-3",
        stageName: "Flowering & First Fruit Cluster Set",
        dayRange: "Day 50 – 75 DAT",
        minDays: 50,
        maxDays: 75,
        description: "Active flowering clusters and initial berry setting. Critical window that dictates total season harvest capacity.",
        vulnerability: "Foliar blight can cause heavy blossom drop; spider mites suck cell sap from flower pedicels; Calcium deficiency causes blossom end rot.",
        preventativeActions: [
          {
            type: "Fertigation",
            action: "Foliar spray of Solubor (Boron 20%) @ 1g/L combined with Calcium Nitrate to promote pollen tube fertility and fruit retention.",
            dosage: "1g/L Boron + 2.5g/L Calcium Nitrate",
            targetPathogen: "Flower Drop & Blossom End Rot",
            yieldBenefit: "+22% Fruit Retention & Reduced Cracking"
          },
          {
            type: "Chemical Prophylactic",
            action: "Preventative dual-action fungicide Azoxystrobin 18.2% + Difenoconazole 11.4% SC or Propineb 70% WP.",
            dosage: "1ml per Liter water",
            targetPathogen: "Early Blight & Anthracnose Fruit Spot",
            yieldBenefit: "Protects young emerging green fruit skin"
          },
          {
            type: "Organic / Bio-Control",
            action: "Release predatory phytoseiid mites (Amblyseius swirskii) or spray bio-insecticide Beauveria bassiana @ 4g/L.",
            dosage: "4g per Liter water",
            targetPathogen: "Two-Spotted Spider Mite & Aphids",
            yieldBenefit: "Pollinator-safe bio-repellent"
          }
        ],
        criticalWatchout: "Avoid spraying broad-spectrum synthetic insecticides between 9:00 AM and 3:00 PM during peak bee pollination."
      },
      {
        id: "stage-4",
        stageName: "Fruit Bulking & Color Break Stage",
        dayRange: "Day 75 – 100 DAT",
        minDays: 75,
        maxDays: 100,
        description: "Rapid expansion of fruit sizing, starch-to-sugar conversion, and carotene ripening pigment development.",
        vulnerability: "Humid monsoon spells trigger Late Blight (Phytophthora infestans) or fruit rot; fruit borer caterpillar boring.",
        preventativeActions: [
          {
            type: "Chemical Prophylactic",
            action: "If continuous rain or overcast foggy weather occurs, apply preventative systemic Metalaxyl-M 4% + Mancozeb 64% WP.",
            dosage: "2.5g per Liter water",
            targetPathogen: "Late Blight (Phytophthora) Fruit Rot",
            yieldBenefit: "Averts catastrophic late-season crop wipeout"
          },
          {
            type: "Organic / Bio-Control",
            action: "Install Helicoverpa pheromone traps (5 traps/acre) and spray Bacillus thuringiensis (Bt var. kurstaki) @ 1.5g/L.",
            dosage: "1.5g per Liter water",
            targetPathogen: "Fruit Borer (Helicoverpa armigera)",
            yieldBenefit: "Eliminates fruit puncture cull losses"
          },
          {
            type: "Fertigation",
            action: "Apply Sulphate of Potash (0-0-50) @ 5g/L foliar or 3kg/acre fertigation for fruit firmness, uniform red color, and TSS brix.",
            dosage: "5g per Liter foliar spray",
            targetPathogen: "Blotchy Ripening & Skin Softness",
            yieldBenefit: "+18% Market Grade Premium & Extended Shelf-Life"
          }
        ],
        criticalWatchout: "Maintain even, consistent drip irrigation. Rapid fluctuations between drought and flooding cause severe skin splitting."
      },
      {
        id: "stage-5",
        stageName: "Harvesting Flushes & Post-Harvest Sanitation",
        dayRange: "Day 100 – 130 DAT",
        minDays: 100,
        maxDays: 130,
        description: "Successive picking rounds every 3-4 days followed by field clearing and soil solarization.",
        vulnerability: "Post-harvest fungal rotting; accumulation of pathogen spores in dead plant residues that overwinter in field soil.",
        preventativeActions: [
          {
            type: "Cultural Practice",
            action: "Harvest fruit at breaker stage early morning; discard culled or rotten fruit in deep compost pit away from field rows.",
            targetPathogen: "Rhizopus Soft Rot & Fruit Fly Spoilage",
            yieldBenefit: "Minimizes transit losses from farm-gate to mandi"
          },
          {
            type: "Organic / Bio-Control",
            action: "Post-final pick, spray Trichoderma viride enriched farmyard manure over soil and deep plough under summer sun.",
            dosage: "2kg Trichoderma per ton FYM",
            targetPathogen: "Overwintering Alternaria & Sclerotium Sclerotia",
            yieldBenefit: "Disinfects field soil for the subsequent crop cycle"
          }
        ],
        criticalWatchout: "Never leave diseased tomato vines rotting on borders—they serve as pathogen reservoirs for neighboring solanaceous crops."
      }
    ]
  },
  rice: {
    cropName: "Rice (Paddy)",
    totalDurationDays: 130,
    seasonRecommendation: "Kharif (June–Nov) & Rabi/Boro (Nov–April) in irrigated wetland deltas",
    stages: [
      {
        id: "stage-1",
        stageName: "Nursery & Seedling Germination",
        dayRange: "Day 0 – 25 DAS",
        minDays: 0,
        maxDays: 25,
        description: "Seedling raising in raised wet nursery beds before puddle transplanting.",
        vulnerability: "Seed-borne Blast spores (Magnaporthe oryzae), Bakanae foot rot, early thrips.",
        preventativeActions: [
          {
            type: "Chemical Prophylactic",
            action: "Dry seed treatment with Carbendazim 50% WP @ 2g/kg or Tricyclazole 75% WP @ 2g/kg seed.",
            dosage: "2g per kg seed",
            targetPathogen: "Seed-borne Blast & Brown Spot",
            yieldBenefit: "Guarantees 95%+ healthy nursery germination"
          },
          {
            type: "Organic / Bio-Control",
            action: "Seed priming with Pseudomonas fluorescens @ 10g/kg and soil drenching of nursery bed.",
            dosage: "10g per kg seed",
            targetPathogen: "Bacterial Leaf Blight & Seedling Blast",
            yieldBenefit: "Induces systemic acquired resistance (SAR)"
          }
        ],
        criticalWatchout: "Clip leaf tips of seedlings before transplanting to eliminate yellow stem borer egg masses."
      },
      {
        id: "stage-2",
        stageName: "Tillering & Vegetative Establishment",
        dayRange: "Day 25 – 55 DAT",
        minDays: 25,
        maxDays: 55,
        description: "Active vegetative tiller production and root anchoring in flooded field conditions.",
        vulnerability: "Leaf Blast spindle lesions and Sheath Blight snakeskin lesions on water level stems.",
        preventativeActions: [
          {
            type: "Chemical Prophylactic",
            action: "Prophylactic foliar spray of Tricyclazole 75% WP @ 0.6g/L at first sign of spindle spots.",
            dosage: "0.6g per Liter water",
            targetPathogen: "Magnaporthe oryzae (Paddy Leaf Blast)",
            yieldBenefit: "Prevents leaf blast transmission to upper canopy"
          },
          {
            type: "Cultural Practice",
            action: "Adopt alternate wetting and drying (AWD) water management; avoid heavy single-dose urea applications.",
            targetPathogen: "Sheath Blight & Root Suffocation",
            yieldBenefit: "Stiffens tillers and conserves 25% irrigation water"
          }
        ],
        criticalWatchout: "Excessive Nitrogen fertilizer creates lush thin-walled leaf cells that pathogens penetrate effortlessly."
      },
      {
        id: "stage-3",
        stageName: "Panicle Initiation & Booting",
        dayRange: "Day 55 – 80 DAT",
        minDays: 55,
        maxDays: 80,
        description: "Panicle embryo develops inside the flag leaf sheath; reproductive tiller determination.",
        vulnerability: "Neck blast infection at this stage causes completely empty whiteheads (100% loss of affected tiller).",
        preventativeActions: [
          {
            type: "Chemical Prophylactic",
            action: "Mandatory prophylactic spray of Azoxystrobin 18.2% + Difenoconazole 11.4% SC or Validamycin 3% L at boot-leaf emergence.",
            dosage: "1ml per Liter water",
            targetPathogen: "Panicle Neck Blast & Sheath Blight",
            yieldBenefit: "+28% Grain Filling & Filled Panicle Ratio"
          },
          {
            type: "Fertigation",
            action: "Top-dress Muriate of Potash (MOP) @ 15kg/acre to harden stem walls against lodging and brown planthopper.",
            dosage: "15kg per acre",
            targetPathogen: "Stem Weakness & Lodging Vulnerability",
            yieldBenefit: "Ensures upright canopy and heavy panicle support"
          }
        ],
        criticalWatchout: "Never skip the boot-leaf preventative fungicide spray if continuous drizzle or morning dew persists."
      },
      {
        id: "stage-4",
        stageName: "Flowering, Heading & Grain Filling",
        dayRange: "Day 80 – 110 DAT",
        minDays: 80,
        maxDays: 110,
        description: "Anthesis pollination followed by milky and dough grain starch deposition.",
        vulnerability: "False smut yellow velvet balls; Rice ear-cutting caterpillar; Gundhi bug sap sucking.",
        preventativeActions: [
          {
            type: "Chemical Prophylactic",
            action: "Spray Propiconazole 25% EC @ 1ml/L at 50% flowering to prevent False Smut (Ustilaginoidea virens).",
            dosage: "1ml per Liter water",
            targetPathogen: "False Smut & Glume Discoloration",
            yieldBenefit: "Maintains pristine grain export quality"
          },
          {
            type: "Cultural Practice",
            action: "Maintain 2-3cm thin water film during flowering; monitor for Brown Planthopper at stem base.",
            targetPathogen: "Moisture Stress & Hopper Burn",
            yieldBenefit: "Prevents chaffy unfilled grains"
          }
        ],
        criticalWatchout: "Do not spray toxic chemicals during anthesis hours (9:30 AM to 11:30 AM) when rice glumes open for pollination."
      },
      {
        id: "stage-5",
        stageName: "Maturity & Pre-Harvest Drying",
        dayRange: "Day 110 – 130 DAT",
        minDays: 110,
        maxDays: 130,
        description: "Panicles turn golden yellow, moisture decreases from 24% to 18-20% ideal harvest moisture.",
        vulnerability: "Pre-harvest lodging from cyclones; grain shattering; mould infection if harvested wet.",
        preventativeActions: [
          {
            type: "Cultural Practice",
            action: "Drain all standing water from paddy fields 10-12 days before anticipated harvest date.",
            targetPathogen: "Soil softening, grain sprouting & mould",
            yieldBenefit: "Enables combine harvester trafficability and uniform dry grains"
          }
        ],
        criticalWatchout: "Delayed harvest beyond 20% moisture causes sun-checking cracks, leading to broken rice during milling."
      }
    ]
  },
  cotton: {
    cropName: "Cotton",
    totalDurationDays: 160,
    seasonRecommendation: "Kharif sowing (May–June) across Central & Southern Indian black cotton soils",
    stages: [
      {
        id: "stage-1",
        stageName: "Germination & Seedling Phase",
        dayRange: "Day 0 – 30 DAS",
        minDays: 0,
        maxDays: 30,
        description: "Deep taproot anchoring and first true leaf formation in deep black or loamy soil.",
        vulnerability: "Cotton Leaf Curl Virus (CLCuV) transmitted by whitefly Bemisia tabaci; seedling damping-off.",
        preventativeActions: [
          {
            type: "Chemical Prophylactic",
            action: "Seed treatment with Imidacloprid 70% WS @ 5g/kg seed for 30-day early sucking pest protection.",
            dosage: "5g per kg seed",
            targetPathogen: "Early Whitefly, Thrips & Jassids",
            yieldBenefit: "Eliminates need for early foliar chemical sprays"
          },
          {
            type: "Cultural Practice",
            action: "Plant 2-3 barrier border rows of Pearl Millet (Bajra) or Maize around the cotton plot to obstruct windborne whiteflies.",
            targetPathogen: "Whitefly Vector & CLCuV Influx",
            yieldBenefit: "Reduces virus vector incidence by 45%"
          }
        ],
        criticalWatchout: "Uproot and burn any volunteer weeds (e.g. Abutilon indicum) near field borders that harbor Leaf Curl Virus."
      },
      {
        id: "stage-2",
        stageName: "Square Formation & Vegetative Branching",
        dayRange: "Day 30 – 65 DAS",
        minDays: 30,
        maxDays: 65,
        description: "Formation of pyramidal flower buds ('squares') and rapid monopodial and sympodial branch growth.",
        vulnerability: "Bacterial Blight (Xanthomonas), Alternaria leaf spot, early bollworm entry.",
        preventativeActions: [
          {
            type: "Chemical Prophylactic",
            action: "Preventative spray of Copper Oxychloride 50% WP @ 2.5g/L + Streptocycline @ 1g/10L against Bacterial Blight.",
            dosage: "2.5g COC + 0.1g Streptocycline per Liter",
            targetPathogen: "Bacterial Blight (Angular Leaf Spot)",
            yieldBenefit: "Stops black arm stem canker development"
          },
          {
            type: "Organic / Bio-Control",
            action: "Install yellow sticky traps (12/acre) and spray 5% Neem Seed Kernel Extract (NSKE) as oviposition deterrent.",
            dosage: "50g NSKE per Liter water",
            targetPathogen: "Whiteflies, Jassids & Bollworm moths",
            yieldBenefit: "Natural pest deterrent without harming natural predators"
          }
        ],
        criticalWatchout: "Install Pink Bollworm pheromone traps (5 traps/acre) at 45 DAS to track moth catch spikes."
      },
      {
        id: "stage-3",
        stageName: "Peak Flowering & Boll Setting",
        dayRange: "Day 65 – 105 DAS",
        minDays: 65,
        maxDays: 105,
        description: "Open creamy-white flowers transition to pink; young bolls expand rapidly in size.",
        vulnerability: "Pink Bollworm (Pectinophora gossypiella) larvae bore directly into bolls; internal boll rot.",
        preventativeActions: [
          {
            type: "Chemical Prophylactic",
            action: "If pheromone traps exceed 8 moths/trap/night for 3 consecutive days, spray Emamectin Benzoate 5% SG @ 0.4g/L.",
            dosage: "0.4g per Liter water",
            targetPathogen: "Pink Bollworm & Spotted Bollworm",
            yieldBenefit: "+30% Clean White Lint Bolls"
          },
          {
            type: "Fertigation",
            action: "Foliar spray of 13-0-45 (Potassium Nitrate) @ 10g/L + Magnesium Sulphate @ 5g/L to prevent leaf reddening.",
            dosage: "10g/L Potassium Nitrate",
            targetPathogen: "Physiological Leaf Reddening & Square Drop",
            yieldBenefit: "Keeps upper canopy active for late boll filling"
          }
        ],
        criticalWatchout: "Destructive scouting: Inspect 20 bolls per acre weekly; if rosette flowers or internal boring exceeds 10%, treat immediately."
      },
      {
        id: "stage-4",
        stageName: "Boll Maturation & Bursting",
        dayRange: "Day 105 – 140 DAS",
        minDays: 105,
        maxDays: 140,
        description: "Bolls dry and burst open cleanly, exposing fluffy white seed cotton (kapas).",
        vulnerability: "Grey Mildew (Ramularia areola), humid weather boll rotting, dusky cotton bug staining.",
        preventativeActions: [
          {
            type: "Chemical Prophylactic",
            action: "Foliar spray of Wettable Sulphur 80% WDG @ 3g/L or Kresoxim-methyl 44.3% SC @ 1ml/L against Grey Mildew.",
            dosage: "3g per Liter water (Sulphur)",
            targetPathogen: "Ramularia Grey Mildew (Dahiya disease)",
            yieldBenefit: "Prevents premature defoliation before bolls mature"
          }
        ],
        criticalWatchout: "Cease synthetic chemical sprays 20 days prior to first picking to avoid pesticide residues on commercial lint."
      },
      {
        id: "stage-5",
        stageName: "Picking Flushes & Crop Termination",
        dayRange: "Day 140 – 165 DAS",
        minDays: 140,
        maxDays: 165,
        description: "2 to 3 selective pickings followed by mandatory stalk shredding to break insect life cycles.",
        vulnerability: "Overwintering diapausing Pink Bollworm larvae inside leftover green unburst bolls.",
        preventativeActions: [
          {
            type: "Cultural Practice",
            action: "Pick dry seed cotton in clean cloth bags; avoid mixing stained or trash-laden cotton; terminate crop by end of January.",
            targetPathogen: "Pink Bollworm Diapause Overwintering",
            yieldBenefit: "Breaks multi-year pest carryover for next season"
          }
        ],
        criticalWatchout: "Never practice ratoon cotton cultivation—it is the single largest cause of endemic Pink Bollworm epidemics across India."
      }
    ]
  },
  potato: {
    cropName: "Potato",
    totalDurationDays: 105,
    seasonRecommendation: "Rabi season (Oct–Feb) in Northern Gangetic plains and hills",
    stages: [
      {
        id: "stage-1",
        stageName: "Sprouting & Emergence",
        dayRange: "Day 0 – 25 DAP",
        minDays: 0,
        maxDays: 25,
        description: "Tuber eye sprouting, shoot emergence, and early root system formation.",
        vulnerability: "Seed-piece decay, Black Scurf (Rhizoctonia solani), early cutworms.",
        preventativeActions: [
          {
            type: "Chemical Prophylactic",
            action: "Treat well-sprouted certified seed tubers with Boric Acid 3% solution or Pencycuron 250 SC @ 2ml/L water.",
            dosage: "2ml per Liter water",
            targetPathogen: "Rhizoctonia Black Scurf & Tuber Rot",
            yieldBenefit: "Ensures 100% uniform field plant population"
          },
          {
            type: "Cultural Practice",
            action: "Earthing-up loose soil ridges 20 days after emergence to cover developing tubers from sunlight greening.",
            targetPathogen: "Tuber Moth & Sun Greening (Solanine)",
            yieldBenefit: "Maximizes Grade-A marketable clean tubers"
          }
        ],
        criticalWatchout: "Plant only certified disease-free seed tubers from verified seed agencies (CPRI / State Agriculture)."
      },
      {
        id: "stage-2",
        stageName: "Stolon Formation & Tuber Initiation",
        dayRange: "Day 25 – 50 DAP",
        minDays: 25,
        maxDays: 50,
        description: "Stolons swell at tips beneath soil to form tiny marble-sized baby tubers.",
        vulnerability: "Early Blight (Alternaria solani) and initial Late Blight (Phytophthora infestans) inoculum.",
        preventativeActions: [
          {
            type: "Chemical Prophylactic",
            action: "Mandatory preventative prophylactic spray of Mancozeb 75% WP @ 2.5g/L before canopy closes the furrows.",
            dosage: "2.5g per Liter water",
            targetPathogen: "Early & Late Blight Prophylaxis",
            yieldBenefit: "Establishes protective copper/mancozeb contact shield"
          },
          {
            type: "Organic / Bio-Control",
            action: "Soil drench with Trichoderma harzianum @ 5g/L around root zone during irrigation.",
            dosage: "5g per Liter water",
            targetPathogen: "Fusarium Dry Rot & Sclerotium Wilt",
            yieldBenefit: "Biological soil barrier around young stolons"
          }
        ],
        criticalWatchout: "Avoid irrigating in late evening. Foliage that remains wet all night is primed for late blight spore germination."
      },
      {
        id: "stage-3",
        stageName: "Rapid Tuber Bulking & Canopy Density",
        dayRange: "Day 50 – 75 DAP",
        minDays: 50,
        maxDays: 75,
        description: "Massive translocation of carbohydrates from leafy canopy into tubers for size enlargement.",
        vulnerability: "Severe Late Blight epidemic risk when temperature drops to 10-20°C with dense fog and >85% humidity.",
        preventativeActions: [
          {
            type: "Chemical Prophylactic",
            action: "Upon weather advisory of fog/rain, immediately spray Cymoxanil 8% + Mancozeb 64% WP @ 2.5g/L or Dimethomorph 50% WP @ 1g/L.",
            dosage: "2.5g per Liter water",
            targetPathogen: "Late Blight (Phytophthora infestans)",
            yieldBenefit: "Stops explosive 48-hour total field blighting"
          },
          {
            type: "Fertigation",
            action: "Apply Sulphate of Potash (0-0-50) @ 5g/L foliar spray to boost starch accumulation and tuber specific gravity.",
            dosage: "5g per Liter water",
            targetPathogen: "Hollow Heart & Low Tuber Dry Matter",
            yieldBenefit: "+20% Total Harvest Weight"
          }
        ],
        criticalWatchout: "Check IMD weather bulletins daily. If fog persists more than 3 days, do not delay preventative systemic sprays."
      },
      {
        id: "stage-4",
        stageName: "Dehaulming & Tuber Skin Hardening",
        dayRange: "Day 75 – 95 DAP",
        minDays: 75,
        maxDays: 95,
        description: "Foliage yellowing, vegetative growth termination, and tuber skin cutinization.",
        vulnerability: "Late blight spores washing down from diseased foliage into soil cracks, rotting underground tubers.",
        preventativeActions: [
          {
            type: "Cultural Practice",
            action: "Dehaulm (cut and remove all aerial foliage at soil level) 10-15 days before digging harvest.",
            targetPathogen: "Late Blight Spore Wash & Aphid Virus Transmission",
            yieldBenefit: "Hardens tuber skins so they do not peel during transport"
          }
        ],
        criticalWatchout: "Never harvest immediately after dehaulming. Allow 12-15 days underground for tuber skin to thicken and cure."
      },
      {
        id: "stage-5",
        stageName: "Harvest & Post-Harvest Curing",
        dayRange: "Day 95 – 105 DAP",
        minDays: 95,
        maxDays: 105,
        description: "Careful mechanical or manual lifting of tubers in dry crisp weather.",
        vulnerability: "Tuber bruising, soft rot bacteria entry, greening from direct sun exposure.",
        preventativeActions: [
          {
            type: "Cultural Practice",
            action: "Cure harvested tubers in a cool, dark, ventilated shed at 15-18°C with 85-90% humidity for 10 days before cold storage.",
            targetPathogen: "Bacterial Soft Rot & Fusarium Wound Infection",
            yieldBenefit: "Heals micro-scrapes and extends storage life to 8+ months"
          }
        ],
        criticalWatchout: "Do not expose harvested potatoes to bright midday sunlight for more than 30 minutes to prevent toxic solanine development."
      }
    ]
  },
  general: {
    cropName: "Crop Specimen",
    totalDurationDays: 120,
    seasonRecommendation: "Applicable for commercial seasonal horticulture and field crops",
    stages: [
      {
        id: "stage-1",
        stageName: "Seedling & Root Establishment",
        dayRange: "Day 0 – 25 DAS",
        minDays: 0,
        maxDays: 25,
        description: "Initial seed germination, radical emergence, and juvenile root anchor establishment.",
        vulnerability: "Damping-off, collar rot, seed decay, and juvenile sap-sucking insects.",
        preventativeActions: [
          {
            type: "Organic / Bio-Control",
            action: "Seed priming with Trichoderma viride or Pseudomonas @ 5g/kg seed.",
            dosage: "5g per kg seed",
            targetPathogen: "Seedling Damping-Off & Collar Rot",
            yieldBenefit: "+15% Stand Uniformity"
          },
          {
            type: "Cultural Practice",
            action: "Ensure adequate drainage furrows and avoid over-saturating young root zones.",
            targetPathogen: "Anaerobic root rot",
            yieldBenefit: "Stronger foundational taproot development"
          }
        ],
        criticalWatchout: "Do not plant seeds deeper than 2.5 times their seed diameter."
      },
      {
        id: "stage-2",
        stageName: "Active Vegetative Canopy Growth",
        dayRange: "Day 25 – 55 DAT",
        minDays: 25,
        maxDays: 55,
        description: "Expansion of photosynthetic leaf area, tillers/branches, and stem girth.",
        vulnerability: "Foliar blights, powdery mildew, red spider mites, aphids, and nutrient deficiencies.",
        preventativeActions: [
          {
            type: "Chemical Prophylactic",
            action: "Preventative contact fungicide spray (Mancozeb 75% WP @ 2g/L) before monsoon rains.",
            dosage: "2g per Liter water",
            targetPathogen: "Leaf Spot & Blight Pathogens",
            yieldBenefit: "Preserves green leaf area index"
          },
          {
            type: "Organic / Bio-Control",
            action: "Neem oil foliar spray (1500 ppm @ 4ml/L) as broad-spectrum prophylactic insect repellent.",
            dosage: "4ml per Liter water",
            targetPathogen: "Mites, Aphids & Whitefly Vectors",
            yieldBenefit: "Stops early viral spread"
          }
        ],
        criticalWatchout: "Inspect lower foliage regularly where microclimatic humidity is highest."
      },
      {
        id: "stage-3",
        stageName: "Flowering & Reproductive Initiation",
        dayRange: "Day 55 – 85 DAT",
        minDays: 55,
        maxDays: 85,
        description: "Flower bud initiation, anthesis pollination, and embryo setting.",
        vulnerability: "Blossom drop, flower thrips, anthracnose rot, and boron/calcium deficiency.",
        preventativeActions: [
          {
            type: "Fertigation",
            action: "Micronutrient spray of Boron (1g/L) and balanced N-P-K (19-19-19 @ 4g/L) for flower strength.",
            dosage: "1g/L Boron + 4g/L NPK",
            targetPathogen: "Flower Abortion & Poor Pollen Viability",
            yieldBenefit: "+20% Fruit/Grain Setting Rate"
          },
          {
            type: "Organic / Bio-Control",
            action: "Install pheromone and sticky traps; spray Bacillus thuringiensis or bio-fungicides.",
            dosage: "2g per Liter water",
            targetPathogen: "Boring Caterpillars & Pod Borers",
            yieldBenefit: "Safe for honeybee pollinators"
          }
        ],
        criticalWatchout: "Strictly avoid toxic chemical insecticide applications during morning pollination hours."
      },
      {
        id: "stage-4",
        stageName: "Yield Bulking & Maturation",
        dayRange: "Day 85 – 110 DAT",
        minDays: 85,
        maxDays: 110,
        description: "Grain/fruit filling, starch accumulation, and protective skin cutinization.",
        vulnerability: "Late-season fruit rots, lodging, cracking, and sap-sucking bugs.",
        preventativeActions: [
          {
            type: "Fertigation",
            action: "Apply Potassium Sulphate (0-0-50 @ 5g/L) to accelerate sugar transport and tissue firmness.",
            dosage: "5g per Liter water",
            targetPathogen: "Premature Drop & Skin Cracking",
            yieldBenefit: "+15% Density & Extended Shelf-Life"
          }
        ],
        criticalWatchout: "Check pre-harvest interval (PHI) of any spray applied within 20 days of picking."
      },
      {
        id: "stage-5",
        stageName: "Harvest & Post-Harvest Field Sanitization",
        dayRange: "Day 110 – 120+ DAT",
        minDays: 110,
        maxDays: 125,
        description: "Harvesting at optimal maturity followed by crop residue destruction.",
        vulnerability: "Post-harvest transit spoilage and overwintering spores in soil.",
        preventativeActions: [
          {
            type: "Cultural Practice",
            action: "Remove all diseased crop residues from field; deep plough to expose soil pathogens to sun.",
            targetPathogen: "Soil-borne Inoculum Survival",
            yieldBenefit: "Reduces next season disease pressure by 50%"
          }
        ],
        criticalWatchout: "Store harvested produce in cool, dry, ventilated conditions with minimal physical bruising."
      }
    ]
  }
};

/**
 * Returns the matching growth calendar based on crop common name or hint.
 */
export function getGrowthCalendarForCrop(cropCommonName?: string): CropGrowthCalendar {
  if (!cropCommonName) return CROP_GROWTH_CALENDARS.tomato;
  const lower = cropCommonName.toLowerCase();
  if (lower.includes("tomato")) return CROP_GROWTH_CALENDARS.tomato;
  if (lower.includes("rice") || lower.includes("paddy")) return CROP_GROWTH_CALENDARS.rice;
  if (lower.includes("cotton")) return CROP_GROWTH_CALENDARS.cotton;
  if (lower.includes("potato")) return CROP_GROWTH_CALENDARS.potato;
  if (lower.includes("corn") || lower.includes("maize")) return CROP_GROWTH_CALENDARS.general;
  return CROP_GROWTH_CALENDARS.general;
}
