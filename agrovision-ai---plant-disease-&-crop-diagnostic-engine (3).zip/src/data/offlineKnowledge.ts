import { DiagnosticReport, DiagnosisItem, normalizeDiagnosticReport } from "../types";

export interface OfflineDiseaseEntry {
  id: string;
  cropName: string;
  scientificName: string;
  diseaseName: string;
  causalAgent: string;
  condition: "Healthy" | "Diseased" | "Pest Attack" | "Nutrient Deficiency";
  severityDefault: "Low" | "Moderate" | "High" | "Critical";
  affectedPercentage: number;
  symptoms: string[];
  organicTreatment: string[];
  chemicalTreatment: string[];
  fertilizerAdjustment: string;
  weatherRisk: {
    conditions: string;
    preventative: string;
  };
  localizedTranslations: Record<string, string>;
  diagnosesList?: DiagnosisItem[];
}

export const OFFLINE_DISEASE_REGISTRY: OfflineDiseaseEntry[] = [
  {
    id: "tomato-co-infection",
    cropName: "Tomato",
    scientificName: "Solanum lycopersicum",
    diseaseName: "Early Blight & Spider Mite Damage",
    causalAgent: "Alternaria solani (Fungus) + Tetranychidae (Pest)",
    condition: "Diseased",
    severityDefault: "Moderate",
    affectedPercentage: 25,
    symptoms: [
      "Concentric ring spots on lower leaves",
      "Yellowing around leaf lesions",
      "Fine white stippling on upper leaf surface from spider mites",
    ],
    organicTreatment: [
      "Apply Neem oil solution (5ml/L of water).",
      "Spray insecticidal soap or neem oil spray directly to undersides of leaves.",
    ],
    chemicalTreatment: [
      "Spray Mancozeb 75% WP @ 2g/L of water.",
      "Apply Abamectin 1.8% EC @ 1ml/L of water if infestation spreads.",
    ],
    fertilizerAdjustment: "Maintain balanced nutrition; avoid excessive nitrogen which accelerates mite reproduction.",
    weatherRisk: {
      conditions: "High humidity (>85%) and warm temperatures.",
      preventative: "Avoid overhead sprinkler irrigation.",
    },
    localizedTranslations: {
      Hindi: "आपकी टमाटर की फसल में अगेती झुलसा और लाल मकड़ी (Spider Mite) दोनों का प्रकोप है। नीम का तेल और मैंकोजेब (2g/L) का छिड़काव करें।",
      Tamil: "உங்கள் தக்காளியில் ஆரம்பகால கருகல் மற்றும் சிலந்திப் பூச்சி தாக்குதல் உள்ளது. வேப்பெண்ணெய் மற்றும் மான்கோசெப் தெளிக்கவும்.",
      Marathi: "टोमॅटो पिकावर करपा आणि लाल कोळी दोघांचा प्रादुर्भाव आहे. नीम तेल आणि मॅनकोझेब फवारावे.",
      Telugu: "మీ టమోటాలో ఎర్లీ బ్లైట్ మరియు స్పైడర్ మైట్ తెగులు ఉంది. వేపనూనె మరియు మాంకోజెబ్ పిచికారీ చేయండి.",
      Bengali: "টমেটোতে আর্লি ব্লাইট এবং স্পাইডার মাইট আক্রমণ ঘটেছে। নিম তেল ও ম্যানকোজেব স্প্রে করুন।",
      Gujarati: "ટામેટાના પાકમાં આગોતરો સુકારો અને લાલ ઈયળ/કથીરી છે. લીમડાનું તેલ અને મેન્કોઝેબ વાપરો.",
      Punjabi: "ਟਮਾਟਰ ਦੀ ਫਸਲ 'ਤੇ ਅਗੇਤਾ ਝੁਲਸਾ ਅਤੇ ਮਾਈਟ ਦਾ ਹਮਲਾ ਹੈ। ਨਿੰਮ ਦਾ ਤੇਲ ਅਤੇ ਮੈਨਕੋਜ਼ੇਬ ਛਿੜਕੋ।",
      Kannada: "ಟೊಮೆಟೊ ಬೆಳೆಯಲ್ಲಿ ಮುಂಚಿತ ಬ್ಲೈಟ್ ಮತ್ತು ಜೇಡ ಹುಳು ಬಾಧೆ ಇದೆ. ಬೇವಿನ ಎಣ್ಣೆ ಸಿಂಪಡಿಸಿ.",
      English: "Detected co-infection of Early Blight (fungus) and Spider Mite damage (pest). Apply Mancozeb and Neem oil / Abamectin.",
    },
    diagnosesList: [
      {
        disease_name: "Early Blight",
        causal_agent: "Alternaria solani (Fungus)",
        casual_agent: "Alternaria solani (Fungus)",
        severity_level: "Moderate",
        estimated_affected_area_percentage: 25,
        key_symptoms: [
          "Concentric ring spots on lower leaves",
          "Yellowing around leaf lesions",
        ],
        remediation: {
          organic_treatment: [
            "Apply Neem oil solution (5ml/L of water).",
          ],
          chemical_treatment: [
            "Spray Mancozeb 75% WP @ 2g/L of water.",
          ],
        },
      },
      {
        disease_name: "Spider Mite Damage",
        causal_agent: "Tetranychidae (Pest)",
        casual_agent: "Tetranychidae (Pest)",
        severity_level: "Low",
        estimated_affected_area_percentage: 10,
        key_symptoms: [
          "Fine white stippling on upper leaf surface",
        ],
        remediation: {
          organic_treatment: [
            "Spray insecticidal soap or neem oil spray directly to undersides of leaves.",
          ],
          chemical_treatment: [
            "Apply Abamectin 1.8% EC @ 1ml/L of water if infestation spreads.",
          ],
        },
      },
    ],
  },
  {
    id: "tomato-early-blight",
    cropName: "Tomato",
    scientificName: "Solanum lycopersicum",
    diseaseName: "Early Blight",
    causalAgent: "Alternaria solani (Fungus)",
    condition: "Diseased",
    severityDefault: "Moderate",
    affectedPercentage: 28,
    symptoms: [
      "Concentric ring spots (target-board pattern) on mature lower leaves",
      "Chlorotic yellowing halos surrounding necrotic brown lesions",
      "Defoliation starting from bottom foliage working upward",
    ],
    organicTreatment: [
      "Spray 5% Neem seed kernel extract (NSKE) or cold-pressed Neem oil (5ml/L water) mixed with mild soap emulsifier every 7 days.",
      "Apply Trichoderma viride bio-fungicide @ 5g/L water on foliage and root zone.",
      "Prune and burn lower 12 inches of infected leaves to arrest upward fungal spore splashing.",
    ],
    chemicalTreatment: [
      "Spray Mancozeb 75% WP @ 2.0g to 2.5g/L of water at first symptom onset.",
      "Alternate with Copper Oxychloride 50% WP @ 3.0g/L or Azoxystrobin 18.2% + Difenoconazole 11.4% SC @ 1ml/L if humid weather persists.",
    ],
    fertilizerAdjustment: "Suspend excess urea/nitrogenous fertilizers; boost potassium sulfate (0-0-50) @ 5g/L foliar spray to strengthen leaf cell walls.",
    weatherRisk: {
      conditions: "Intermittent rain showers followed by warm temperatures (24°C–30°C) and relative humidity >85%.",
      preventative: "Avoid overhead sprinkler irrigation; practice wide plant spacing (60cm x 45cm) for laminar airflow.",
    },
    localizedTranslations: {
      Hindi: "आपकी टमाटर की फसल में अगेती झुलसा (Early Blight) रोग के लक्षण पाए गए हैं। तुरंत नीम के तेल (5 मिली/लीटर) या मैंकोजेब (2 ग्राम/लीटर) का छिड़काव करें।",
      Tamil: "உங்கள் தக்காளி பயிரில் ஆரம்பகால கருகல் நோய் (Early Blight) அறிகுறிகள் உள்ளன. வேப்பெண்ணெய் கரைசல் (5ml/L) அல்லது மான்கோசெப் தெளிக்கவும்.",
      Marathi: "तुमच्या टोमॅटो पिकावर अर्ली ब्लाइट (करपा) रोगाचा प्रादुर्भाव झाला आहे. प्रतिबंधासाठी मॅनकोझेब २ ग्रॅम प्रति लिटर फवारावे.",
      Telugu: "మీ టమాటో పంటలో ప్రారంభ బ్లైట్ తెగులు లక్షణాలు కనిపించాయి. నివారణకు వేప నూనె లేదా మాంకోజెబ్ మందును పిచికారీ చేయండి.",
      Bengali: "আপনার টমেটো ফসলে আর্লি ব্লাইট রোগের লক্ষণ দেখা গেছে। নিম তেল বা ম্যানকোজেব স্প্রে করুন এবং আক্রান্ত পাতা অপসারণ করুন।",
      Gujarati: "તમારા ટામેટાના પાકમાં આગોતરો સુકારો (Early Blight) ના લક્ષણો છે. લીમડાનું તેલ અથવા મેન્કોઝેબનો છંટકાવ કરો.",
      Punjabi: "ਤੁਹਾਡੀ ਟਮਾਟਰ ਦੀ ਫਸਲ ਵਿੱਚ ਅਗੇਤਾ ਝੁਲਸਾ ਰੋਗ ਦੇ ਲੱਛਣ ਹਨ। ਰੋਕਥਾਮ ਲਈ ਨਿੰਮ ਦਾ ਤੇਲ ਜਾਂ ਮੈਨਕੋਜ਼ੇਬ ਦਾ ਛਿੜਕਾਅ ਕਰੋ।",
      Kannada: "ನಿಮ್ಮ ಟೊಮೆಟೊ ಬೆಳೆಯಲ್ಲಿ ಮುಂಚಿತ ಬ್ಲೈಟ್ ರೋಗದ ಲಕ್ಷಣಗಳು ಕಂಡುಬಂದಿವೆ. ಬೇವಿನ ಎಣ್ಣೆ ಅಥವಾ ಮ್ಯಾಂಕೋಜೆಬ್ ಸಿಂಪಡಿಸಿ.",
      English: "Early Blight detected on tomato foliage. Apply Neem oil emulsion or Mancozeb 75% WP and remove infected lower leaves.",
    },
  },
  {
    id: "paddy-blast",
    cropName: "Paddy / Rice",
    scientificName: "Oryza sativa",
    diseaseName: "Rice Blast (Leaf Blast)",
    causalAgent: "Magnaporthe oryzae (Fungus)",
    condition: "Diseased",
    severityDefault: "High",
    affectedPercentage: 35,
    symptoms: [
      "Spindle-shaped/diamond-shaped lesions with ash-grey center and dark reddish-brown margins",
      "Coalescing spots causing complete leaf drying and seedling burn",
      "Lesions on nodal joints causing lodging during panicle emergence",
    ],
    organicTreatment: [
      "Foliar spray of Pseudomonas fluorescens talc formulation @ 10g/L of water at 10-day intervals.",
      "Spray Jeevamrut (cow urine + dung bio-concoction) 10% solution to induce systemic plant defense.",
    ],
    chemicalTreatment: [
      "Spray Tricyclazole 75% WP @ 0.6g/L of water (standard ICAR recommendation).",
      "Alternate with Isoprothiolane 40% EC @ 1.5ml/L or Kasugamycin 3% SL @ 2ml/L in severe outbreaks.",
    ],
    fertilizerAdjustment: "Immediately withhold top-dressing of Urea. Split nitrogen doses into 3-4 split applications; apply Silicon/potash fertilizers.",
    weatherRisk: {
      conditions: "Dense morning fog, prolonged dew on leaf blades (>9 hours), nighttime temperatures 19°C–24°C.",
      preventative: "Maintain optimal field water level; drain flooded water for 48 hours to aerate the soil root zone.",
    },
    localizedTranslations: {
      Hindi: "धान की फसल में झोंका/ब्लास्ट रोग (Rice Blast) के लक्षण हैं। ट्राइसाइक्लाजोल 75% WP (0.6 ग्राम/लीटर) का छिड़काव करें और यूरिया रोक दें।",
      Tamil: "நெல் பயிரில் குலை நோய் (Rice Blast) தாக்கியுள்ளது. உடனே டிரைசைக்ளசோல் 75% WP (0.6g/L) மருந்தை தெளிக்கவும்.",
      Marathi: "भाताच्या पिकावर करपा (Rice Blast) रोगाचा प्रादुर्भाव झाला आहे. युरिया खताचा वापर थांबवून ट्रायसायक्लॅझोल फवारावे.",
      Telugu: "వరి పంటలో అగ్గి తెగులు (బ్లాస్ట్) కనిపించింది. ట్రైసైక్లాజోల్ 75% WP (0.6 గ్రా/లీ) పిచికారీ చేసి, యూరియా తగ్గించండి.",
      Bengali: "ধানের পাতায় ব্লাস্ট রোগের আক্রমণ হয়েছে। ট্রাইসাইক্লাজোল স্প্রে করুন ও অতিরিক্ত ইউরিয়া প্রয়োগ বন্ধ রাখুন।",
      Gujarati: "ડાંગરના પાકમાં ગેરુ/બ્લાસ્ટ રોગના ચિહ્નો છે. ટ્રાયસાઇક્લાઝોલનો છંટકાવ કરો અને યુરિયા આપવાનું બંધ કરો.",
      Punjabi: "ਝੋਨੇ ਦੀ ਫਸਲ ਵਿੱਚ ਧੌਣ ਮਰੋੜ/ਬਲਾਸਟ ਰੋਗ ਦੇ ਲੱਛਣ ਹਨ। ਟ੍ਰਾਈਸਾਈਕਲਾਜ਼ੋਲ 0.6 ਗ੍ਰਾਮ ਪ੍ਰਤੀ ਲੀਟਰ ਪਾਣੀ ਵਿੱਚ ਛਿੜਕੋ।",
      Kannada: "ಭತ್ತದ ಬೆಳೆಯಲ್ಲಿ ಬೆಂಕಿ ರೋಗ (ಬ್ಲಾಸ್ಟ್) ಕಂಡುಬಂದಿದೆ. ಟ್ರೈಸೈಕ್ಲೋಜೋಲ್ ಸಿಂಪಡಿಸಿ ಹಾಗೂ ಯೂರಿಯಾ ಕಡಿಮೆ ಮಾಡಿ.",
      English: "Rice Leaf Blast detected. Discontinue urea application and immediately spray Tricyclazole 75% WP @ 0.6g/L.",
    },
  },
  {
    id: "cotton-leaf-curl",
    cropName: "Cotton",
    scientificName: "Gossypium hirsutum",
    diseaseName: "Cotton Leaf Curl Virus (CLCuD)",
    causalAgent: "Begomovirus (Transmitted by Whitefly Bemisia tabaci)",
    condition: "Pest Attack",
    severityDefault: "Critical",
    affectedPercentage: 45,
    symptoms: [
      "Upward or downward cupping and thickening of veins on leaves",
      "Cup-shaped leaf outgrowths (enations) on underside of main veins",
      "Severe plant stunting and reduction in boll formation",
    ],
    organicTreatment: [
      "Install yellow sticky traps @ 15-20 traps per acre to monitor and trap whitefly vectors.",
      "Spray 5% Neem oil (Azadirachtin 1500 ppm @ 5ml/L) to deter whitefly nymph feeding.",
      "Eradicate weed hosts like Abutilon indicum and Xanthium strumarium along field bunds.",
    ],
    chemicalTreatment: [
      "Spray Diafenthiuron 50% WP @ 1.2g/L or Afidopyropen 50g/L @ 2ml/L to control the vector whiteflies.",
      "Alternate with Pyriproxyfen 10% EC @ 2ml/L for inhibiting whitefly egg hatching.",
    ],
    fertilizerAdjustment: "Foliar spray of 2% Potassium Nitrate (13:0:45) + 1% Magnesium Sulfate to counteract yellowing.",
    weatherRisk: {
      conditions: "Dry hot weather (32°C–40°C) with dry spells favoring whitefly multiplication.",
      preventative: "Maintain border crops of 2 rows of Bajra/Maize/Sorghum as a natural physical wind & vector barrier.",
    },
    localizedTranslations: {
      Hindi: "कपास में पत्ता मरोड़ वायरस (CLCuD) और सफेद मक्खी का हमला है। सफेद मक्खी नियंत्रण हेतु डायफेन्थियुरॉन या नीम तेल का छिड़काव करें।",
      Tamil: "பருத்தியில் இலை சுருட்டு வைரஸ் பரவியுள்ளது. வெள்ளை ஈக்களை கட்டுப்படுத்த வேப்பெண்ணெய் அல்லது டயாஃபென்துரான் தெளிக்கவும்.",
      Marathi: "कापूस पिकावर पानांमधील चुरडा-मुरडा (लीफ कर्ल) आणि पांढऱ्या माशीचा प्रादुर्भाव आहे. डायफेन्थियुरॉन किंवा निंबोळी अर्क फवारा.",
      Telugu: "పత్తి పంటలో ఆకు ముడత వైరస్ (తెల్లదోమ ద్వారా) సోకింది. నివారణకు పసుపు రంగు జిగురు అట్టలు మరియు తగిన పురుగుమందు వాడండి.",
      Bengali: "তুলা গাছে পাতা কোঁকড়ানো ভাইরাস ও সাদা মাছির আক্রমণ। হলুদ ফাঁদ ও নিম তেল ব্যবহার করুন।",
      Gujarati: "કપાસમાં પાન વળવા અને સફેદ માખીનો ઉપદ્રવ છે. પીળા ચીકણા ટ્રેપ લગાવો અને ડાયાફેન્થિયુરોનનો છંટકાવ કરો.",
      Punjabi: "ਨਰਮੇ ਵਿੱਚ ਚਿੱਟੀ ਮੱਖੀ ਅਤੇ ਪੱਤਾ ਮਰੋੜ ਰੋਗ ਦਾ ਹਮਲਾ ਹੈ। ਪੀਲੇ ਟਰੈਪ ਲਗਾਓ ਅਤੇ ਡਾਇਫੈਂਥੀਯੂਰੋਨ ਦਾ ਛਿੜਕਾਅ ਕਰੋ।",
      Kannada: "ಹತ್ತಿ ಬೆಳೆಯಲ್ಲಿ ಎಲೆ ಸುರುಟು ರೋಗ ಹಾಗೂ ಬಿಳಿ ನೊಣದ ಬಾಧೆ ಇದೆ. ಹಳದಿ ಜಿಗುಟು ಬಲೆಗಳನ್ನು ಬಳಸಿ ಮತ್ತು ಕೀಟನಾಶಕ ಸಿಂಪಡಿಸಿ.",
      English: "Cotton Leaf Curl Virus detected, vectored by Whiteflies. Deploy yellow sticky traps and spray Diafenthiuron or Neem oil.",
    },
  },
  {
    id: "cotton-pink-bollworm",
    cropName: "Cotton",
    scientificName: "Gossypium hirsutum",
    diseaseName: "Pink Bollworm Damage",
    causalAgent: "Pectinophora gossypiella (Pest)",
    condition: "Pest Attack",
    severityDefault: "High",
    affectedPercentage: 42,
    symptoms: [
      "Rosette flowers with petals twisted and webbed together",
      "Exit holes on bolls with frass accumulation and lint discoloration",
      "Premature dropping of immature bolls",
    ],
    organicTreatment: [
      "Install 2 Pheromone traps per acre for monitoring; destroy rosette flowers manually.",
      "Release Trichogramma bactrae @ 60,000 parasites/acre at 7-day intervals.",
    ],
    chemicalTreatment: [
      "If ETL (>8 moths/trap/night) is crossed, spray Profenofos 50% EC @ 2ml per Liter of water.",
      "Alternate with Emamectin Benzoate 5% SG @ 0.5g/L of water under severe boll penetration.",
    ],
    fertilizerAdjustment: "Avoid excess urea application during peak boll formation; apply Potassium Nitrate 13:0:45 @ 10g/L.",
    weatherRisk: {
      conditions: "Relative humidity >80% with cloudy conditions favors rapid pest multiplication in the next 72 hours.",
      preventative: "Erect light traps @ 1/acre between 7 PM and 10 PM to mass trap nocturnal moths.",
    },
    localizedTranslations: {
      Marathi: "तुमच्या कापसाच्या पिकावर गुलाबी बोंड अळीचा प्रादुर्भाव दिसून येत आहे. हे नियंत्रणात आणण्यासाठी एकरी २ कामगंध सापळे लावा आणि जैविक उपचारासाठी ट्रायकोग्राम्माचा वापर करा.",
      Hindi: "कपास की फसल में गुलाबी सुंडी (Pink Bollworm) का प्रकोप है। प्रति एकड़ 2 फेरोमोन ट्रैप लगाएं और प्रोफेनोफॉस 2 मिली/लीटर का छिड़काव करें।",
      English: "Pink Bollworm attack on cotton crop. Install 2 pheromone traps per acre and spray Profenofos 50% EC @ 2ml/L if ETL is crossed.",
    },
  },
  {
    id: "soybean-rust",
    cropName: "Soybean",
    scientificName: "Glycine max",
    diseaseName: "Asian Soybean Rust",
    causalAgent: "Phakopsora pachyrhizi (Fungus)",
    condition: "Diseased",
    severityDefault: "High",
    affectedPercentage: 38,
    symptoms: [
      "Tiny polygonal tan-brown lesions on lower leaf surfaces",
      "Volcano-like uredinia pustules releasing yellowish-brown spores",
      "Early leaf yellowing and rapid defoliation during pod filling",
    ],
    organicTreatment: [
      "Foliar spray of 5% Neem Seed Kernel Extract (NSKE) at early flowering.",
      "Spray Trichoderma viride bio-fungicide @ 5g/L of water.",
    ],
    chemicalTreatment: [
      "Spray Hexaconazole 5% SC @ 2ml/L or Tebuconazole 25.9% EC @ 1ml/L of water.",
      "Alternate with Pyraclostrobin 20% WG @ 1g/L for broad systemic protection.",
    ],
    fertilizerAdjustment: "Apply Potash @ 25 kg/ha to improve cell wall resilience against fungal haustoria.",
    weatherRisk: {
      conditions: "Intermittent rain showers with extended leaf wetness (>6-8 hours) and temperatures 20°C-28°C.",
      preventative: "Maintain row spacing of 45 cm for better air circulation and sunlight penetration in canopy.",
    },
    localizedTranslations: {
      Marathi: "सोयाबीन पिकावर तांबेरा (Soybean Rust) रोगाची लागण झाली आहे. हेक्झाकोनॅझोल २ मिली किंवा टेब्युकोनॅझोल १ मिली प्रति लिटर पाण्यात मिसळून फवारा.",
      Hindi: "सोयाबीन में गेरुआ/रस्ट (Rust) रोग का प्रकोप है। हेक्साकोनाजोल (2 मिली/लीटर) या टेबुकोनाजोल (1 मिली/लीटर) का छिड़काव करें।",
      English: "Asian Soybean Rust detected. Spray Hexaconazole 5% SC @ 2ml/L or Tebuconazole 25.9% EC @ 1ml/L immediately.",
    },
  },
  {
    id: "potato-late-blight",
    cropName: "Potato",
    scientificName: "Solanum tuberosum",
    diseaseName: "Late Blight",
    causalAgent: "Phytophthora infestans (Oomycete)",
    condition: "Diseased",
    severityDefault: "Critical",
    affectedPercentage: 40,
    symptoms: [
      "Water-soaked irregular pale-green lesions that rapidly turn purplish-brown/black",
      "Delicate white fungal downy mildew growth on the underside of leaves under humid conditions",
      "Rapid systemic collapse ('blight') of entire foliage within 4-7 days",
    ],
    organicTreatment: [
      "Preventative prophylactic spray of copper sulfate + lime (Bordeaux mixture 1%) prior to monsoon onset.",
      "Bio-control with Bacillus subtilis strain QST 713 @ 4g/L water.",
    ],
    chemicalTreatment: [
      "Prophylactic: Mancozeb 75% WP @ 2.5g/L or Chlorothalonil 75% WP @ 2g/L.",
      "Curative/Systemic: Cymoxanil 8% + Mancozeb 64% WP @ 3g/L or Dimethomorph 50% WP @ 1g/L + Mancozeb.",
    ],
    fertilizerAdjustment: "Cease foliar nitrogen feeds immediately; supplement with calcium silicate or micronutrient boron.",
    weatherRisk: {
      conditions: "Cool temperatures (12°C–22°C) combined with prolonged high relative humidity (>90%) and rain.",
      preventative: "High earthing-up of potato ridges to protect tubers from downward spore washing.",
    },
    localizedTranslations: {
      Hindi: "आलू की फसल में पछेती झुलसा (Late Blight) का गंभीर प्रकोप है। तुरंत साइमोक्सानिल + मैंकोजेब या कॉपर आधारित फफूंदनाशी का छिड़काव करें।",
      Tamil: "உருளைக்கிழங்கு பயிரில் பிந்தைய கருகல் நோய் (Late Blight) தீவிரமாக உள்ளது. உடனே காப்பர் பூஞ்சாணக்கொல்லி தெளிக்கவும்.",
      Marathi: "बटाटा पिकावर लेट ब्लाइट (पछेती करपा) आला आहे. सायमॉक्सानिल + मॅनकोझेब बुरशीनाशकाची त्वरित फवारणी करा.",
      Telugu: "బంగాళాదుంపలో లేట్ బ్లైట్ తెగులు వ్యాపించింది. తక్షణమే సైమోక్సానిల్ + మాంకోజెబ్ మందును పిచికారీ చేయండి.",
      Bengali: "আলুর ধসা রোগ (লেট ব্লাইট) মারাত্মক আকার নিয়েছে। দ্রুত সাইমোক্সানিল ও ম্যানকোজেব স্প্রে করুন।",
      Gujarati: "બટાટાના પાકમાં પાછોતરો સુકારો (Late Blight) નો રોગ છે. તુરંત સાયમોક્સાનીલ અને મેન્કોઝેબનો છંટકાવ કરો.",
      Punjabi: "ਆਲੂ ਦੀ ਫਸਲ 'ਚ ਪਛੇਤਾ ਝੁਲਸਾ ਰੋਗ ਆ ਗਿਆ ਹੈ। ਤੁਰੰਤ ਸਾਇਮੋਕਸਾਨਿਲ + ਮੈਨਕੋਜ਼ੇਬ ਦਾ ਛਿੜਕਾਅ ਕਰੋ।",
      Kannada: "ಆಲೂಗಡ್ಡೆ ಬೆಳೆಯಲ್ಲಿ ಲೇಟ್ ಬ್ಲೈಟ್ ರೋಗ ತೀವ್ರವಾಗಿದೆ. ಸೈಮೊಕ್ಸಾನಿಲ್ ಮತ್ತು ಮ್ಯಾಂಕೋಜೆಬ್ ಸಿಂಪಡಿಸಿ.",
      English: "Potato Late Blight detected. Extremely aggressive; immediately spray Cymoxanil 8% + Mancozeb 64% WP @ 3g/L.",
    },
  },
  {
    id: "sugarcane-red-rot",
    cropName: "Sugarcane",
    scientificName: "Saccharum officinarum",
    diseaseName: "Red Rot",
    causalAgent: "Colletotrichum falcatum (Fungus)",
    condition: "Diseased",
    severityDefault: "Critical",
    affectedPercentage: 45,
    symptoms: [
      "Discoloration of third and fourth leaves with yellowing and drying from tip downward",
      "Internal stalk reddening with diagnostic white transverse cross-patches",
      "Sour fermentation/alcoholic odor when infected stalk is split longitudinally",
      "Premature cane lodging and loss of recoverable sucrose content",
    ],
    organicTreatment: [
      "Select disease-free certified nursery seed setts from disease-free crop zones.",
      "Hot water treatment of cane setts at 50°C for 2 hours before planting.",
      "Sett dipping in Trichoderma harzianum bio-fungicide @ 10g/L water for 15 minutes.",
    ],
    chemicalTreatment: [
      "Dip setts in Carbendazim 50% WP @ 2.0g/L or Thiophanate Methyl 70% WP @ 1.5g/L for 30 minutes prior to planting.",
      "Soil drenching with Copper Oxychloride 50% WP @ 3g/L along furrows to prevent secondary spreading.",
    ],
    fertilizerAdjustment: "Suspend excessive nitrogen; apply Muriate of Potash (MOP) @ 80 kg/ha to enhance rind silica and cell strength.",
    weatherRisk: {
      conditions: "Warm humid climate (28°C–32°C) with waterlogging in heavy black cotton soils during monsoon.",
      preventative: "Ensure furrow drainage to avoid standing water; promptly rogue out and burn infected cane clumps.",
    },
    localizedTranslations: {
      Marathi: "उसाच्या पिकावर तांबोरा (Red Rot / Colletotrichum falcatum) रोगाचा प्रादुर्भाव झाला आहे. तांबोराग्रस्त बेटं उपटून नष्ट करा, कार्बेन्डाझिमची फवारणी/आळवणी करा आणि पाण्याचा निचरा योग्य ठेवा.",
      Hindi: "गन्ने की फसल में लाल सड़न (Red Rot) रोग का प्रकोप है। संक्रमित पौधे तुरंत उखाड़ कर नष्ट करें और कार्बेन्डाजिम या कॉपर फफूंदनाशी का उपयोग करें।",
      English: "Sugarcane Red Rot detected. Rogue out diseased clumps immediately and treat setts with Carbendazim 50% WP.",
    },
  },
  {
    id: "healthy-maize",
    cropName: "Maize / Corn",
    scientificName: "Zea mays",
    diseaseName: "Healthy Crop (No Pathogen)",
    causalAgent: "None (Nutritionally Balanced)",
    condition: "Healthy",
    severityDefault: "Low",
    affectedPercentage: 0,
    symptoms: [
      "Vibrant green leaf lamina with uniform chlorophyll distribution",
      "No fungal spots, rust pustules, insect punctures, or chlorotic halos",
      "Robust turgid midrib and intact leaf margin",
    ],
    organicTreatment: [
      "Maintain organic soil health with vermicompost @ 2 tonnes/acre annually.",
      "Apply protective Panchagavya or seaweed extract spray (3ml/L) to sustain vegetative vigor.",
    ],
    chemicalTreatment: [
      "No chemical fungicide or insecticide intervention is required.",
      "Continue standard routine field monitoring once a week.",
    ],
    fertilizerAdjustment: "Maintain recommended NPK schedule (120:60:40 kg/ha) based on local soil health card.",
    weatherRisk: {
      conditions: "Normal growing conditions; watch for sudden waterlogging or extreme dry spells.",
      preventative: "Ensure furrow drainage to prevent root asphyxiation during excessive rainfall.",
    },
    localizedTranslations: {
      Hindi: "आपकी मक्के की फसल पूर्णतः स्वस्थ है। किसी भी फफूंदनाशी या कीटनाशक की आवश्यकता नहीं है। संतुलित पोषण जारी रखें।",
      Tamil: "உங்கள் மக்காச்சோள பயிர் முற்றிலும் ஆரோக்கியமாக உள்ளது. இரசாயன மருந்துகள் தேவையில்லை.",
      Marathi: "तुमचे मका पीक पूर्णपणे निरोगी आहे. कोणत्याही बुरशीनाशकाची किंवा कीटकनाशकाची आवश्यकता नाही.",
      Telugu: "మీ మొక్కజొన్న పంట ఆరోగ్యకరంగా ఉంది. ఎటువంటి రసాయన మందులు పిచికారీ చేయవలసిన అవసరం లేదు.",
      Bengali: "আপনার ভুট্টার ফসল সম্পূর্ণ সুস্থ। কোনো ছত্রাকনাশক বা কীটনাশক স্প্রে করার প্রয়োজন নেই।",
      Gujarati: "તમારો મકાઈનો પાક સંપૂર્ણપણે તંદુરસ્ત છે. કોઈ રાસાયણિક જંતુનાશકની જરૂર નથી.",
      Punjabi: "ਤੁਹਾਡੀ ਮੱਕੀ ਦੀ ਫਸਲ ਬਿਲਕੁਲ ਤੰਦਰੁਸਤ ਹੈ। ਕਿਸੇ ਕੀਟਨਾਸ਼ਕ ਦੀ ਲੋੜ ਨਹੀਂ ਹੈ।",
      Kannada: "ನಿಮ್ಮ ಮೆಕ್ಕೆಜೋಳ ಬೆಳೆ ಸಂಪೂರ್ಣವಾಗಿ ಆರೋಗ್ಯಕರವಾಗಿದೆ. ಯಾವುದೇ ಕೀಟನಾಶಕ ಅಗತ್ಯವಿಲ್ಲ.",
      English: "Foliage is completely healthy with 0% lesions. No pesticide or fungicide application needed.",
    },
  },
];

/**
 * Generates an offline diagnostic report from our built-in agricultural pathology knowledge base
 * This satisfies the SIH offline edge-resilience requirement when network/cloud is unavailable.
 */
export function generateOfflineDiagnosticReport(
  cropKey: string,
  language: string = "Hindi"
): DiagnosticReport {
  // Handle non-agricultural test
  if (cropKey === "invalid-test" || cropKey === "invalid_object") {
    const invalidReport: any = {
      is_valid_specimen: false,
      is_valid_crop_image: false,
      error_message: "The provided image does not clearly show plant foliage, leaf veins, stem, or agricultural crop. Please capture a clear, well-lit specimen.",
      error_message_marathi: "कृपया पिकाच्या पानाचे किंवा रोगाचे स्पष्ट छायाचित्र अपलोड करा. इतर वस्तू किंवा अस्पष्ट छायाचित्रे स्वीकारली जात नाहीत.",
      marathi_audio_script: "कृपया पिकाच्या पानाचे किंवा रोगाचे स्पष्ट छायाचित्र अपलोड करा. इतर वस्तू किंवा अस्पष्ट छायाचित्रे चालणार नाहीत.",
      confidence_score: 15,
      crop_details: {
        common_name: "Non-Crop Object / Blurry Specimen",
        scientific_name: "N/A",
        overall_status: "DISEASED",
        leaf_condition: "Invalid Image",
      },
      diagnoses: [
        {
          condition_name: "No Plant Pathogen Detected",
          disease_name: "No Plant Pathogen Detected",
          causal_agent: "Non-Agricultural Specimen",
          severity: "Low",
          confidence_score: 15,
          symptoms_observed: [
            "The provided specimen does not display plant foliage, leaf veins, or crop tissues.",
            "Identified as non-agricultural or excessively blurred object."
          ],
          treatment_plan: {
            organic_methods: [
              "Capture a clear, daylight photograph of a single crop leaf or diseased plant stem.",
              "Ensure camera is focused closely on lesion spots or insect damage."
            ],
            chemical_methods: ["No chemical treatment required."]
          }
        }
      ],
      weather_risk_advisory: {
        risk_level: "Low",
        advice: "Point camera directly at the affected crop foliage under natural lighting."
      },
      localized_advisory: {
        language: language,
        summary_script: language === "Hindi"
          ? "यह तस्वीर किसी फसल या पौधे की नहीं है। कृपया खेत में पौधे की पत्ती की साफ तस्वीर लें।"
          : "This image does not contain recognizable plant foliage. Please upload a clear photo of an infected leaf."
      },
      source: "offline_cache",
    };
    return normalizeDiagnosticReport(invalidReport, language);
  }

  const keyAliases: Record<string, string> = {
    cotton_pbw: "cotton-pink-bollworm",
    soybean_rust: "soybean-rust",
    rice_blast: "paddy-blast",
    sugarcane_redrot: "sugarcane-red-rot",
    tomato_blight: "tomato-early-blight",
    healthy_maize: "healthy-maize",
  };
  const resolvedKey = keyAliases[cropKey] || cropKey;
  const entry = OFFLINE_DISEASE_REGISTRY.find((e) => e.id === resolvedKey) || OFFLINE_DISEASE_REGISTRY[0];

  const localizedAudio =
    entry.localizedTranslations[language] ||
    entry.localizedTranslations["English"] ||
    `Diagnostic advisory for ${entry.cropName} (${entry.diseaseName}). Take immediate remedial action.`;

  const primaryDiagnosis = {
    disease_name: entry.diseaseName,
    casual_agent: entry.causalAgent,
    causal_agent: entry.causalAgent,
    severity_level: entry.severityDefault,
    estimated_affected_area_percentage: entry.affectedPercentage,
    key_symptoms: entry.symptoms,
  };

  const diagnoses: DiagnosisItem[] = entry.diagnosesList || [
    {
      ...primaryDiagnosis,
      remediation: {
        organic_treatment: entry.organicTreatment,
        chemical_treatment: entry.chemicalTreatment,
        fertilizer_adjustment: entry.fertilizerAdjustment,
      },
    },
  ];

  const rawReport: any = {
    is_valid_specimen: true,
    is_valid_crop_image: true,
    error_message: null,
    confidence_score: 94,
    crop_details: {
      common_name: entry.cropName,
      scientific_name: entry.scientificName,
      overall_status: entry.condition === "Healthy" ? "HEALTHY" : entry.condition === "Pest Attack" ? "PEST_INFESTED" : "DISEASED",
      leaf_condition: entry.condition,
    },
    diagnosis: primaryDiagnosis,
    diagnoses,
    remediation: {
      organic_treatment: entry.organicTreatment,
      chemical_treatment: entry.chemicalTreatment,
      fertilizer_adjustment: entry.fertilizerAdjustment,
    },
    weather_risk_advisory: {
      risk_level: entry.severityDefault === "Critical" || entry.severityDefault === "High" ? "High" : "Moderate",
      advice: `${entry.weatherRisk.conditions} ${entry.weatherRisk.preventative}`.trim(),
      high_risk_conditions: entry.weatherRisk.conditions,
      preventative_action: entry.weatherRisk.preventative,
    },
    localized_advisory: {
      language: language,
      summary_script: localizedAudio,
    },
    localized_text: {
      language: language,
      summary_audio_script: localizedAudio,
    },
    source: "offline_cache",
  };

  return normalizeDiagnosticReport(rawReport, language);
}
