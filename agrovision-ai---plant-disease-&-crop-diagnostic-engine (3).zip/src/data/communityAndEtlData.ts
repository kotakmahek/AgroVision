export interface CommunityIncident {
  id: string;
  farmerName: string;
  village: string;
  gramPanchayat: string;
  taluka: string;
  district: string;
  crop: string;
  diseaseOrPest: string;
  marathiName: string;
  severity: "Low" | "Moderate" | "High" | "Critical";
  reportedAgo: string;
  verificationsCount: number;
  hasUserVerified?: boolean;
  coordinates: { lat: number; lng: number };
  imageUrl: string;
  alertTriggered: boolean;
}

export interface EtlCropConfig {
  id: string;
  cropName: string;
  pestName: string;
  marathiName: string;
  samplingUnit: string;
  samplingPrompt: string;
  etlThresholdValue: number;
  etlThresholdDescription: string;
  unitLabel: string;
  minVal: number;
  maxVal: number;
  defaultVal: number;
  standardYieldLossPerUnit: number; // % yield loss per unit above ETL
  avgCropValuePerAcre: number; // ₹ value of harvest
  biologicalControl: {
    name: string;
    dosage: string;
    costPerAcre: number;
    delayDays: string;
  };
  chemicalControl: {
    name: string;
    dosage: string;
    activeIngredient: string;
    costPerAcre: number;
    waitingPeriodDays: number;
    cibrcReg: string;
  };
}

export interface KrishiSevaKendraStore {
  id: string;
  storeName: string;
  ownerName: string;
  licenseNumber: string;
  district: string;
  taluka: string;
  address: string;
  contactNumber: string;
  distanceKm: number;
  coordinates: { lat: number; lng: number };
  googleMapsUrl: string;
  operatingHours: string;
  isMahaAgriAuthorized: boolean;
  subsidiesOffered: string[];
  stockItems: {
    itemName: string;
    type: "Biological" | "Pheromone Trap" | "Bio-Fertilizer" | "Certified Chemical";
    price: string;
    inStock: boolean;
    subsidyAvailable: boolean;
  }[];
}

export interface PesticideQrBatch {
  qrCodeId: string;
  productName: string;
  brandName: string;
  activeIngredient: string;
  manufacturer: string;
  batchNumber: string;
  manufacturingDate: string;
  expiryDate: string;
  cibrcRegistrationNumber: string;
  status: "GENUINE_CERTIFIED" | "COUNTERFEIT_DETECTED" | "EXPIRED_BATCH";
  authenticityScore: number;
  hologramVerified: boolean;
  labTestReportUrl?: string;
  flagReason?: string;
}

export interface NutrientDeficiencyGuide {
  id: string;
  nutrient: string;
  symbol: string;
  category: "Macro (NPK)" | "Secondary" | "Micro";
  affectedLeafZone: "Older Lower Leaves" | "Middle Canopy" | "Young New Leaves / Shoot Tip";
  marathiTitle: string;
  symptomsEnglish: string;
  symptomsMarathi: string;
  visualCue: string;
  bgColor: string;
  borderColor: string;
  textColor: string;
  remedySoil: string;
  remedyFoliarSpray: string;
}

export const INITIAL_COMMUNITY_INCIDENTS: CommunityIncident[] = [
  {
    id: "inc-1",
    farmerName: "Sambhaji Patil",
    village: "Babhulgaon",
    gramPanchayat: "Babhulgaon GP",
    taluka: "Babhulgaon",
    district: "Yavatmal",
    crop: "Cotton (कापूस)",
    diseaseOrPest: "Pink Bollworm (गुलाबी बोंड अळी)",
    marathiName: "गुलाबी बोंड अळीचा प्रादुर्भाव",
    severity: "Critical",
    reportedAgo: "35 mins ago",
    verificationsCount: 4,
    hasUserVerified: false,
    coordinates: { lat: 20.452, lng: 78.291 },
    imageUrl: "/assets/presets/cotton_bollworm.jpg",
    alertTriggered: true,
  },
  {
    id: "inc-2",
    farmerName: "Dnyaneshwar Shinde",
    village: "Borgaon",
    gramPanchayat: "Borgaon GP",
    taluka: "Ausa",
    district: "Latur",
    crop: "Soybean (सोयाबीन)",
    diseaseOrPest: "Asian Soybean Rust (सोयाबीन तांबेरा)",
    marathiName: "सोयाबीन तांबेरा बुरशीजन्य रोग",
    severity: "High",
    reportedAgo: "1 hour ago",
    verificationsCount: 3,
    hasUserVerified: false,
    coordinates: { lat: 18.256, lng: 76.502 },
    imageUrl: "/assets/presets/soybean_rust.jpg",
    alertTriggered: true,
  },
  {
    id: "inc-3",
    farmerName: "Gajanan Raut",
    village: "Lakhandur",
    gramPanchayat: "Pardi GP",
    taluka: "Lakhandur",
    district: "Bhandara",
    crop: "Paddy (भात/धान)",
    diseaseOrPest: "Rice Blast (भाताचा करपा)",
    marathiName: "पानांवरील करपा रोग",
    severity: "High",
    reportedAgo: "3 hours ago",
    verificationsCount: 2,
    hasUserVerified: false,
    coordinates: { lat: 20.891, lng: 79.992 },
    imageUrl: "/assets/presets/rice_blast.jpg",
    alertTriggered: false,
  },
  {
    id: "inc-4",
    farmerName: "Bhausaheb Mane",
    village: "Shiroli",
    gramPanchayat: "Shiroli GP",
    taluka: "Hatkanangale",
    district: "Kolhapur",
    crop: "Sugarcane (ऊस)",
    diseaseOrPest: "Red Rot (उसाचा तांबोरा)",
    marathiName: "उसाचा लाल कुजव्या / तांबोरा",
    severity: "Critical",
    reportedAgo: "4 hours ago",
    verificationsCount: 5,
    hasUserVerified: true,
    coordinates: { lat: 16.741, lng: 74.298 },
    imageUrl: "/assets/presets/sugarcane_redrot.jpg",
    alertTriggered: true,
  },
  {
    id: "inc-5",
    farmerName: "Sharad Kadam",
    village: "Ozar",
    gramPanchayat: "Ozar GP",
    taluka: "Niphad",
    district: "Nashik",
    crop: "Tomato (टोमॅटो)",
    diseaseOrPest: "Early Blight (अगेती करपा)",
    marathiName: "अल्टरनेरिया करपा",
    severity: "Moderate",
    reportedAgo: "6 hours ago",
    verificationsCount: 1,
    hasUserVerified: false,
    coordinates: { lat: 20.092, lng: 73.914 },
    imageUrl: "/assets/presets/tomato_blight.jpg",
    alertTriggered: false,
  },
];

export const ETL_CONFIGS: EtlCropConfig[] = [
  {
    id: "cotton_pbw",
    cropName: "Cotton (कापूस)",
    pestName: "Pink Bollworm (Pectinophora gossypiella)",
    marathiName: "गुलाबी बोंड अळी",
    samplingUnit: "Larvae per 20 green bolls or rosette flowers",
    samplingPrompt: "Count of rosette flowers or live larvae found per 20 randomly checked bolls:",
    etlThresholdValue: 2,
    etlThresholdDescription: "ICAR/CICR ETL: 1 to 2 larvae per 20 bolls (or 8 male moths/trap/night for 3 consecutive days)",
    unitLabel: "larvae / 20 bolls",
    minVal: 0,
    maxVal: 15,
    defaultVal: 1,
    standardYieldLossPerUnit: 6.5,
    avgCropValuePerAcre: 52000,
    biologicalControl: {
      name: "Neem Seed Kernel Extract (NSKE 5%) or Trichogramma bactrae cards @ 3 cards/acre",
      dosage: "50 ml/10L water (NeemAzal 10,000 ppm) + install 4 Pheromone traps/acre",
      costPerAcre: 350,
      delayDays: "Recheck in 4 days",
    },
    chemicalControl: {
      name: "Emamectin Benzoate 5% SG or Chlorantraniliprole 18.5% SC",
      dosage: "Emamectin @ 4g or Chlorantraniliprole @ 3ml in 10L water",
      activeIngredient: "Emamectin Benzoate 5% SG (CIBRC Approved)",
      costPerAcre: 1850,
      waitingPeriodDays: 14,
      cibrcReg: "CIR-112948/2014-Emamectin Benzoate(SG)-491",
    },
  },
  {
    id: "soybean_rust",
    cropName: "Soybean (सोयाबीन)",
    pestName: "Asian Soybean Rust (Phakopsora pachyrhizi)",
    marathiName: "सोयाबीन तांबेरा बुरशी",
    samplingUnit: "Percentage of leaf surface covered with pustules",
    samplingPrompt: "Estimated rust pustule coverage on lower and middle canopy leaves:",
    etlThresholdValue: 5,
    etlThresholdDescription: "ICAR-IISR ETL: 5% of leaf area affected by brown rust pustules during flowering or pod development",
    unitLabel: "% leaf pustules",
    minVal: 0,
    maxVal: 50,
    defaultVal: 3,
    standardYieldLossPerUnit: 3.2,
    avgCropValuePerAcre: 38000,
    biologicalControl: {
      name: "Bio-fungicide Trichoderma viride 1% WP or Pseudomonas fluorescens",
      dosage: "50g in 10L water; spray during evening hours with non-ionic sticker",
      costPerAcre: 280,
      delayDays: "Monitor after 3 days",
    },
    chemicalControl: {
      name: "Hexaconazole 5% EC or Tebuconazole 25.9% EC",
      dosage: "Hexaconazole @ 20ml or Tebuconazole @ 10ml in 10L water",
      activeIngredient: "Hexaconazole 5% EC (Systemic Triazole)",
      costPerAcre: 1400,
      waitingPeriodDays: 21,
      cibrcReg: "CIR-98432/2012-Hexaconazole(EC)-108",
    },
  },
  {
    id: "paddy_blast",
    cropName: "Paddy / Rice (भात)",
    pestName: "Rice Blast (Magnaporthe oryzae)",
    marathiName: "भाताचा मानमोड्या / करपा",
    samplingUnit: "Spindle-shaped necrotic eye spots per leaf",
    samplingPrompt: "Average number of typical blast lesions observed per sampled leaf:",
    etlThresholdValue: 3,
    etlThresholdDescription: "ICAR-NRRI ETL: 2 to 3 typical spindle lesions per leaf or 1% leaf area affected",
    unitLabel: "lesions / leaf",
    minVal: 0,
    maxVal: 15,
    defaultVal: 2,
    standardYieldLossPerUnit: 5.0,
    avgCropValuePerAcre: 42000,
    biologicalControl: {
      name: "Pseudomonas fluorescens liquid formulation @ 2.5 ml/L",
      dosage: "Spray at tillering stage; avoid excessive nitrogen fertilizer top-dressing",
      costPerAcre: 260,
      delayDays: "Inspect in 4 days",
    },
    chemicalControl: {
      name: "Tricyclazole 75% WP or Isoprothiolane 40% EC",
      dosage: "Tricyclazole @ 6g in 10L water (0.6g/L) with fine hollow-cone nozzle",
      activeIngredient: "Tricyclazole 75% WP",
      costPerAcre: 1250,
      waitingPeriodDays: 30,
      cibrcReg: "CIR-74321/2010-Tricyclazole(WP)-340",
    },
  },
  {
    id: "sugarcane_redrot",
    cropName: "Sugarcane (ऊस)",
    pestName: "Red Rot (Colletotrichum falcatum)",
    marathiName: "उसाचा तांबोरा / लाल कुजव्या",
    samplingUnit: "Infected drying clumps per 100 meters of cane furrow",
    samplingPrompt: "Number of visibly yellowing or rotting clumps per 100m row:",
    etlThresholdValue: 2,
    etlThresholdDescription: "ICAR-SBI ETL: More than 1 clump showing crown yellowing and alcoholic odor per 100m",
    unitLabel: "diseased clumps / 100m",
    minVal: 0,
    maxVal: 12,
    defaultVal: 1,
    standardYieldLossPerUnit: 8.0,
    avgCropValuePerAcre: 110000,
    biologicalControl: {
      name: "Rogueing out diseased clumps + Trichoderma harzianum bio-drenching",
      dosage: "Rogue and incinerate infected stalks; drench soil with Trichoderma @ 10g/L",
      costPerAcre: 450,
      delayDays: "Daily monitoring",
    },
    chemicalControl: {
      name: "Carbendazim 50% WP or Thiophanate Methyl 70% WP",
      dosage: "Carbendazim @ 2g/L or Thiophanate Methyl @ 1.5g/L furrow drenching",
      activeIngredient: "Carbendazim 50% WP",
      costPerAcre: 2200,
      waitingPeriodDays: 45,
      cibrcReg: "CIR-55421/2008-Carbendazim(WP)-219",
    },
  },
];

export const MAHA_KRISHI_STORES: KrishiSevaKendraStore[] = [
  {
    id: "store-1",
    storeName: "MahaAgri Krishi Seva Kendra",
    ownerName: "Ashokrao Deshmukh",
    licenseNumber: "LIC/MH/YTL/2023/8492",
    district: "Yavatmal",
    taluka: "Babhulgaon",
    address: "Opposite APMC Market Yard, Main Road, Babhulgaon - 445101",
    contactNumber: "+91 94221 84920",
    distanceKm: 2.8,
    coordinates: { lat: 20.4485, lng: 78.3321 },
    googleMapsUrl: "https://www.google.com/maps/search/?api=1&query=20.4485,78.3321",
    operatingHours: "8:00 AM - 7:30 PM (Mon-Sat)",
    isMahaAgriAuthorized: true,
    subsidiesOffered: ["NFSM 50% Pheromone Trap Subsidy", "DBT Trichoderma Bio-Fungicide"],
    stockItems: [
      { itemName: "Pheromone Traps (Helilure/PBL) with Lures", type: "Pheromone Trap", price: "₹65 / trap", inStock: true, subsidyAvailable: true },
      { itemName: "Trichoderma viride 1% WP (MahaAgri Bio)", type: "Biological", price: "₹180 / 1kg", inStock: true, subsidyAvailable: true },
      { itemName: "Beauveria bassiana 1.15% WP", type: "Biological", price: "₹220 / 1kg", inStock: true, subsidyAvailable: true },
      { itemName: "Emamectin Benzoate 5% SG (Certified CIBRC)", type: "Certified Chemical", price: "₹480 / 100g", inStock: true, subsidyAvailable: false },
    ],
  },
  {
    id: "store-2",
    storeName: "Kisan Vikas Krishi Kendra",
    ownerName: "Vitthalrao Kulkarni",
    licenseNumber: "LIC/MH/LTR/2022/6120",
    district: "Latur",
    taluka: "Ausa",
    address: "Near Panchayat Samiti, Latur-Solapur Highway, Ausa - 413520",
    contactNumber: "+91 98230 45112",
    distanceKm: 4.1,
    coordinates: { lat: 18.2520, lng: 76.5020 },
    googleMapsUrl: "https://www.google.com/maps/search/?api=1&query=18.2520,76.5020",
    operatingHours: "8:30 AM - 8:00 PM (Mon-Sun)",
    isMahaAgriAuthorized: true,
    subsidiesOffered: ["PM Krishi Sinchayee Yojana Micro-nutrients", "State Bio-Pesticide Incentive"],
    stockItems: [
      { itemName: "Hexaconazole 5% EC (Fungicide)", type: "Certified Chemical", price: "₹380 / 500ml", inStock: true, subsidyAvailable: false },
      { itemName: "Pseudomonas fluorescens 1% WP", type: "Biological", price: "₹190 / 1kg", inStock: true, subsidyAvailable: true },
      { itemName: "NeemAzal 10,000 ppm (Bio-Insecticide)", type: "Biological", price: "₹410 / 500ml", inStock: true, subsidyAvailable: true },
    ],
  },
  {
    id: "store-3",
    storeName: "Sahyadri Shetkari Seva Sahakari Sanstha",
    ownerName: "Balasaheb Patil",
    licenseNumber: "LIC/MH/KOP/2021/4098",
    district: "Kolhapur",
    taluka: "Hatkanangale",
    address: "Station Road, Hatkanangale Market, Kolhapur - 416109",
    contactNumber: "+91 98901 77234",
    distanceKm: 3.5,
    coordinates: { lat: 16.7450, lng: 74.4530 },
    googleMapsUrl: "https://www.google.com/maps/search/?api=1&query=16.7450,74.4530",
    operatingHours: "9:00 AM - 7:00 PM (Mon-Sat)",
    isMahaAgriAuthorized: true,
    subsidiesOffered: ["MahaSugarcane Sett Treatment Subsidy", "Organic Soil Conditioner Scheme"],
    stockItems: [
      { itemName: "Trichoderma harzianum Bio-formulation", type: "Biological", price: "₹210 / 1kg", inStock: true, subsidyAvailable: true },
      { itemName: "Carbendazim 50% WP (Certified)", type: "Certified Chemical", price: "₹310 / 500g", inStock: true, subsidyAvailable: false },
      { itemName: "Potassium Schoenite / SOP (Soluble K)", type: "Bio-Fertilizer", price: "₹750 / 25kg", inStock: true, subsidyAvailable: true },
    ],
  },
  {
    id: "store-4",
    storeName: "Godavari Agro Agrochemicals & Seeds",
    ownerName: "Mangesh Jadhav",
    licenseNumber: "LIC/MH/NSK/2024/9912",
    district: "Nashik",
    taluka: "Niphad",
    address: "Khedgaon Phata, Niphad - 422303",
    contactNumber: "+91 97654 32189",
    distanceKm: 5.2,
    coordinates: { lat: 20.0760, lng: 74.1120 },
    googleMapsUrl: "https://www.google.com/maps/search/?api=1&query=20.0760,74.1120",
    operatingHours: "8:00 AM - 8:30 PM (Daily)",
    isMahaAgriAuthorized: true,
    subsidiesOffered: ["Horticulture Mission IPM Kit"],
    stockItems: [
      { itemName: "Copper Oxychloride 50% WP", type: "Certified Chemical", price: "₹420 / 500g", inStock: true, subsidyAvailable: false },
      { itemName: "Yellow Sticky Traps (Pack of 10)", type: "Pheromone Trap", price: "₹150 / pack", inStock: true, subsidyAvailable: true },
      { itemName: "Bio-NPK Consortium Liquid (1 Liter)", type: "Bio-Fertilizer", price: "₹290 / 1L", inStock: true, subsidyAvailable: true },
    ],
  },
];

export const SAMPLE_PESTICIDE_QR_DATABASE: PesticideQrBatch[] = [
  {
    qrCodeId: "QR-CORAGEN-8849-GEN",
    productName: "Coragen® Insecticide",
    brandName: "FMC India Ltd.",
    activeIngredient: "Chlorantraniliprole 18.5% w/w SC",
    manufacturer: "FMC India Private Limited, Savli Unit, Gujarat",
    batchNumber: "BN-2024-C9842",
    manufacturingDate: "02/2024",
    expiryDate: "01/2027",
    cibrcRegistrationNumber: "CIR-61,489/2009-Chlorantraniliprole(SC)-128",
    status: "GENUINE_CERTIFIED",
    authenticityScore: 100,
    hologramVerified: true,
    labTestReportUrl: "https://cibrc.nic.in/reports/BN-2024-C9842.pdf",
  },
  {
    qrCodeId: "QR-NEEMAZAL-10K-GEN",
    productName: "NeemAzal-T/S 1% (10,000 ppm)",
    brandName: "EID Parry India Ltd.",
    activeIngredient: "Azadirachtin 1% EC (Organic Bio-pesticide)",
    manufacturer: "Parry Bio, Cuddalore, Tamil Nadu",
    batchNumber: "PARRY-NM-8419",
    manufacturingDate: "05/2024",
    expiryDate: "04/2026",
    cibrcRegistrationNumber: "CIR-48,110/2004-Azadirachtin(EC)-99",
    status: "GENUINE_CERTIFIED",
    authenticityScore: 98,
    hologramVerified: true,
    labTestReportUrl: "https://mahaagri.gov.in/bio/PARRY-NM-8419.pdf",
  },
  {
    qrCodeId: "QR-FAKE-EMAMECTIN-001",
    productName: "Fake 'Emamectin Gold' 5% SG",
    brandName: "Counterfeit Packaging (Mimicking Syngenta/Proclaim)",
    activeIngredient: "Diluted Chalk & Industrial Dye (Unregistered)",
    manufacturer: "Unknown Underground Unit (No License)",
    batchNumber: "EM-FAKE-771",
    manufacturingDate: "11/2023",
    expiryDate: "10/2025",
    cibrcRegistrationNumber: "INVALID / NOT FOUND IN CIBRC REGISTRY",
    status: "COUNTERFEIT_DETECTED",
    authenticityScore: 12,
    hologramVerified: false,
    flagReason: "Critical Alert: CIBRC QR Cryptographic Hash Failed. Active chemical ingredient test failed purity threshold (0.4% vs 5.0% required). Do not apply to crops!",
  },
  {
    qrCodeId: "QR-EXPIRED-TRICYCLAZOLE",
    productName: "Beam 75% WP (Tricyclazole)",
    brandName: "Dow AgroSciences",
    activeIngredient: "Tricyclazole 75% WP",
    manufacturer: "Dow Crop Protection, Mumbai",
    batchNumber: "DW-BL-2020-09",
    manufacturingDate: "03/2020",
    expiryDate: "02/2022 (Expired)",
    cibrcRegistrationNumber: "CIR-32,940/1998-Tricyclazole(WP)-44",
    status: "EXPIRED_BATCH",
    authenticityScore: 45,
    hologramVerified: true,
    flagReason: "Warning: Genuine bottle, but chemical expiry date has elapsed by more than 2 years. Active compound degradation likely to cause phytotoxicity.",
  },
];

export const NUTRIENT_DEFICIENCY_GUIDES: NutrientDeficiencyGuide[] = [
  {
    id: "def-nitrogen",
    nutrient: "Nitrogen (N)",
    symbol: "N",
    category: "Macro (NPK)",
    affectedLeafZone: "Older Lower Leaves",
    marathiTitle: "नायट्रोजन (नत्र) कमतरता",
    symptomsEnglish: "Characteristic V-shaped chlorosis (yellowing) beginning at the leaf tip and progressing along the midrib. Older bottom leaves yellow and senesce prematurely while upper leaves stay pale green.",
    symptomsMarathi: "खालची जुनी पाने टोकाकडून मुख्य शिरेच्या बाजूने 'V' आकारात पिवळी पडतात. झाडाची वाढ खुंटते आणि फुटवे कमी येतात.",
    visualCue: "V-shaped yellowing starting from tip of mature lower leaves",
    bgColor: "bg-amber-950/40",
    borderColor: "border-amber-700/60",
    textColor: "text-amber-300",
    remedySoil: "Apply Neem-coated Urea @ 35 kg/acre as top-dressing or Ammonium Sulphate in split doses.",
    remedyFoliarSpray: "Foliar spray of 19:19:19 or 2% Urea solution (200g Urea in 100L water) for rapid nitrogen uptake.",
  },
  {
    id: "def-phosphorus",
    nutrient: "Phosphorus (P)",
    symbol: "P",
    category: "Macro (NPK)",
    affectedLeafZone: "Older Lower Leaves",
    marathiTitle: "फॉस्फरस (स्फुरद) कमतरता",
    symptomsEnglish: "Leaves develop distinct dark green to purplish-bronze or reddish-violet coloration along margins and underside veins due to anthocyanin pigment accumulation. Stunted root system.",
    symptomsMarathi: "पानांवर जांभळट-तांबूस किंवा तांबडी छटा येते (विशेषतः शिरांच्या बाजूला). मुळांची वाढ मंदावते आणि खोड बारीक राहते.",
    visualCue: "Dark purplish-red discoloration on margins of older foliage",
    bgColor: "bg-purple-950/40",
    borderColor: "border-purple-700/60",
    textColor: "text-purple-300",
    remedySoil: "Apply Single Super Phosphate (SSP) @ 50 kg/acre or DAP @ 30 kg/acre near root zone with soil moisture.",
    remedyFoliarSpray: "Foliar spray of 12:61:00 (Mono Ammonium Phosphate) @ 5g/L water during vegetative stage.",
  },
  {
    id: "def-potassium",
    nutrient: "Potassium (K)",
    symbol: "K",
    category: "Macro (NPK)",
    affectedLeafZone: "Older Lower Leaves",
    marathiTitle: "पोटॅशियम (पालाश) कमतरता",
    symptomsEnglish: "Marginal scorching and firing (leaf edge browning). Tips and outer edges of lower leaves look burned while midrib stays green. Weak stems lead to lodging and boll/fruit drop.",
    symptomsMarathi: "पानांच्या कडा करपल्यासारख्या तांबूस-तपकिरी दिसतात. पानाच्या मधला भाग हिरवा राहतो पण कडा वाळतात.",
    visualCue: "Marginal chlorosis and burnt-edge scorch on lower canopy",
    bgColor: "bg-orange-950/40",
    borderColor: "border-orange-700/60",
    textColor: "text-orange-300",
    remedySoil: "Apply Muriate of Potash (MOP 0:0:60) @ 25 kg/acre or Sulphate of Potash (SOP).",
    remedyFoliarSpray: "Foliar spray of 00:00:50 (Potassium Sulphate) or 13:00:45 (Potassium Nitrate) @ 5g/L during boll/grain filling.",
  },
  {
    id: "def-zinc",
    nutrient: "Zinc (Zn)",
    symbol: "Zn",
    category: "Micro",
    affectedLeafZone: "Middle Canopy",
    marathiTitle: "झिंक (जस्त) कमतरता / खैरा रोग",
    symptomsEnglish: "Interveinal chlorosis (white/pale bands between veins) with shortened internodes resulting in 'little leaf' rosette syndrome. Rusty brown blotches in paddy (Khaira disease).",
    symptomsMarathi: "पानांच्या शिरांमधील भाग पिवळा पडतो, पाने आकाराने लहान राहतात (लहान पानाच्या गुच्छे) आणि भातात तांबूस डाग दिसतात.",
    visualCue: "Interveinal bleached white-yellow stripes with stunted 'little leaf'",
    bgColor: "bg-yellow-950/40",
    borderColor: "border-yellow-700/60",
    textColor: "text-yellow-300",
    remedySoil: "Soil application of Zinc Sulphate (ZnSO4 21%) @ 10 kg/acre at sowing or land preparation.",
    remedyFoliarSpray: "Foliar spray of Chelated Zinc (EDTA Zn 12%) @ 1g/L or Zinc Sulphate 0.5% (5g/L) neutralized with 2.5g Slaked Lime.",
  },
  {
    id: "def-magnesium",
    nutrient: "Magnesium (Mg)",
    symbol: "Mg",
    category: "Secondary",
    affectedLeafZone: "Older Lower Leaves",
    marathiTitle: "मॅग्नेशियम कमतरता / कापसाचा लाल्या",
    symptomsEnglish: "Interveinal chlorosis progressing to purplish-red discoloration between veins while main veins remain distinctly green ('Lalya' disease in Bt Cotton). Premature defoliation.",
    symptomsMarathi: "कापसात पानांच्या शिरा हिरव्या राहून मधला भाग गडद लाल किंवा जांभळा पडतो (कापसाचा लाल्या रोग).",
    visualCue: "Vibrant red/purple coloration between green leaf veins in cotton",
    bgColor: "bg-rose-950/40",
    borderColor: "border-rose-700/60",
    textColor: "text-rose-300",
    remedySoil: "Apply Magnesium Sulphate (MgSO4) @ 15 kg/acre during square formation in black cotton soils.",
    remedyFoliarSpray: "Foliar spray of Magnesium Sulphate (MgSO4) @ 10g/L water at 60 and 90 days after sowing in cotton.",
  },
  {
    id: "def-iron",
    nutrient: "Iron (Fe)",
    symbol: "Fe",
    category: "Micro",
    affectedLeafZone: "Young New Leaves / Shoot Tip",
    marathiTitle: "लोह (आयर्न) कमतरता",
    symptomsEnglish: "Complete interveinal bleaching and ivory-yellow discoloration of youngest top leaves, while veins stay sharply dark green. Common in calcareous high-pH alkaline soils.",
    symptomsMarathi: "वरची कोवळी पाने पूर्णपणे पिवळी किंवा पांढरट पडतात पण शिरा बारीक हिरव्या जाळीसारख्या दिसतात (चुनखडीयुक्त जमिनीत जास्त आढळते).",
    visualCue: "Bright yellow/white chlorosis on newest top shoots with fine green veins",
    bgColor: "bg-emerald-950/40",
    borderColor: "border-emerald-700/60",
    textColor: "text-emerald-300",
    remedySoil: "Incorporate Ferrous Sulphate (FeSO4) @ 10 kg/acre mixed with well-rotted FYM/compost to prevent fixation.",
    remedyFoliarSpray: "Foliar spray of Chelated Iron (Fe-EDTA 12%) @ 1g/L or Ferrous Sulphate @ 5g/L + Citric Acid @ 1g/L water.",
  },
];

export const CROP_GROWTH_STAGES = [
  {
    stage: "Sowing / Seedling",
    durationDays: "0 - 25 Days",
    vulnerabilityLevel: "Moderate",
    vulnerabilityMultiplier: 1.2,
    criticalThreats: "Seed rot, Damping-off, Cutworms, Early stem fly",
    guidance: "Focus on biological seed treatment (Trichoderma / Rhizobium) and avoid excessive moisture.",
  },
  {
    stage: "Vegetative Growth",
    durationDays: "25 - 55 Days",
    vulnerabilityLevel: "Moderate",
    vulnerabilityMultiplier: 1.5,
    criticalThreats: "Sucking pests (Aphids, Jassids, Whitefly), Leaf spots, Rust initiation",
    guidance: "Install yellow sticky traps (10/acre); monitor ETL before initiating any chemical sprays.",
  },
  {
    stage: "Flowering & Squaring",
    durationDays: "55 - 85 Days",
    vulnerabilityLevel: "CRITICAL PEAK",
    vulnerabilityMultiplier: 3.2,
    criticalThreats: "Pink Bollworm, Flower shedding, Blight, Anthracnose, Pod borers",
    guidance: "Highest economic sensitivity! Damage to flower buds directly destroys 50-80% of harvest capacity. Deploy pheromone traps immediately.",
  },
  {
    stage: "Boll / Pod / Grain Formation",
    durationDays: "85 - 120 Days",
    vulnerabilityLevel: "High",
    vulnerabilityMultiplier: 2.8,
    criticalThreats: "Internal boll rot, Soybean Rust pustule outbreak, Stem rot, Fruit fly",
    guidance: "Ensure balanced potassium nutrition (SOP); adhere strictly to pre-harvest interval (PHI) for any sprays.",
  },
  {
    stage: "Maturity & Harvesting",
    durationDays: "120+ Days",
    vulnerabilityLevel: "Low",
    vulnerabilityMultiplier: 0.8,
    criticalThreats: "Post-monsoon mold, Aspergillus, Lodging",
    guidance: "Zero chemical pesticide sprays allowed to prevent residue in food grains; harvest at physiological maturity.",
  },
];
