/**
 * Real-World Weather Service for AgroVision AI
 * Fetches real-world temperature, relative humidity, and city/district name
 * to supply accurate micro-climate vectors before calling Gemini AI.
 */

export interface RealWorldWeatherData {
  temp: number;
  humidity: number;
  cityName: string;
  source?: string;
}

/**
 * Fetch real-world weather by latitude and longitude.
 * Queries the secure server /api/weather endpoint (which uses OpenWeather API if configured),
 * with instant client fallback to Open-Meteo API.
 */
export async function getRealWorldWeather(
  lat: number,
  lon: number
): Promise<RealWorldWeatherData> {
  // 1. Attempt server-side proxy which secures the OpenWeather API key
  try {
    const res = await fetch(`/api/weather?lat=${lat}&lon=${lon}`);
    if (res.ok) {
      const data = await res.json();
      return {
        temp: Number(data.temp),
        humidity: Number(data.humidity),
        cityName: data.cityName || `GPS (${lat.toFixed(2)}°, ${lon.toFixed(2)}°)`,
        source: data.source || "Live Weather Service",
      };
    }
  } catch (err) {
    console.warn("Server weather route fetch failed, using fallback:", err);
  }

  // 2. Direct client fallback using Open-Meteo
  try {
    const meteoUrl = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m`;
    const res = await fetch(meteoUrl);
    if (res.ok) {
      const data = await res.json();
      return {
        temp: Math.round(data.current?.temperature_2m ?? 28),
        humidity: Math.round(data.current?.relative_humidity_2m ?? 75),
        cityName: `GPS (${lat.toFixed(2)}°, ${lon.toFixed(2)}°)`,
        source: "Open-Meteo",
      };
    }
  } catch (err) {
    console.warn("Direct Open-Meteo fallback error:", err);
  }

  // 3. Sensible agricultural default fallback if offline
  return {
    temp: 28,
    humidity: 78,
    cityName: "Field Coordinates",
    source: "Field Baseline",
  };
}

/**
 * Common Agricultural Districts and Benchmarks in India / Maharashtra
 */
export const POPULAR_AGRI_LOCATIONS: Array<{
  name: string;
  state: string;
  lat: number;
  lon: number;
}> = [
  { name: "Nagpur (Vidarbha Cotton Belt)", state: "Maharashtra", lat: 21.1458, lon: 79.0882 },
  { name: "Nashik (Grape & Onion Hub)", state: "Maharashtra", lat: 19.9975, lon: 73.7898 },
  { name: "Pune (Western Maharashtra Sugarcane)", state: "Maharashtra", lat: 18.5204, lon: 73.8567 },
  { name: "Amravati (Soybean & Orange Zone)", state: "Maharashtra", lat: 20.9320, lon: 77.7523 },
  { name: "Kolhapur (Panchganga Basin)", state: "Maharashtra", lat: 16.7050, lon: 74.2433 },
  { name: "Latur (Marathwada Pulses Belt)", state: "Maharashtra", lat: 18.4088, lon: 76.5604 },
  { name: "Akola (Dr. PDKV Agri University)", state: "Maharashtra", lat: 20.7002, lon: 77.0082 },
  { name: "Indore (Malwa Plateau)", state: "Madhya Pradesh", lat: 22.7196, lon: 75.8577 },
  { name: "Ludhiana (Punjab Wheat & Paddy)", state: "Punjab", lat: 30.9010, lon: 75.8573 },
  { name: "Coimbatore (Tamil Nadu Cotton & Maize)", state: "Tamil Nadu", lat: 11.0168, lon: 76.9558 },
];
