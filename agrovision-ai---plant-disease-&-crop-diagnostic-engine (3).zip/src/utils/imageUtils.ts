/**
 * Utility to rasterize SVGs, data URLs, and images into clean JPEG Base64 data URLs
 * Suitable for both Gemini API multimodal inputs and HTML5 canvas display.
 */

export const compressImage = (file: File, maxWidth = 1280): Promise<string> => {
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;
        if (width > maxWidth) {
          height = Math.round((height * maxWidth) / width);
          width = maxWidth;
        }
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL('image/jpeg', 0.85));
      };
      img.src = e.target?.result as string;
    };
    reader.readAsDataURL(file);
  });
};

export function getImageSizeKb(dataUrl: string): number {
  if (!dataUrl) return 0;
  const commaIdx = dataUrl.indexOf(",");
  const base64Str = commaIdx !== -1 ? dataUrl.substring(commaIdx + 1) : dataUrl;
  const padding = (base64Str.endsWith("==") ? 2 : base64Str.endsWith("=") ? 1 : 0);
  const bytes = (base64Str.length * 3) / 4 - padding;
  return Math.round(bytes / 1024);
}

export async function ensureJpegDataUrl(
  imageUrl: string,
  maxDim: number = 1280,
  quality: number = 0.85
): Promise<string> {
  if (!imageUrl) {
    return "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEASABIAAD/2wBDAP//////////////////////////////////////////////////////////////////////////////////////wgALCAABAAEBAREA/8QAFBABAAAAAAAAAAAAAAAAAAAAAP/aAAgBAQABPxA=";
  }

  // If it's already a small compressed JPEG data URL (< 350 KB), return directly to avoid redundant re-encoding
  if (imageUrl.startsWith("data:image/jpeg;base64,") && imageUrl.length < 450000) {
    return imageUrl;
  }

  return new Promise((resolve) => {
    const img = new Image();
    let objectUrlToRevoke: string | null = null;

    // Only set crossOrigin for remote http(s) URLs; setting it on data: or blob: can cause browser load security errors
    if (imageUrl.startsWith("http://") || imageUrl.startsWith("https://")) {
      img.crossOrigin = "anonymous";
    }

    const cleanup = () => {
      if (objectUrlToRevoke) {
        try {
          URL.revokeObjectURL(objectUrlToRevoke);
        } catch {
          // ignore
        }
        objectUrlToRevoke = null;
      }
    };

    img.onload = () => {
      cleanup();
      try {
        const canvas = document.createElement("canvas");
        let width = img.naturalWidth || img.width || 600;
        let height = img.naturalHeight || img.height || 600;

        if (width > maxDim || height > maxDim) {
          if (width > height) {
            height = Math.round((height * maxDim) / width);
            width = maxDim;
          } else {
            width = Math.round((width * maxDim) / height);
            height = maxDim;
          }
        }

        canvas.width = Math.max(width, 100);
        canvas.height = Math.max(height, 100);
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          return resolve(imageUrl);
        }

        // Fill background with dark slate so transparent SVGs/PNGs render with clean contrast
        ctx.fillStyle = "#0f172a";
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

        const jpegUrl = canvas.toDataURL("image/jpeg", quality);
        resolve(jpegUrl);
      } catch (err) {
        console.warn("Canvas compression error, returning original:", err);
        resolve(imageUrl);
      }
    };

    img.onerror = (err) => {
      cleanup();
      console.warn("Image load warning for compression:", err);
      // Fallback: If it's an SVG data URI, convert to base64 data URI directly
      if (imageUrl.startsWith("data:image/svg+xml")) {
        try {
          const parts = imageUrl.split(",");
          if (parts.length > 1) {
            const raw = parts[1];
            const rawSvg = imageUrl.includes(";base64,") ? atob(raw) : decodeURIComponent(raw);
            const b64 = btoa(unescape(encodeURIComponent(rawSvg)));
            resolve(`data:image/svg+xml;base64,${b64}`);
            return;
          }
        } catch {
          // ignore
        }
      }
      resolve(imageUrl);
    };

    // If SVG data URL, convert into a Blob URL for reliable cross-browser image loading
    if (imageUrl.startsWith("data:image/svg+xml")) {
      try {
        const commaIdx = imageUrl.indexOf(",");
        const rawPayload = commaIdx !== -1 ? imageUrl.substring(commaIdx + 1) : imageUrl;
        const svgContent = imageUrl.includes(";base64,")
          ? atob(rawPayload)
          : decodeURIComponent(rawPayload);
        const blob = new Blob([svgContent], { type: "image/svg+xml;charset=utf-8" });
        const blobUrl = URL.createObjectURL(blob);
        objectUrlToRevoke = blobUrl;
        img.src = blobUrl;
        return;
      } catch {
        // fall through to setting src directly
      }
    }

    img.src = imageUrl;
  });
}

export interface InlineImageData {
  inlineData: {
    data: string;
    mimeType: string;
  };
}

/**
 * Converts an image URL, data URL, or local asset path into Base64 format
 * required for Gemini API multimodal requests without throwing "Failed to fetch".
 *
 * @param {string} url - The relative path, data URL, or URL of the image asset.
 * @returns {Promise<{inlineData: {data: string, mimeType: string}}>}
 */
export async function fetchImageAsInlineData(url: string): Promise<InlineImageData> {
  if (!url) {
    return {
      inlineData: {
        data: "/9j/4AAQSkZJRgABAQEASABIAAD/2wBDAP//////////////////////////////////////////////////////////////////////////////////////wgALCAABAAEBAREA/8QAFBABAAAAAAAAAAAAAAAAAAAAAP/aAAgBAQABPxA=",
        mimeType: "image/jpeg",
      },
    };
  }

  // 1. Data URLs: NEVER call fetch() because in sandboxed iframes or certain browsers,
  // fetch("data:...") throws "TypeError: Failed to fetch".
  if (url.startsWith("data:")) {
    try {
      const commaIndex = url.indexOf(",");
      if (commaIndex !== -1) {
        const header = url.substring(0, commaIndex);
        const dataPart = url.substring(commaIndex + 1);
        const mimeMatch = header.match(/^data:([^;,]+)/i);
        const rawMime = mimeMatch ? mimeMatch[1].toLowerCase() : "image/jpeg";

        // For SVG vectors, rasterize to clean JPEG base64 so Gemini vision models parse the foliar features
        if (rawMime.includes("svg")) {
          const rasterJpeg = await ensureJpegDataUrl(url);
          const rIndex = rasterJpeg.indexOf(",");
          const rasterData = rIndex !== -1 ? rasterJpeg.substring(rIndex + 1) : rasterJpeg;
          return {
            inlineData: {
              data: rasterData,
              mimeType: "image/jpeg",
            },
          };
        }

        // If it is already a base64 encoded image (jpeg, png, webp)
        if (header.includes(";base64")) {
          return {
            inlineData: {
              data: dataPart.trim(),
              mimeType: rawMime || "image/jpeg",
            },
          };
        }

        // If it's URL-encoded text/svg
        try {
          const decoded = decodeURIComponent(dataPart);
          const base64 = btoa(unescape(encodeURIComponent(decoded)));
          return {
            inlineData: {
              data: base64,
              mimeType: rawMime || "image/jpeg",
            },
          };
        } catch {
          const raster = await ensureJpegDataUrl(url);
          const cIndex = raster.indexOf(",");
          return {
            inlineData: {
              data: cIndex !== -1 ? raster.substring(cIndex + 1) : raster,
              mimeType: "image/jpeg",
            },
          };
        }
      }
    } catch (parseErr) {
      console.warn("Data URL inline parse warning:", parseErr);
    }
  }

  // 2. Relative or remote URLs (e.g. /assets/presets/cotton_bollworm.jpg):
  // First attempt standard fetch()
  try {
    const response = await fetch(url);
    if (response.ok) {
      const blob = await response.blob();
      const mimeType = blob.type || "image/jpeg";

      const base64Data = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => {
          const result = reader.result as string;
          const base64 = result.includes(",") ? result.split(",")[1] : result;
          resolve(base64);
        };
        reader.onerror = reject;
        reader.readAsDataURL(blob);
      });

      return {
        inlineData: {
          data: base64Data,
          mimeType,
        },
      };
    }
  } catch (fetchErr) {
    // Expected in offline, CORS-restricted, or sandbox iframe contexts
    console.warn("Direct fetch() bypassed for image asset; activating HTML Image canvas fallback:", fetchErr);
  }

  // 3. Robust fallback: Load image via HTML Image element and rasterize to Canvas
  try {
    const rasterJpeg = await ensureJpegDataUrl(url);
    const commaIndex = rasterJpeg.indexOf(",");
    const base64Data = commaIndex !== -1 ? rasterJpeg.substring(commaIndex + 1) : rasterJpeg;
    return {
      inlineData: {
        data: base64Data,
        mimeType: "image/jpeg",
      },
    };
  } catch (canvasErr) {
    console.warn("Canvas rasterization fallback note:", canvasErr);
  }

  // 4. Safe guaranteed non-crashing baseline
  return {
    inlineData: {
      data: "/9j/4AAQSkZJRgABAQEASABIAAD/2wBDAP//////////////////////////////////////////////////////////////////////////////////////wgALCAABAAEBAREA/8QAFBABAAAAAAAAAAAAAAAAAAAAAP/aAAgBAQABPxA=",
      mimeType: "image/jpeg",
    },
  };
}

/**
 * Handles quick preset clicks during demo, constructs API request payload,
 * and executes Gemini diagnostic scan.
 */
export async function handlePresetSelect(
  preset: {
    image: string;
    cropName: string;
    diseaseName: string;
    marathiName?: string;
    samplePayload: {
      location: string;
      humidity: number;
      temperature: number;
      crop?: string;
    };
  },
  apiKey?: string
): Promise<any> {
  try {
    // 1. Convert preset image asset to Inline Data safely
    const imagePart = await fetchImageAsInlineData(preset.image);

    // 2. Build text prompt with weather metadata
    const textPrompt = `
      Analyze this crop specimen. 
      Location: ${preset.samplePayload.location}
      Current Relative Humidity: ${preset.samplePayload.humidity}%
      Current Temperature: ${preset.samplePayload.temperature}°C
      Provide diagnosis, early warning risk score, and IPM remedies in Hindi/Marathi.
    `;

    // 3. Construct Gemini API Payload
    const requestBody = {
      contents: [
        {
          parts: [
            { text: textPrompt },
            imagePart, // Contains { inlineData: { data, mimeType } }
          ],
        },
      ],
    };

    // 4. Call Gemini API Endpoint:
    // If an explicit apiKey is provided, call Google Generative Language API directly;
    // Otherwise, route through the secure full-stack /api/diagnose endpoint.
    if (apiKey) {
      const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent?key=${apiKey}`;
      const response = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(requestBody),
      });
      const data = await response.json();
      return JSON.parse(data.candidates[0].content.parts[0].text);
    } else {
      const response = await fetch("/api/diagnose", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          imageBase64: imagePart.inlineData.data,
          mimeType: imagePart.inlineData.mimeType,
          location: preset.samplePayload.location,
          humidity: preset.samplePayload.humidity,
          temperature: preset.samplePayload.temperature,
          cropHint: `${preset.cropName} - ${preset.diseaseName} (${preset.marathiName || ""})`,
        }),
      });
      return await response.json();
    }
  } catch (err) {
    console.error("Failed to run preset analysis:", err);
    throw err;
  }
}
