import React, { useRef, useState, useEffect } from "react";
import { Camera, X, RefreshCw, CheckCircle2, AlertCircle } from "lucide-react";

interface CameraCaptureModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCapture: (base64Data: string) => void;
}

export const CameraCaptureModal: React.FC<CameraCaptureModalProps> = ({
  isOpen,
  onClose,
  onCapture,
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [capturedPhoto, setCapturedPhoto] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [facingMode, setFacingMode] = useState<"environment" | "user">("environment");

  useEffect(() => {
    if (isOpen && !capturedPhoto) {
      startCamera();
    } else {
      stopCamera();
    }
    return () => {
      stopCamera();
    };
  }, [isOpen, facingMode]);

  const startCamera = async () => {
    setErrorMsg(null);
    stopCamera();
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: facingMode,
          width: { ideal: 1920 },
          height: { ideal: 1080 },
        },
        audio: false,
      });
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
        await videoRef.current.play();
      }
    } catch (err: any) {
      console.error("Camera access error:", err);
      setErrorMsg("Unable to access camera. Please check camera permissions or upload an image file.");
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach((track) => track.stop());
      setStream(null);
    }
  };

  const handleSnap = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      canvas.width = video.videoWidth || 640;
      canvas.height = video.videoHeight || 480;
      const ctx = canvas.getContext("2d");
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL("image/jpeg", 0.9);
        setCapturedPhoto(dataUrl);
        stopCamera();
      }
    }
  };

  const handleRetake = () => {
    setCapturedPhoto(null);
    startCamera();
  };

  const handleConfirm = () => {
    if (capturedPhoto) {
      onCapture(capturedPhoto);
      onClose();
    }
  };

  const toggleFacingMode = () => {
    setFacingMode((prev) => (prev === "environment" ? "user" : "environment"));
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-slate-900 border border-emerald-700/50 rounded-2xl w-full max-w-xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="px-5 py-4 bg-emerald-950/80 border-b border-emerald-800/60 flex items-center justify-between">
          <div className="flex items-center gap-2 text-emerald-300 font-semibold text-sm">
            <Camera className="w-5 h-5 text-emerald-400" />
            <span>Field Leaf Camera Scanner</span>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Viewport */}
        <div className="relative bg-black flex-1 min-h-[340px] flex items-center justify-center overflow-hidden">
          {errorMsg ? (
            <div className="p-6 text-center max-w-sm">
              <AlertCircle className="w-12 h-12 text-rose-500 mx-auto mb-3" />
              <p className="text-slate-200 text-sm font-medium mb-4">{errorMsg}</p>
              <button
                onClick={startCamera}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold"
              >
                Retry Access
              </button>
            </div>
          ) : capturedPhoto ? (
            <div className="relative w-full h-full flex items-center justify-center">
              <img
                src={capturedPhoto}
                alt="Captured crop"
                className="max-h-[55vh] w-auto object-contain rounded-lg"
              />
              <div className="absolute top-3 left-3 bg-emerald-900/90 text-emerald-200 px-3 py-1 rounded-full text-xs font-medium border border-emerald-500/30">
                Snapshot Preview Ready
              </div>
            </div>
          ) : (
            <>
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover max-h-[55vh]"
              />
              {/* Botanical Focus Frame Overlay */}
              <div className="absolute inset-8 sm:inset-14 border-2 border-dashed border-emerald-400/70 rounded-2xl pointer-events-none flex flex-col justify-between p-3">
                <div className="flex justify-between text-emerald-400 text-[11px] font-mono bg-black/40 px-2 py-0.5 rounded w-fit">
                  [POINT AT AFFECTED LEAF LESION]
                </div>
                <div className="self-center text-center text-emerald-200 text-xs bg-black/60 px-3 py-1 rounded-full border border-emerald-500/20">
                  Keep leaf in direct focus under good daylight
                </div>
              </div>
            </>
          )}
          <canvas ref={canvasRef} className="hidden" />
        </div>

        {/* Controls Footer */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex items-center justify-between gap-3">
          {!capturedPhoto ? (
            <>
              <button
                onClick={toggleFacingMode}
                className="flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-medium transition"
                title="Switch Camera (Front/Back)"
              >
                <RefreshCw className="w-4 h-4" />
                <span>Switch Lens</span>
              </button>

              <button
                id="capture-leaf-snap-btn"
                onClick={handleSnap}
                disabled={!!errorMsg}
                className="flex-1 max-w-[200px] mx-auto py-2.5 px-5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-full font-bold text-sm shadow-lg shadow-emerald-950 flex items-center justify-center gap-2 transition"
              >
                <div className="w-3.5 h-3.5 rounded-full bg-white animate-ping" />
                Capture
              </button>

              <button
                onClick={onClose}
                className="px-3 py-2 text-slate-400 hover:text-white text-xs font-medium"
              >
                Cancel
              </button>
            </>
          ) : (
            <div className="flex items-center justify-end gap-3 w-full">
              <button
                onClick={handleRetake}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-medium transition"
              >
                Retake
              </button>
              <button
                id="use-photo-btn"
                onClick={handleConfirm}
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold shadow flex items-center gap-1.5 transition"
              >
                <CheckCircle2 className="w-4 h-4" />
                Use Photo for Diagnosis
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
