import React, { useState, useEffect } from "react";
import { 
  DiagnosticReport, 
  SupportedLanguage,
  DiagnosisItem,
  toSIHJson,
  toMaharashtraSIHJson
} from "../types";
import {
  AlertTriangle,
  CheckCircle2,
  Bug,
  Leaf,
  Volume2,
  VolumeX,
  Play,
  Square,
  FileCode2,
  Printer,
  CloudSun,
  FlaskConical,
  Sprout,
  ShieldAlert,
  ChevronRight,
  Sparkles,
  PhoneCall,
  ExternalLink,
  MapPin,
  Share2,
  RotateCcw,
  Layers,
  Activity,
  Info,
  Calendar,
  TrendingUp,
  Building2,
  ClipboardCheck
} from "lucide-react";
import { GrowthCycleCalendar } from "./GrowthCycleCalendar";
import { AgriDealerPrescriptionModal } from "./AgriDealerPrescriptionModal";
import { MarathiSpeechPlayer } from "./MarathiSpeechPlayer";
import { speechEngine } from "../utils/speechEngine";

interface DiagnosticReportViewProps {
  report: DiagnosticReport;
  uploadedImageUrl: string | null;
  onReset: () => void;
  onOpenEmergency: () => void;
}

const LANGUAGE_SPEECH_CODES: Record<string, string> = {
  Hindi: "hi-IN",
  Tamil: "ta-IN",
  Marathi: "mr-IN",
  Telugu: "te-IN",
  Bengali: "bn-IN",
  Gujarati: "gu-IN",
  Punjabi: "pa-IN",
  Kannada: "kn-IN",
  English: "en-IN",
};

export const DiagnosticReportView: React.FC<DiagnosticReportViewProps> = ({
  report,
  uploadedImageUrl,
  onReset,
  onOpenEmergency,
}) => {
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [speechRate, setSpeechRate] = useState<number>(0.9); // slightly slower for clear comprehension
  const [showJsonRaw, setShowJsonRaw] = useState(false);
  const [jsonSchemaType, setJsonSchemaType] = useState<"maharashtra" | "sih">("maharashtra");
  const [copiedJson, setCopiedJson] = useState(false);
  const [showDealerSlipModal, setShowDealerSlipModal] = useState(false);
  const [activeTab, setActiveTab] = useState<"treatment" | "symptoms" | "weather">("treatment");
  const [selectedDiagnosisIndex, setSelectedDiagnosisIndex] = useState<number | "all">("all");

  // Audio Speech Synthesis
  useEffect(() => {
    return () => {
      speechEngine.stop();
    };
  }, []);

  const handleToggleSpeech = () => {
    if (!speechEngine.isSupported()) {
      alert("Text-to-speech audio is not supported in this browser.");
      return;
    }

    if (isPlayingAudio) {
      speechEngine.stop();
      setIsPlayingAudio(false);
      return;
    }

    const textToSpeak = report.localized_text?.summary_audio_script || "";
    if (!textToSpeak) return;

    const langCode = LANGUAGE_SPEECH_CODES[report.localized_text?.language] || "mr-IN";
    speechEngine.speak(textToSpeak, langCode, {
      rate: speechRate,
      onStart: () => setIsPlayingAudio(true),
      onEnd: () => setIsPlayingAudio(false),
      onError: () => setIsPlayingAudio(false),
    });
  };


  const copyJsonToClipboard = () => {
    const payload = jsonSchemaType === "maharashtra"
      ? (report.maharashtra_json || toMaharashtraSIHJson(report))
      : (report.sih_json || toSIHJson(report));
    navigator.clipboard.writeText(JSON.stringify(payload, null, 2));
    setCopiedJson(true);
    setTimeout(() => setCopiedJson(false), 2000);
  };

  const handlePrint = () => {
    window.print();
  };

  const getSeverityBadgeColor = (severity: string) => {
    switch (severity) {
      case "Critical":
        return "bg-rose-500/20 text-rose-300 border-rose-500/40";
      case "High":
        return "bg-orange-500/20 text-orange-300 border-orange-500/40";
      case "Moderate":
        return "bg-amber-500/20 text-amber-300 border-amber-500/40";
      case "Low":
      default:
        return "bg-emerald-500/20 text-emerald-300 border-emerald-500/40";
    }
  };

  const getConditionColor = (cond: string) => {
    switch (cond) {
      case "Healthy":
        return "bg-emerald-600 text-white";
      case "Pest Attack":
        return "bg-red-600 text-white";
      case "Nutrient Deficiency":
        return "bg-amber-600 text-white";
      case "Diseased":
      default:
        return "bg-rose-700 text-white";
    }
  };

  // If the image was judged invalid or non-agricultural per SIH workflow:
  const isInvalidSpecimen = report.is_valid_specimen === false || report.is_valid_crop_image === false;

  if (isInvalidSpecimen) {
    return (
      <div className="bg-slate-900 border border-rose-800/60 rounded-2xl p-6 sm:p-8 shadow-xl max-w-4xl mx-auto my-6 animate-fade-in text-white">
        <div className="flex items-start gap-4">
          <div className="p-3 bg-rose-950/80 border border-rose-700/50 rounded-xl text-rose-400 shrink-0">
            <AlertTriangle className="w-8 h-8" />
          </div>
          <div className="space-y-3 flex-1">
            <div className="flex items-center justify-between">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider bg-rose-950 text-rose-400 border border-rose-800">
                Specimen Validation Notice
              </span>
              <span className="text-xs text-rose-400 font-mono bg-rose-950/60 px-2 py-0.5 rounded border border-rose-800">
                is_valid_specimen: false
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-rose-200">
              Invalid Agricultural Specimen
            </h2>
            <p className="text-sm text-slate-300 leading-relaxed">
              {report.error_message ||
                "AgroVision AI's visual screening determined that the uploaded photograph is blurry, irrelevant, or does not clearly show an agricultural crop leaf, stem, or fruit."}
            </p>

            <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-4 space-y-2 text-xs text-slate-300">
              <p className="font-semibold text-emerald-400">SIH Specimen Capture Guidelines:</p>
              <ul className="list-disc list-inside space-y-1 text-slate-400">
                <li>Capture a clear, close-up shot of the single affected leaf showing lesion margins or pest signs.</li>
                <li>Avoid blurry hands, strong backlight, or camera motion artifacts.</li>
                <li>Ensure the plant foliage or fruit fills at least 60% of the frame in natural lighting.</li>
              </ul>
            </div>

            {(report.marathi_audio_script || report.localized_text?.summary_audio_script) && (
              <MarathiSpeechPlayer
                marathiScript={report.marathi_audio_script || report.localized_text?.summary_audio_script || ""}
                title="अस्पष्ट छायाचित्र मार्गदर्शन (Marathi Voice Guidance)"
                subTitle="स्पष्ट छायाचित्र काढण्यासाठी सूचना ऐका"
                className="mt-2"
              />
            )}

            <div className="pt-2 flex flex-wrap gap-3">
              <button
                onClick={onReset}
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-sm font-bold flex items-center gap-2 shadow-md transition"
              >
                <RotateCcw className="w-4 h-4" />
                Capture / Upload New Photo
              </button>
              <button
                onClick={onOpenEmergency}
                className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-sm font-medium border border-slate-700 flex items-center gap-2 transition"
              >
                <PhoneCall className="w-4 h-4 text-rose-400" />
                Contact Kisan Helpdesk
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const { crop_details, diagnosis, remediation, weather_risk_advisory, localized_text } = report;

  // Extract all diagnoses (multi-pathogen support)
  const diagnosesList: DiagnosisItem[] = (report.diagnoses && report.diagnoses.length > 0)
    ? report.diagnoses
    : [
        {
          disease_name: diagnosis.disease_name,
          causal_agent: diagnosis.causal_agent || diagnosis.casual_agent,
          casual_agent: diagnosis.causal_agent || diagnosis.casual_agent,
          severity_level: diagnosis.severity_level,
          estimated_affected_area_percentage: diagnosis.estimated_affected_area_percentage,
          key_symptoms: diagnosis.key_symptoms,
          remediation: remediation,
        },
      ];

  const isMultiDiagnosis = diagnosesList.length > 1;

  const totalAffectedArea = Math.min(
    100,
    diagnosesList.reduce((acc, d) => acc + (d.estimated_affected_area_percentage || 0), 0)
  );

  return (
    <div className="max-w-5xl mx-auto my-6 space-y-6 animate-fade-in text-slate-100">
      {/* Top Header Card */}
      <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-emerald-950 border border-emerald-700/50 rounded-2xl p-5 sm:p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-emerald-800/50">
          <div className="space-y-1">
            <div className="flex items-center gap-2.5 flex-wrap">
              {crop_details.overall_status && (
                <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-bold bg-slate-900 text-emerald-400 border border-emerald-600/60">
                  Status: {crop_details.overall_status}
                </span>
              )}
              <span className={`px-2.5 py-0.5 rounded-full text-xs font-extrabold tracking-wide uppercase shadow-sm ${getConditionColor(crop_details.leaf_condition)}`}>
                {crop_details.leaf_condition}
              </span>
              {isMultiDiagnosis ? (
                <>
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-950 text-amber-300 border border-amber-600/70 flex items-center gap-1">
                    <Bug className="w-3.5 h-3.5 text-amber-400" />
                    Co-Infection: {diagnosesList.length} Pathologies
                  </span>
                  {diagnosesList.map((d, idx) => (
                    <span
                      key={idx}
                      className={`px-2.5 py-0.5 rounded-full text-xs font-semibold border ${getSeverityBadgeColor(d.severity_level)}`}
                    >
                      {d.disease_name}: {d.severity_level}
                    </span>
                  ))}
                </>
              ) : (
                <span className={`px-2.5 py-0.5 rounded-full text-xs font-semibold border ${getSeverityBadgeColor(diagnosis.severity_level)}`}>
                  Severity: {diagnosis.severity_level}
                </span>
              )}
              <span className="px-2.5 py-0.5 rounded-full text-xs font-medium bg-emerald-950/80 text-emerald-300 border border-emerald-700/50 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-emerald-400" />
                AI Confidence: {(report.confidence_score * 100).toFixed(0)}%
              </span>
              {report.source === "offline_cache" && (
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-amber-950 text-amber-300 border border-amber-700">
                  Offline Edge Backup
                </span>
              )}
            </div>

            <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-white font-['Outfit',sans-serif] pt-1">
              {crop_details.common_name} — {diagnosesList.map((d) => d.disease_name).join(" + ")}
            </h2>
            <p className="text-sm text-emerald-300/90 italic font-mono flex items-center gap-2 flex-wrap">
              <span>Scientific: {crop_details.scientific_name}</span>
              <span className="text-slate-500">•</span>
              <span>Causal Agents: {diagnosesList.map((d) => d.causal_agent || d.casual_agent).join(" & ")}</span>
            </p>
          </div>

          {/* Action buttons: New scan, Print, Raw JSON, Growth Calendar, Agri-Dealer Slip */}
          <div className="flex items-center gap-2 shrink-0 flex-wrap">
            <button
              id="agri-dealer-slip-btn"
              onClick={() => setShowDealerSlipModal(true)}
              className="px-3 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-xs font-bold border border-amber-500/80 flex items-center gap-1.5 transition shadow-sm"
              title="Generate & print medicine prescription slip for local agri-input dealer / Krishi Seva Kendra"
            >
              <Building2 className="w-3.5 h-3.5 text-amber-100" />
              <span>Agri-Dealer Slip</span>
            </button>
            <button
              onClick={() => {
                document.getElementById("growth-cycle-calendar-section")?.scrollIntoView({ behavior: "smooth" });
              }}
              className="px-3 py-2 bg-emerald-950/80 hover:bg-emerald-900 text-emerald-300 hover:text-white rounded-xl text-xs font-bold border border-emerald-700/60 flex items-center gap-1.5 transition shadow-sm"
              title="Jump to Crop Growth Cycle Calendar"
            >
              <Calendar className="w-3.5 h-3.5 text-emerald-400" />
              <span>Growth Calendar</span>
            </button>
            <button
              onClick={handlePrint}
              className="p-2.5 bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl text-xs font-medium border border-slate-700 transition"
              title="Print Diagnostic Report / Save as PDF"
            >
              <Printer className="w-4 h-4" />
            </button>
            <button
              onClick={() => setShowJsonRaw(!showJsonRaw)}
              className="px-3 py-2 bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl text-xs font-mono font-medium border border-slate-700 flex items-center gap-1.5 transition"
              title="View Raw SIH JSON Schema"
            >
              <FileCode2 className="w-4 h-4 text-emerald-400" />
              <span>JSON</span>
            </button>
            <button
              onClick={onReset}
              className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold shadow flex items-center gap-1.5 transition"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>New Scan</span>
            </button>
          </div>
        </div>

        {/* Localized Audio Broadcast Banner */}
        <div className="mt-4 bg-emerald-950/60 border border-emerald-600/40 rounded-xl p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-start gap-3">
            <button
              id="play-audio-script-btn"
              onClick={handleToggleSpeech}
              className={`p-2.5 rounded-full shrink-0 shadow-md transition flex items-center justify-center ${
                isPlayingAudio
                  ? "bg-rose-600 hover:bg-rose-500 text-white animate-pulse"
                  : "bg-emerald-500 hover:bg-emerald-400 text-emerald-950 font-bold"
              }`}
              title={isPlayingAudio ? "Stop Voice Advisory" : "Listen in Selected Language"}
            >
              {isPlayingAudio ? <Square className="w-4 h-4" /> : <Play className="w-4 h-4 fill-current ml-0.5" />}
            </button>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-emerald-300 uppercase tracking-wide flex items-center gap-1">
                  <Volume2 className="w-3.5 h-3.5 text-emerald-400" />
                  Voice Advisory ({localized_text?.language || "Localized"})
                </span>
                {isPlayingAudio && (
                  <span className="inline-flex items-center gap-1 text-[11px] text-emerald-400 font-medium animate-pulse">
                    Playing audio advisory...
                  </span>
                )}
              </div>
              <p className="text-xs sm:text-sm text-slate-200 mt-0.5 font-sans leading-relaxed">
                "{localized_text?.summary_audio_script}"
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
            <span className="text-[11px] text-slate-400">Speed:</span>
            {[0.8, 1.0, 1.2].map((rate) => (
              <button
                key={rate}
                onClick={() => setSpeechRate(rate)}
                className={`px-2 py-0.5 text-[10px] font-semibold rounded border ${
                  speechRate === rate
                    ? "bg-emerald-600 text-white border-emerald-500"
                    : "bg-slate-800 text-slate-400 border-slate-700 hover:text-white"
                }`}
              >
                {rate}x
              </button>
            ))}
          </div>
        </div>

        {/* AgroVision Maharashtra SIH26131 Early-Warning & Outbreak Intelligence Banner */}
        <div className="mt-4 bg-gradient-to-r from-slate-950 via-slate-900 to-amber-950/70 border border-amber-500/50 rounded-xl p-4 space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2.5 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-ping" />
              <span className="text-xs font-bold uppercase tracking-wider text-amber-300 font-mono flex items-center gap-1.5">
                <ShieldAlert className="w-4 h-4 text-amber-400" />
                AgroVision Maharashtra (SIH26131) Outbreak Intelligence
              </span>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-slate-900 text-amber-300 border border-amber-500/50">
                Variety: {crop_details.variety || "BT Cotton"}
              </span>
              <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-slate-900 text-slate-300 border border-slate-700">
                Stage: {crop_details.growth_stage || "Flowering / Boll Formation"}
              </span>
              {crop_details.crop_name_marathi && (
                <span className="text-xs font-medium px-2 py-0.5 rounded-full bg-slate-900 text-emerald-400 border border-emerald-800">
                  मराठी: {crop_details.crop_name_marathi}
                </span>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {/* Outbreak Risk Score Gauge */}
            <div className="p-3 bg-slate-950/90 rounded-xl border border-slate-800 space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400 font-medium">Block Outbreak Risk Score:</span>
                <span className={`font-mono font-black text-base ${(report.predictive_weather_risk?.block_outbreak_risk_score ?? 85) >= 80 ? "text-rose-400" : (report.predictive_weather_risk?.block_outbreak_risk_score ?? 85) >= 60 ? "text-amber-400" : "text-emerald-400"}`}>
                  {report.predictive_weather_risk?.block_outbreak_risk_score ?? 85}/100
                </span>
              </div>
              <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden">
                <div 
                  className={`h-full transition-all duration-500 rounded-full ${(report.predictive_weather_risk?.block_outbreak_risk_score ?? 85) >= 80 ? "bg-rose-500" : (report.predictive_weather_risk?.block_outbreak_risk_score ?? 85) >= 60 ? "bg-amber-500" : "bg-emerald-500"}`}
                  style={{ width: `${report.predictive_weather_risk?.block_outbreak_risk_score ?? 85}%` }}
                />
              </div>
              <div className="flex items-center justify-between text-[11px] text-slate-400">
                <span>Risk Level:</span>
                <span className="font-bold text-amber-300 uppercase">
                  {report.predictive_weather_risk?.risk_level || "CRITICAL_HOTSPOT"}
                </span>
              </div>
            </div>

            {/* Contributing Climate Vectors */}
            <div className="p-3 bg-slate-950/90 rounded-xl border border-slate-800 space-y-1 text-xs md:col-span-2">
              <span className="text-slate-400 font-medium block">Micro-Climate Vector Advisory:</span>
              <p className="text-slate-300 leading-relaxed font-sans">
                {report.predictive_weather_risk?.contributing_factors || "Relative humidity >80% with cloudy conditions favors rapid pest multiplication in the next 72 hours."}
              </p>
            </div>
          </div>

          {/* Hotspot Geospatial Alert Trigger Banner */}
          {report.hotspot_geospatial_flag && (
            <div className="p-3 bg-rose-950/30 border border-rose-500/40 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
              <div className="flex items-start gap-2.5">
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-rose-300 uppercase">
                      Geospatial Block Alert Active ({report.hotspot_geospatial_flag.recommended_radius_km} km Radius)
                    </span>
                    <span className="text-[10px] bg-rose-900/80 text-rose-200 px-1.5 py-0.2 rounded font-mono">
                      Broadcast Triggered
                    </span>
                  </div>
                  <p className="text-slate-200 mt-0.5 font-medium">
                    "{report.hotspot_geospatial_flag.alert_message_marathi}"
                  </p>
                </div>
              </div>
              <MarathiSpeechPlayer
                marathiScript={report.hotspot_geospatial_flag.alert_message_marathi}
                variant="compact"
                className="self-start sm:self-center shrink-0"
              />
            </div>
          )}
        </div>

        {/* Multi-Pathogen Pathology Filter Switcher */}
        {isMultiDiagnosis && (
          <div className="mt-4 pt-3.5 border-t border-emerald-800/40 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-emerald-400" />
                Pathology View:
              </span>
              <button
                onClick={() => setSelectedDiagnosisIndex("all")}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                  selectedDiagnosisIndex === "all"
                    ? "bg-emerald-600 text-white shadow-md ring-1 ring-emerald-400"
                    : "bg-slate-800 text-slate-300 hover:text-white border border-slate-700"
                }`}
              >
                <span>All Pathologies ({diagnosesList.length})</span>
              </button>
              {diagnosesList.map((d, idx) => (
                <button
                  key={idx}
                  onClick={() => setSelectedDiagnosisIndex(idx)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                    selectedDiagnosisIndex === idx
                      ? "bg-emerald-600 text-white shadow-md ring-1 ring-emerald-400"
                      : "bg-slate-800 text-slate-300 hover:text-white border border-slate-700"
                  }`}
                >
                  <span>{d.disease_name}</span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-950 font-mono text-amber-300">
                    {d.estimated_affected_area_percentage}%
                  </span>
                </button>
              ))}
            </div>
            <div className="text-xs text-slate-300 flex items-center gap-1.5 bg-slate-950/70 px-3 py-1.5 rounded-lg border border-slate-800">
              <Activity className="w-3.5 h-3.5 text-amber-400" />
              <span>Cumulative Leaf Stress: <strong className="text-amber-300 font-mono">{totalAffectedArea}%</strong></span>
            </div>
          </div>
        )}
      </div>

      {/* Disease Cards Overview (React multi-diagnosis grid) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {diagnosesList.map((item, index) => (
          <div
            key={index}
            id={`disease-card-${index}`}
            className="disease-card bg-slate-900 border border-slate-800 hover:border-emerald-600/50 rounded-2xl p-4 sm:p-5 shadow-md space-y-2 transition cursor-pointer"
            onClick={() => setSelectedDiagnosisIndex(index === selectedDiagnosisIndex ? "all" : index)}
          >
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <Bug className="w-3.5 h-3.5 text-amber-400" />
                Pathology {index + 1}
              </span>
              <span className={`text-xs px-2.5 py-0.5 rounded-full font-bold border ${getSeverityBadgeColor(item.severity_level)}`}>
                {item.severity_level}
              </span>
            </div>
            <h3 className="text-lg font-bold text-white tracking-tight">
              {item.disease_name} ({item.severity_level})
            </h3>
            <p className="text-xs sm:text-sm text-emerald-300 font-mono">
              Causal Agent: {item.causal_agent || item.casual_agent}
            </p>
            <div className="pt-2 flex items-center justify-between text-xs border-t border-slate-800 text-slate-400">
              <span>Estimated Foliage Damage:</span>
              <span className="font-bold text-amber-300 font-mono">{item.estimated_affected_area_percentage}%</span>
            </div>
          </div>
        ))}
      </div>

      {/* Main Diagnostic Body: Grid with Leaf Photo, Metrics, and Remedies */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Visual Leaf Inspection & Pathology Stats (4 cols) */}
        <div className="lg:col-span-4 space-y-5">
          {/* Leaf Visual Card */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-md">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2.5 flex items-center justify-between">
              <span>Analyzed Leaf Specimen</span>
              <span className="text-emerald-400 font-mono">100% Verified</span>
            </h3>
            <div className="relative rounded-xl overflow-hidden bg-slate-950 aspect-square flex items-center justify-center border border-slate-800">
              {uploadedImageUrl ? (
                <img
                  src={uploadedImageUrl}
                  alt="Scanned Crop Leaf"
                  className="w-full h-full object-contain"
                />
              ) : (
                <div className="text-center p-4 text-slate-500">
                  <Leaf className="w-12 h-12 mx-auto mb-2 opacity-50" />
                  <p className="text-xs">Botanical Specimen</p>
                </div>
              )}
              {/* Estimated lesion overlay tag */}
              <div className="absolute bottom-2 left-2 bg-black/80 backdrop-blur-md px-2.5 py-1 rounded-lg border border-slate-700 text-[11px] font-medium text-slate-200">
                Foliage Stress: <span className="font-bold text-rose-400">{totalAffectedArea}%</span>
              </div>
            </div>

            {/* Severity Progress Bar */}
            <div className="mt-4 space-y-1.5">
              <div className="flex items-center justify-between text-xs font-medium">
                <span className="text-slate-400">Total Affected Area</span>
                <span className="text-rose-400 font-bold">{totalAffectedArea}%</span>
              </div>
              <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden">
                <div
                  className={`h-full transition-all duration-700 rounded-full ${
                    totalAffectedArea > 50
                      ? "bg-rose-500"
                      : totalAffectedArea > 25
                      ? "bg-amber-500"
                      : "bg-emerald-500"
                  }`}
                  style={{ width: `${Math.min(totalAffectedArea, 100)}%` }}
                />
              </div>
              {isMultiDiagnosis && (
                <div className="pt-2 space-y-1 border-t border-slate-800/80">
                  {diagnosesList.map((d, idx) => (
                    <div key={idx} className="flex justify-between items-center text-xs">
                      <span className="text-slate-300 flex items-center gap-1.5 truncate max-w-[190px]">
                        <span className="w-1.5 h-1.5 rounded-full bg-amber-400 shrink-0" />
                        {d.disease_name}
                      </span>
                      <span className="font-mono font-bold text-amber-300">{d.estimated_affected_area_percentage}%</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Dedicated Web Speech API Marathi Audio Console */}
          <MarathiSpeechPlayer
            marathiScript={
              report.marathi_audio_script ||
              (report.hotspot_geospatial_flag?.alert_message_marathi
                ? `${report.hotspot_geospatial_flag.alert_message_marathi} ${report.localized_text?.summary_audio_script || ""}`
                : report.localized_text?.summary_audio_script || "")
            }
            title="मराठी ऑडिओ सल्लागार"
            subTitle="Web Speech API ध्वनी संकलन व फवारणी सल्ला"
          />

          {/* Quick Symptoms Card (Iterates over diagnoses) */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-md space-y-3">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              Key Observable Symptoms
            </h3>
            
            <div className="space-y-3">
              {diagnosesList
                .filter((_, idx) => selectedDiagnosisIndex === "all" || selectedDiagnosisIndex === idx)
                .map((d, dIdx) => (
                  <div key={dIdx} className="space-y-1.5">
                    {isMultiDiagnosis && (
                      <div className="flex items-center justify-between text-xs font-bold text-amber-300 border-b border-slate-800/80 pb-1 pt-1">
                        <span className="flex items-center gap-1.5">
                          <Bug className="w-3.5 h-3.5 text-amber-400" />
                          {d.disease_name}
                        </span>
                        <span className={`text-[10px] px-1.5 py-0.5 rounded border ${getSeverityBadgeColor(d.severity_level)}`}>
                          {d.severity_level}
                        </span>
                      </div>
                    )}
                    <ul className="space-y-1.5">
                      {d.key_symptoms?.map((symptom, sIdx) => (
                        <li
                          key={sIdx}
                          className="text-xs text-slate-300 flex items-start gap-2 bg-slate-950/60 p-2.5 rounded-lg border border-slate-800/80"
                        >
                          <ChevronRight className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                          <span>{symptom}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
            </div>
          </div>

          {/* Direct Nearby Emergency Help Tile */}
          <div className="bg-gradient-to-br from-rose-950/60 via-slate-900 to-slate-900 border border-rose-800/60 rounded-2xl p-4 shadow-md space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-rose-300 flex items-center gap-1.5">
                <PhoneCall className="w-3.5 h-3.5 text-rose-400" />
                Emergency Farm Advisory
              </span>
              <span className="text-[10px] bg-rose-900/60 text-rose-200 px-1.5 py-0.5 rounded">Toll-Free</span>
            </div>
            <p className="text-xs text-slate-300">
              Need immediate district agronomist assistance or outbreak reporting?
            </p>
            <div className="flex flex-col gap-2">
              <a
                href="tel:18001801551"
                className="w-full py-2 px-3 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-xs font-bold text-center flex items-center justify-center gap-2 shadow transition"
              >
                <PhoneCall className="w-3.5 h-3.5" />
                Call Kisan Helpline (1800-180-1551)
              </a>
              <button
                onClick={onOpenEmergency}
                className="w-full py-2 px-3 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-medium border border-slate-700 flex items-center justify-center gap-1.5 transition"
              >
                <MapPin className="w-3.5 h-3.5 text-emerald-400" />
                Find Nearest Krishi Vigyan Kendra (KVK)
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: Optimal Solutions & Weather Advisory (8 cols) */}
        <div className="lg:col-span-8 space-y-5">
          {/* Section Navigation Tabs */}
          <div className="flex border-b border-slate-800 bg-slate-900/80 rounded-t-2xl p-1 gap-1 flex-wrap">
            <button
              onClick={() => setActiveTab("treatment")}
              className={`flex-1 min-w-[120px] py-2.5 text-xs sm:text-sm font-bold rounded-xl transition flex items-center justify-center gap-2 ${
                activeTab === "treatment"
                  ? "bg-emerald-600 text-white shadow-md"
                  : "text-slate-400 hover:text-white hover:bg-slate-800"
              }`}
            >
              <FlaskConical className="w-4 h-4" />
              Optimal Treatment Plan
            </button>
            <button
              onClick={() => setActiveTab("weather")}
              className={`flex-1 min-w-[120px] py-2.5 text-xs sm:text-sm font-bold rounded-xl transition flex items-center justify-center gap-2 ${
                activeTab === "weather"
                  ? "bg-emerald-600 text-white shadow-md"
                  : "text-slate-400 hover:text-white hover:bg-slate-800"
              }`}
            >
              <CloudSun className="w-4 h-4" />
              Weather Risk & Climate
            </button>
            <button
              onClick={() => setActiveTab("symptoms")}
              className={`flex-1 min-w-[120px] py-2.5 text-xs sm:text-sm font-bold rounded-xl transition flex items-center justify-center gap-2 ${
                activeTab === "symptoms"
                  ? "bg-emerald-600 text-white shadow-md"
                  : "text-slate-400 hover:text-white hover:bg-slate-800"
              }`}
            >
              <Sprout className="w-4 h-4" />
              Pathology Breakdown
            </button>
            <button
              onClick={() => {
                document.getElementById("growth-cycle-calendar-section")?.scrollIntoView({ behavior: "smooth" });
              }}
              className="flex-1 min-w-[120px] py-2.5 text-xs sm:text-sm font-bold rounded-xl transition flex items-center justify-center gap-1.5 text-emerald-300 hover:text-white hover:bg-emerald-950/60 border border-emerald-800/40"
              title="Jump to Growth Cycle Calendar section"
            >
              <Calendar className="w-4 h-4 text-emerald-400" />
              <span>Growth Calendar</span>
            </button>
          </div>

          {/* Tab 1: Optimal Treatment Plan (Supports multi-pathogen and single diagnosis) */}
          {activeTab === "treatment" && (
            <div className="space-y-4">
              {/* Integrated Pest & Disease Management (IPM) Banner if Co-Infection */}
              {isMultiDiagnosis && (
                <div className="p-4 bg-gradient-to-r from-amber-950/70 via-slate-900 to-emerald-950/70 border border-amber-600/50 rounded-2xl flex items-start gap-3">
                  <ShieldAlert className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                  <div className="space-y-1">
                    <h5 className="text-xs sm:text-sm font-bold text-amber-300">
                      Integrated Pest & Disease Management (IPM) Tank-Mix Advisory
                    </h5>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      Dual co-infection detected: Fungal leaf lesions (Early Blight) and pest infestation (Spider Mites). Apply Neem oil (5ml/L) as a protective broad-spectrum bio-repellent. When preparing tank-mixes with chemical fungicides and miticides, conduct a jar compatibility test first and maintain recommended pre-harvest intervals (PHI).
                    </p>
                  </div>
                </div>
              )}

              {/* Render remediation per diagnosis or unified */}
              {diagnosesList
                .filter((_, idx) => selectedDiagnosisIndex === "all" || selectedDiagnosisIndex === idx)
                .map((d, idx) => {
                  const organicList = d.remediation?.organic_treatment || (idx === 0 ? remediation.organic_treatment : []);
                  const chemicalList = d.remediation?.chemical_treatment || (idx === 0 ? remediation.chemical_treatment : []);

                  return (
                    <div key={idx} className="space-y-3">
                      {isMultiDiagnosis && (
                        <div className="flex items-center justify-between bg-slate-950/80 px-4 py-2.5 rounded-xl border border-slate-800">
                          <div className="flex items-center gap-2">
                            <Bug className="w-4 h-4 text-emerald-400" />
                            <span className="text-sm font-bold text-white">{d.disease_name}</span>
                            <span className="text-xs text-slate-400 italic font-mono">({d.causal_agent || d.casual_agent})</span>
                          </div>
                          <span className={`text-xs px-2 py-0.5 rounded border ${getSeverityBadgeColor(d.severity_level)}`}>
                            {d.severity_level} Severity
                          </span>
                        </div>
                      )}

                      {/* Organic / Biological Treatment */}
                      {organicList && organicList.length > 0 && (
                        <div className="bg-slate-900 border border-emerald-800/40 rounded-2xl p-5 shadow-md space-y-3">
                          <div className="flex items-center justify-between">
                            <h4 className="text-sm font-bold text-emerald-300 flex items-center gap-2">
                              <Sprout className="w-4 h-4 text-emerald-400" />
                              Organic & Biological Interventions {isMultiDiagnosis ? `for ${d.disease_name}` : "(Eco-Safe)"}
                            </h4>
                            <span className="text-[11px] font-semibold text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800">
                              Natural Bio-Control
                            </span>
                          </div>
                          <div className="space-y-2">
                            {organicList.map((treatment, tIdx) => (
                              <div
                                key={tIdx}
                                className="p-3 bg-emerald-950/30 border border-emerald-900/50 rounded-xl flex items-start gap-2.5 text-xs sm:text-sm text-slate-200"
                              >
                                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                                <span>{treatment}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Chemical Treatment with Exact Active Dosages */}
                      {chemicalList && chemicalList.length > 0 && (
                        <div className="bg-slate-900 border border-amber-800/40 rounded-2xl p-5 shadow-md space-y-3">
                          <div className="flex items-center justify-between">
                            <h4 className="text-sm font-bold text-amber-300 flex items-center gap-2">
                              <FlaskConical className="w-4 h-4 text-amber-400" />
                              Chemical Prescription {isMultiDiagnosis ? `for ${d.disease_name}` : ""}
                            </h4>
                            <span className="text-[11px] font-semibold text-amber-400 bg-amber-950 px-2 py-0.5 rounded border border-amber-800">
                              CIBRC Standards
                            </span>
                          </div>
                          <div className="space-y-2">
                            {chemicalList.map((treatment, tIdx) => (
                              <div
                                key={tIdx}
                                className="p-3 bg-amber-950/30 border border-amber-900/50 rounded-xl flex items-start gap-2.5 text-xs sm:text-sm text-slate-200"
                              >
                                <div className="w-2 h-2 rounded-full bg-amber-400 shrink-0 mt-1.5" />
                                <span className="font-sans font-medium">{treatment}</span>
                              </div>
                            ))}
                          </div>
                          <div className="p-2.5 bg-slate-950 rounded-lg text-[11px] text-slate-400 italic">
                            Note: Wear protective gloves and eye gear when applying sprays. Avoid spraying during peak pollinator foraging hours (10:00 AM – 3:00 PM).
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}

              {/* Fertilizer & N-P-K Balancing */}
              {remediation.fertilizer_adjustment && (
                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-md space-y-2">
                  <h4 className="text-sm font-bold text-indigo-300 flex items-center gap-2">
                    <Leaf className="w-4 h-4 text-indigo-400" />
                    Fertilizer & Soil Nutrition Adjustment
                  </h4>
                  <div className="p-3.5 bg-indigo-950/30 border border-indigo-900/50 rounded-xl text-xs sm:text-sm text-slate-200">
                    {remediation.fertilizer_adjustment}
                  </div>
                </div>
              )}

              {/* Agri-Input Dealer Medicine Verification & Dispensation Slip Card */}
              <div className="p-4 bg-gradient-to-r from-amber-950/70 via-slate-900 to-amber-950/50 border border-amber-600/60 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-md">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <Building2 className="w-4 h-4 text-amber-400" />
                    <span className="text-xs font-bold text-amber-300 uppercase tracking-wider">
                      Krishi Seva Kendra / Agri-Dealer Prescription
                    </span>
                    <span className="text-[10px] bg-amber-900/80 text-amber-200 px-2 py-0.5 rounded border border-amber-700 font-semibold">
                      CIBRC Standard
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 max-w-xl leading-relaxed">
                    Need to purchase these prescribed fungicides or bio-inputs from your local fertilizer retailer? Open the official dealer prescription slip with exact active ingredient dosages and dealer verification boxes.
                  </p>
                </div>
                <button
                  id="treatment-tab-print-dealer-btn"
                  onClick={() => setShowDealerSlipModal(true)}
                  className="px-4 py-2.5 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-xs font-bold flex items-center gap-2 transition shadow shrink-0"
                >
                  <Printer className="w-4 h-4" />
                  <span>Print Dealer Slip</span>
                </button>
              </div>

              {/* Long-Term Yield Protection Bridge Banner */}
              <div className="p-4 bg-gradient-to-r from-emerald-950/70 via-slate-900 to-indigo-950/70 border border-emerald-700/50 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-md">
                <div className="space-y-0.5">
                  <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5" />
                    Long-Term Yield Protection Calendar
                  </span>
                  <p className="text-xs text-slate-300">
                    Proactively timing sprays across {crop_details.common_name}'s growth phases prevents up to 85% of future fungal and pest reinfections.
                  </p>
                </div>
                <button
                  onClick={() => {
                    document.getElementById("growth-cycle-calendar-section")?.scrollIntoView({ behavior: "smooth" });
                  }}
                  className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold shrink-0 flex items-center gap-1.5 shadow transition"
                >
                  <Calendar className="w-3.5 h-3.5" />
                  <span>Inspect Growth Calendar</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}

          {/* Tab 2: Weather Risk & Micro-Climate Advisory */}
          {activeTab === "weather" && (
            <div className="space-y-4">
              <div className="bg-slate-900 border border-sky-800/40 rounded-2xl p-5 shadow-md space-y-4">
                <h4 className="text-sm font-bold text-sky-300 flex items-center gap-2">
                  <CloudSun className="w-5 h-5 text-sky-400" />
                  Micro-Climate Weather Risk Parameters
                </h4>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 bg-sky-950/30 border border-sky-900/50 rounded-xl space-y-1.5">
                    <span className="text-xs font-bold text-sky-400 uppercase tracking-wider">
                      High Risk Environmental Conditions
                    </span>
                    <p className="text-xs sm:text-sm text-slate-200">
                      {weather_risk_advisory?.high_risk_conditions || "High humidity (>80%) and warm ambient temperatures promote rapid pathogen spore germination."}
                    </p>
                  </div>

                  <div className="p-4 bg-emerald-950/30 border border-emerald-900/50 rounded-xl space-y-1.5">
                    <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">
                      Field Preventative Action
                    </span>
                    <p className="text-xs sm:text-sm text-slate-200">
                      {weather_risk_advisory?.preventative_action || "Maintain clean drainage furrows, avoid overhead sprinkler wetting, and optimize row spacing for air circulation."}
                    </p>
                  </div>
                </div>

                <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 text-xs text-slate-300 space-y-2">
                  <p className="font-semibold text-sky-300">Indian Monsoon & Crop Protection Rule of Thumb:</p>
                  <ul className="list-disc list-inside space-y-1 text-slate-400">
                    <li>Never apply foliar spray if rain is predicted within 3-4 hours; use a silicon sticker/spreader agent (0.5ml/L).</li>
                    <li>Always check the IMD Meghdoot / Kisan Suvidha daily weather bulletin for localized district rain alerts.</li>
                  </ul>
                </div>
              </div>
            </div>
          )}

          {/* Tab 3: Pathology Breakdown & Symptoms Deep Dive */}
          {activeTab === "symptoms" && (
            <div className="space-y-4">
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-md space-y-4">
                <h4 className="text-sm font-bold text-slate-200 flex items-center gap-2">
                  <Bug className="w-4 h-4 text-emerald-400" />
                  Detailed Botanical & Pathology Breakdown
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                    <span className="text-slate-400 block mb-1">Common Crop Name</span>
                    <span className="font-bold text-white text-sm">{crop_details.common_name}</span>
                  </div>
                  <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                    <span className="text-slate-400 block mb-1">Scientific Classification</span>
                    <span className="font-bold text-emerald-300 text-sm italic">{crop_details.scientific_name}</span>
                  </div>
                </div>

                {/* Per-disease breakdown cards */}
                <div className="space-y-3">
                  {diagnosesList.map((d, idx) => (
                    <div key={idx} className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="w-5 h-5 rounded-full bg-emerald-950 text-emerald-400 font-bold text-xs flex items-center justify-center border border-emerald-800">
                            {idx + 1}
                          </span>
                          <span className="font-bold text-white text-sm">{d.disease_name}</span>
                        </div>
                        <span className={`text-xs px-2 py-0.5 rounded border ${getSeverityBadgeColor(d.severity_level)}`}>
                          {d.severity_level} ({d.estimated_affected_area_percentage}% foliage)
                        </span>
                      </div>
                      <p className="text-xs text-amber-300 font-mono">
                        Causal Organism / Vector: {d.causal_agent || d.casual_agent}
                      </p>
                      <div className="pt-2">
                        <span className="text-slate-400 text-xs block mb-1">Observed Symptoms:</span>
                        <ul className="list-disc list-inside text-xs text-slate-300 space-y-0.5">
                          {d.key_symptoms?.map((s, sIdx) => (
                            <li key={sIdx}>{s}</li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="p-4 bg-emerald-950/20 border border-emerald-900/40 rounded-xl text-xs text-slate-300 space-y-2">
                  <p className="font-bold text-emerald-400">Nutritional Deficiencies vs Biological Diseases:</p>
                  <p className="text-slate-400 leading-relaxed">
                    {crop_details.leaf_condition === "Nutrient Deficiency"
                      ? "This condition is primarily physiological, caused by insufficient macro or micro-elements in the soil rather than infectious pathogens."
                      : "Symptoms indicate an active biological attack (fungal spore germination, bacterial lesions, or sap-sucking pest infestation) requiring immediate field quarantine and targeted treatment."}
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Interactive Growth Cycle Calendar Section */}
      <div id="growth-cycle-calendar-section" className="pt-2">
        <GrowthCycleCalendar
          cropCommonName={crop_details.common_name}
          diagnosedDiseases={diagnosesList.map((d) => d.disease_name)}
          onOpenEmergency={onOpenEmergency}
        />
      </div>

      {/* Raw JSON Inspector Modal / Card (Crucial for SIH evaluation) */}
      {showJsonRaw && (
        <div className="bg-slate-950 border border-emerald-700/60 rounded-2xl p-5 shadow-2xl space-y-3 animate-fade-in">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-slate-800">
            <div className="flex items-center gap-2 text-xs font-mono text-emerald-400">
              <FileCode2 className="w-4 h-4" />
              <span>Diagnostic JSON Output Inspector</span>
            </div>
            
            {/* Schema Selector Tabs */}
            <div className="flex items-center gap-1.5 bg-slate-900 p-1 rounded-xl border border-slate-800 text-xs">
              <button
                onClick={() => setJsonSchemaType("maharashtra")}
                className={`px-3 py-1 rounded-lg font-bold transition flex items-center gap-1.5 ${
                  jsonSchemaType === "maharashtra"
                    ? "bg-amber-600 text-white shadow"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                <span>AgroVision Maharashtra (SIH26131)</span>
              </button>
              <button
                onClick={() => setJsonSchemaType("sih")}
                className={`px-3 py-1 rounded-lg font-bold transition flex items-center gap-1.5 ${
                  jsonSchemaType === "sih"
                    ? "bg-emerald-600 text-white shadow"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                <span>Standard SIH Format</span>
              </button>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={copyJsonToClipboard}
                className="px-3 py-1 bg-emerald-700 hover:bg-emerald-600 text-white rounded-lg text-xs font-mono transition flex items-center gap-1 shadow"
              >
                {copiedJson ? "Copied!" : `Copy ${jsonSchemaType === "maharashtra" ? "Maharashtra JSON" : "SIH JSON"}`}
              </button>
              <button
                onClick={() => setShowJsonRaw(false)}
                className="text-slate-400 hover:text-white text-xs px-2 py-1 rounded hover:bg-slate-800 transition"
              >
                Close
              </button>
            </div>
          </div>

          <div className="text-[11px] text-slate-400 flex items-center justify-between font-mono">
            <span>
              {jsonSchemaType === "maharashtra" 
                ? "Schema: Dept. of Agriculture, Govt. of Maharashtra (SIH26131) with micro-climate risk, IPM, & Marathi TTS"
                : "Schema: Standard Smart India Hackathon Agricultural Pathology Specimen Format"}
            </span>
            <span className="text-emerald-400">application/json</span>
          </div>

          <pre className="p-4 bg-slate-900 rounded-xl text-xs font-mono text-emerald-300 overflow-x-auto max-h-96 border border-slate-800">
            {JSON.stringify(
              jsonSchemaType === "maharashtra"
                ? (report.maharashtra_json || toMaharashtraSIHJson(report))
                : (report.sih_json || toSIHJson(report)),
              null,
              2
            )}
          </pre>
        </div>
      )}

      {/* Agri-Input Dealer Medicine Verification & Prescription Modal (Printer-Friendly) */}
      <AgriDealerPrescriptionModal
        report={report}
        isOpen={showDealerSlipModal}
        onClose={() => setShowDealerSlipModal(false)}
      />
    </div>
  );
};
