import React, { useState, useRef } from "react";
import { SAMPLE_CROPS, SampleCrop } from "../data/sampleCrops";
import { SupportedLanguage } from "../types";
import { ensureJpegDataUrl } from "../utils/imageUtils";
import { 
  Upload, 
  Camera, 
  Sprout, 
  MapPin, 
  Sparkles, 
  AlertCircle, 
  CheckCircle2, 
  Info,
  Loader2,
  ChevronRight,
  ShieldCheck,
  Zap,
  HelpCircle
} from "lucide-react";

interface UploadScanSectionProps {
  onAnalyze: (payload: {
    imageBase64: string;
    mimeType: string;
    language: SupportedLanguage;
    region: string;
    cropHint: string;
  }) => void;
  isLoading: boolean;
  onOpenCamera: () => void;
  currentLanguage: SupportedLanguage;
  isOfflineMode: boolean;
}

const INDIAN_STATES = [
  "General India (National Standard)",
  "Punjab & Haryana (North Indo-Gangetic)",
  "Maharashtra (Western Ghats & Deccan)",
  "Uttar Pradesh & Bihar (Central Plains)",
  "Tamil Nadu & Kerala (Southern Humid)",
  "Andhra Pradesh & Telangana (Krishna-Godavari)",
  "Gujarat (Saurashtra & Coastal)",
  "Madhya Pradesh & Chhattisgarh (Malwa)",
  "Rajasthan (Arid & Semi-Arid)",
  "West Bengal & Assam (Eastern Humid)",
  "Karnataka (Southern Plateau)",
];

export const UploadScanSection: React.FC<UploadScanSectionProps> = ({
  onAnalyze,
  isLoading,
  onOpenCamera,
  currentLanguage,
  isOfflineMode,
}) => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [selectedMime, setSelectedMime] = useState<string>("image/jpeg");
  const [region, setRegion] = useState<string>(INDIAN_STATES[0]);
  const [cropHint, setCropHint] = useState<string>("");
  const [dragOver, setDragOver] = useState<boolean>(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const processFile = (file: File) => {
    if (!file.type.startsWith("image/")) {
      alert("Please upload a valid image file (JPEG, PNG, WEBP).");
      return;
    }
    setSelectedMime("image/jpeg");
    const reader = new FileReader();
    reader.onload = async (e) => {
      if (e.target?.result) {
        const raw = e.target.result as string;
        const rasterized = await ensureJpegDataUrl(raw);
        setSelectedImage(rasterized);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const handleSelectSample = async (sample: SampleCrop) => {
    setCropHint(sample.crop);
    setSelectedMime("image/jpeg");
    // Rasterize SVG or preset sample image immediately into a clean JPEG base64 data URL
    const rasterized = await ensureJpegDataUrl(sample.imageUrl);
    setSelectedImage(rasterized);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedImage) return;

    // Ensure clean raster JPEG base64
    const readyImage = await ensureJpegDataUrl(selectedImage);
    onAnalyze({
      imageBase64: readyImage,
      mimeType: "image/jpeg",
      language: currentLanguage,
      region,
      cropHint,
    });
  };

  return (
    <div className="max-w-4xl mx-auto my-6 space-y-6">
      {/* Informative Welcome Banner tailored for Indian Farming Conditions & SIH */}
      <div className="bg-gradient-to-br from-emerald-950/90 via-slate-900 to-emerald-950/70 border border-emerald-800/60 rounded-3xl p-6 sm:p-8 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 space-y-4">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="px-3 py-1 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded-full text-xs font-bold flex items-center gap-1.5 shadow-sm">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              Smart India Hackathon (SIH) Standard
            </span>
            <span className="px-3 py-1 bg-slate-800/80 text-slate-300 border border-slate-700/60 rounded-full text-xs font-medium">
              Indian Agri Conditions & ICAR Protocols
            </span>
            {isOfflineMode && (
              <span className="px-3 py-1 bg-amber-500/20 text-amber-300 border border-amber-500/40 rounded-full text-xs font-semibold">
                Offline Classification Active
              </span>
            )}
          </div>

          <div className="space-y-2">
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black text-white tracking-tight font-['Outfit',sans-serif]">
              Instant Plant Pathology & <span className="text-emerald-400">Crop Health Diagnostic</span>
            </h2>
            <p className="text-slate-300 text-sm sm:text-base max-w-2xl leading-relaxed">
              Upload or scan a plant leaf to identify fungal pathogens, viral curls, bacterial blights, and nutrient deficiencies. Receive actionable, non-generic remedies and voice advisories in your local language.
            </p>
          </div>

          {/* Core Workflow Checklist */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
            <div className="p-3 bg-slate-950/60 border border-emerald-900/40 rounded-xl flex items-start gap-2 text-xs text-slate-300">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span>
                <strong className="text-emerald-200 block">1. Visual Assessment</strong>
                Lesion margin & chlorosis pattern analysis
              </span>
            </div>
            <div className="p-3 bg-slate-950/60 border border-emerald-900/40 rounded-xl flex items-start gap-2 text-xs text-slate-300">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span>
                <strong className="text-emerald-200 block">2. Optimal Remedies</strong>
                Exact CIBRC chemical & bio-organic dosages
              </span>
            </div>
            <div className="p-3 bg-slate-950/60 border border-emerald-900/40 rounded-xl flex items-start gap-2 text-xs text-slate-300">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span>
                <strong className="text-emerald-200 block">3. Localized Voice & Help</strong>
                Regional speech script & 24/7 Kisan dialer
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Upload / Scan Form */}
      <form onSubmit={handleSubmit} className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
        {/* Upload Zone */}
        <div className="space-y-3">
          <label className="text-sm font-bold text-slate-200 flex items-center justify-between">
            <span className="flex items-center gap-2">
              <Upload className="w-4 h-4 text-emerald-400" />
              Upload or Capture Crop Specimen
            </span>
            <span className="text-xs text-slate-400 font-normal">
              Daylight photo of infected leaf surface
            </span>
          </label>

          <div
            onDragOver={(e) => {
              e.preventDefault();
              setDragOver(true);
            }}
            onDragLeave={() => setDragOver(false)}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`border-2 border-dashed rounded-2xl p-6 sm:p-8 text-center cursor-pointer transition-all duration-200 flex flex-col items-center justify-center min-h-[220px] ${
              dragOver
                ? "border-emerald-400 bg-emerald-950/40"
                : selectedImage
                ? "border-emerald-600/70 bg-emerald-950/20"
                : "border-slate-700 hover:border-emerald-500/60 bg-slate-950/60 hover:bg-slate-950"
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleFileChange}
            />

            {selectedImage ? (
              <div className="space-y-3">
                <div className="relative inline-block">
                  <img
                    src={selectedImage}
                    alt="Selected leaf"
                    className="max-h-48 max-w-xs object-contain rounded-xl border border-emerald-500/40 shadow-md bg-black"
                  />
                  <div className="absolute top-2 right-2 bg-emerald-600 text-white p-1 rounded-full shadow">
                    <CheckCircle2 className="w-4 h-4" />
                  </div>
                </div>
                <p className="text-xs text-emerald-300 font-medium">
                  Leaf image loaded. Click to replace or select from presets below.
                </p>
              </div>
            ) : (
              <div className="space-y-3 max-w-sm mx-auto">
                <div className="w-14 h-14 rounded-2xl bg-emerald-950/80 border border-emerald-700/50 flex items-center justify-center mx-auto text-emerald-400 shadow-inner">
                  <Upload className="w-7 h-7" />
                </div>
                <div>
                  <p className="text-sm font-bold text-slate-200">
                    Drag and drop leaf photo, or <span className="text-emerald-400 underline">browse device</span>
                  </p>
                  <p className="text-xs text-slate-400 mt-1">
                    Supports JPG, PNG, WEBP high-resolution field photos
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Quick Action: Live Camera Snapshot */}
          <div className="flex items-center justify-center pt-1">
            <button
              id="open-field-camera-btn"
              type="button"
              onClick={onOpenCamera}
              className="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-emerald-300 rounded-xl text-xs font-bold border border-emerald-700/50 shadow-sm flex items-center gap-2 transition hover:scale-[1.02]"
            >
              <Camera className="w-4 h-4 text-emerald-400" />
              <span>Use Live Field Camera Scanner</span>
            </button>
          </div>
        </div>

        {/* Quick Test Samples */}
        <div className="space-y-3 pt-2 border-t border-slate-800">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              Quick Test Presets (Instant Click-to-Test)
            </span>
            <span className="text-[11px] text-slate-500">Zero network required</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
            {SAMPLE_CROPS.map((sample) => (
              <button
                key={sample.id}
                type="button"
                onClick={() => handleSelectSample(sample)}
                className={`p-2 rounded-xl text-left border transition flex flex-col justify-between group ${
                  selectedImage === sample.imageUrl
                    ? "border-emerald-400 bg-emerald-950/60 ring-2 ring-emerald-500/20"
                    : sample.isInvalidTest
                    ? "border-rose-900/60 bg-rose-950/20 hover:border-rose-700/70"
                    : "border-slate-800 bg-slate-950/80 hover:border-emerald-700/50"
                }`}
              >
                <div className="aspect-square w-full rounded-lg overflow-hidden bg-black mb-1.5 border border-slate-800">
                  <img
                    src={sample.imageUrl}
                    alt={sample.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition"
                  />
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-200 group-hover:text-emerald-300 truncate">
                    {sample.title}
                  </p>
                  <p className="text-[10px] text-slate-400 truncate mt-0.5">
                    {sample.condition}
                  </p>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Agricultural Context (Region & Crop Hint) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-slate-800">
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-emerald-400" />
              Farming Agro-Climatic Zone / State
            </label>
            <select
              value={region}
              onChange={(e) => setRegion(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-400 transition"
            >
              {INDIAN_STATES.map((st) => (
                <option key={st} value={st} className="bg-slate-900">
                  {st}
                </option>
              ))}
            </select>
            <p className="text-[11px] text-slate-500">
              Calibrates chemical spray recommendations and humidity thresholds to your state.
            </p>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
              <Sprout className="w-3.5 h-3.5 text-emerald-400" />
              Crop Hint or Farmer Observations (Optional)
            </label>
            <input
              type="text"
              placeholder="e.g. Tomato, Rice, Cotton, or 'brown circles after monsoon rain'"
              value={cropHint}
              onChange={(e) => setCropHint(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-emerald-400 transition"
            />
            <p className="text-[11px] text-slate-500">
              Helps verify symptom onset timing and vegetative growth stage.
            </p>
          </div>
        </div>

        {/* Submit Button & Scanning State */}
        <div className="pt-4 border-t border-slate-800">
          <button
            id="run-crop-analysis-btn"
            type="submit"
            disabled={!selectedImage || isLoading}
            className={`w-full py-3.5 px-6 rounded-2xl font-bold text-sm text-white shadow-xl flex items-center justify-center gap-2.5 transition ${
              !selectedImage || isLoading
                ? "bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700"
                : "bg-emerald-600 hover:bg-emerald-500 shadow-emerald-950/80 hover:scale-[1.01]"
            }`}
          >
            {isLoading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin text-emerald-300" />
                <span>Analyzing Plant Pathology via AgroVision AI Engine...</span>
              </>
            ) : (
              <>
                <Zap className="w-5 h-5 text-amber-300" />
                <span>
                  Diagnose Crop & Generate Advisory ({currentLanguage})
                </span>
                <ChevronRight className="w-4 h-4 ml-1" />
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};
