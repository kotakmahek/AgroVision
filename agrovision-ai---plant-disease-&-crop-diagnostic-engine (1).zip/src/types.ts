export type LeafCondition = "Healthy" | "Diseased" | "Pest Attack" | "Nutrient Deficiency" | "Invalid Image";
export type SeverityLevel = "Low" | "Moderate" | "High" | "Critical";
export type OverallCropStatus = "HEALTHY" | "DISEASED" | "PEST_INFESTED" | "NUTRIENT_DEFICIENT";

export interface CropDetails {
  common_name: string;
  scientific_name: string;
  overall_status?: OverallCropStatus;
  leaf_condition: LeafCondition;
  crop_name_english?: string;
  crop_name_marathi?: string;
  variety?: string;
  growth_stage?: string;
}

export interface DiagnosisDetails {
  disease_name: string;
  casual_agent: string;
  causal_agent?: string;
  severity_level: SeverityLevel;
  estimated_affected_area_percentage: number;
  key_symptoms: string[];
}

export interface DiagnosisRemediation {
  organic_treatment: string[];
  chemical_treatment: string[];
  fertilizer_adjustment?: string;
}

export interface SIHTreatmentPlan {
  organic_methods: string[];
  chemical_methods: string[];
}

export interface SIHDiagnosisItem {
  condition_name: string;
  causal_agent: string;
  severity: SeverityLevel;
  confidence_score: number;
  symptoms_observed: string[];
  treatment_plan: SIHTreatmentPlan;
}

export interface SIHWeatherRiskAdvisory {
  risk_level: "Low" | "Moderate" | "High" | "Critical";
  advice: string;
}

export interface SIHLocalizedAdvisory {
  language: string;
  summary_script: string;
}

/**
 * Exact AgroVision Maharashtra (SIH26131) Output JSON Schema
 * Custom-built for Department of Agriculture, Government of Maharashtra
 */
export interface IPMAdvisory {
  cultural_mechanical: string;
  biological: string;
  chemical_safe_dosage: string;
}

export interface AgroVisionMaharashtraCropDetails {
  crop_name_english: string;
  crop_name_marathi: string;
  variety: string;
  growth_stage: string;
  scientific_name?: string;
}

export interface AgroVisionMaharashtraDiagnosisItem {
  condition_name: string;
  condition_marathi: string;
  causal_agent: string;
  severity: SeverityLevel;
  confidence_score: number;
  symptoms_observed: string[];
  ipm_advisory: IPMAdvisory;
}

export interface PredictiveWeatherRisk {
  block_outbreak_risk_score: number; // 0–100
  risk_level: "CRITICAL_HOTSPOT" | "HIGH_RISK" | "MODERATE_RISK" | "LOW_RISK" | string;
  contributing_factors: string;
}

export interface HotspotGeospatialFlag {
  trigger_block_alert: boolean;
  recommended_radius_km: number;
  alert_message_marathi: string;
}

export interface AgroVisionMaharashtraResponse {
  is_valid_specimen: boolean;
  error_message_marathi?: string;
  crop_details: AgroVisionMaharashtraCropDetails;
  diagnoses: AgroVisionMaharashtraDiagnosisItem[];
  predictive_weather_risk: PredictiveWeatherRisk;
  hotspot_geospatial_flag: HotspotGeospatialFlag;
  marathi_audio_script: string;
}

/**
 * Standard Smart India Hackathon (SIH) Output JSON Schema
 */
export interface SIHDiagnosticResponse {
  is_valid_specimen: boolean;
  error_message: string | null;
  crop_details: {
    common_name: string;
    scientific_name: string;
    overall_status: OverallCropStatus;
  };
  diagnoses: SIHDiagnosisItem[];
  weather_risk_advisory: SIHWeatherRiskAdvisory;
  localized_advisory: SIHLocalizedAdvisory;
}

export interface DiagnosisItem {
  condition_name?: string;
  condition_marathi?: string;
  disease_name: string;
  causal_agent?: string;
  casual_agent?: string;
  severity?: SeverityLevel;
  severity_level: SeverityLevel;
  confidence_score?: number;
  estimated_affected_area_percentage: number;
  symptoms_observed?: string[];
  key_symptoms: string[];
  treatment_plan?: SIHTreatmentPlan;
  ipm_advisory?: IPMAdvisory;
  remediation?: DiagnosisRemediation;
}

export interface RemediationDetails {
  organic_treatment: string[];
  chemical_treatment: string[];
  fertilizer_adjustment: string;
}

export interface PreventativeAction {
  type: "Organic / Bio-Control" | "Chemical Prophylactic" | "Cultural Practice" | "Fertigation";
  action: string;
  dosage?: string;
  targetPathogen: string;
  yieldBenefit: string;
}

export interface GrowthStageItem {
  id: string;
  stageName: string;
  dayRange: string;
  minDays: number;
  maxDays: number;
  description: string;
  vulnerability: string;
  preventativeActions: PreventativeAction[];
  criticalWatchout: string;
}

export interface CropGrowthCalendar {
  cropName: string;
  totalDurationDays: number;
  seasonRecommendation: string;
  stages: GrowthStageItem[];
}

export interface WeatherRiskAdvisory {
  risk_level?: "Low" | "Moderate" | "High" | "Critical";
  advice?: string;
  high_risk_conditions: string;
  preventative_action: string;
}

export interface LocalizedText {
  language: string;
  summary_audio_script: string;
}

export interface DiagnosticReport {
  is_valid_specimen: boolean;
  is_valid_crop_image: boolean;
  error_message: string | null;
  confidence_score: number;
  crop_details: CropDetails;
  diagnosis: DiagnosisDetails;
  diagnoses?: DiagnosisItem[];
  remediation: RemediationDetails;
  weather_risk_advisory: WeatherRiskAdvisory;
  localized_advisory?: SIHLocalizedAdvisory;
  localized_text: LocalizedText;
  sih_json?: SIHDiagnosticResponse;
  maharashtra_json?: AgroVisionMaharashtraResponse;
  predictive_weather_risk?: PredictiveWeatherRisk;
  hotspot_geospatial_flag?: HotspotGeospatialFlag;
  marathi_audio_script?: string;
  // Optional metadata added by engine
  id?: string;
  timestamp?: string;
  imageUrl?: string;
  source?: "cloud_gemini" | "offline_cache" | "offline_edge_fallback";
  invalid_reason?: string;
}

/**
 * Formats any diagnostic report into the exact AgroVision Maharashtra (SIH26131) Output JSON Schema
 */
export function toMaharashtraSIHJson(report: DiagnosticReport): AgroVisionMaharashtraResponse {
  if (report.maharashtra_json) return report.maharashtra_json;

  const cropEnglish = report.crop_details.crop_name_english || report.crop_details.common_name || "Cotton";
  let cropMarathi = report.crop_details.crop_name_marathi;
  if (!cropMarathi) {
    const lower = cropEnglish.toLowerCase();
    if (lower.includes("cotton")) cropMarathi = "कापूस";
    else if (lower.includes("soy") || lower.includes("soya")) cropMarathi = "सोयाबीन";
    else if (lower.includes("sugar")) cropMarathi = "ऊस";
    else if (lower.includes("tomato")) cropMarathi = "टोमॅटो";
    else if (lower.includes("rice") || lower.includes("paddy")) cropMarathi = "भात";
    else if (lower.includes("onion")) cropMarathi = "कांदा";
    else if (lower.includes("potato")) cropMarathi = "बटाटा";
    else if (lower.includes("corn") || lower.includes("maize")) cropMarathi = "मका";
    else cropMarathi = cropEnglish;
  }

  const variety = report.crop_details.variety || "BT Cotton";
  const growthStage = report.crop_details.growth_stage || "Flowering / Boll Formation";

  const diagnoses: AgroVisionMaharashtraDiagnosisItem[] = (report.diagnoses || []).map((d) => {
    const condName = d.condition_name || d.disease_name || "Pink Bollworm Damage";
    let condMarathi = d.condition_marathi;
    if (!condMarathi) {
      const lower = condName.toLowerCase();
      if (lower.includes("pink") || lower.includes("bollworm")) condMarathi = "गुलाबी बोंड अळी";
      else if (lower.includes("blight")) condMarathi = "करपा रोग";
      else if (lower.includes("curl")) condMarathi = "चुरडा-मुरडा (लीफ कर्ल)";
      else if (lower.includes("rot")) condMarathi = "कुजव्या रोग";
      else if (lower.includes("mosaic")) condMarathi = "पिवळा मोझॅक";
      else if (lower.includes("rust")) condMarathi = "तांबेरा";
      else if (lower.includes("blast")) condMarathi = "ब्लास्ट / करपा";
      else condMarathi = condName;
    }

    const causal = d.causal_agent || d.casual_agent || "Pectinophora gossypiella (Pest)";
    const sev = (d.severity || d.severity_level || "Moderate") as SeverityLevel;
    const conf = typeof d.confidence_score === "number"
      ? (d.confidence_score <= 1 ? Math.round(d.confidence_score * 100) : d.confidence_score)
      : 93;

    const symptoms = d.symptoms_observed && d.symptoms_observed.length > 0
      ? d.symptoms_observed
      : d.key_symptoms && d.key_symptoms.length > 0
      ? d.key_symptoms
      : ["Rosette flowers", "Exit holes on bolls with frass accumulation"];

    const cultural = d.ipm_advisory?.cultural_mechanical ||
      (Array.isArray(d.treatment_plan?.organic_methods) && d.treatment_plan.organic_methods[0]) ||
      "Install 2 Pheromone traps per acre for monitoring. Destroy rosette flowers manually.";

    const biological = d.ipm_advisory?.biological ||
      (Array.isArray(d.treatment_plan?.organic_methods) && d.treatment_plan.organic_methods[1]) ||
      "Release Trichogramma bactrae @ 60,000 parasites/acre at 7-day intervals.";

    const chemical = d.ipm_advisory?.chemical_safe_dosage ||
      (Array.isArray(d.treatment_plan?.chemical_methods) && d.treatment_plan.chemical_methods[0]) ||
      "If ETL (>8 moths/trap/night) is crossed, spray Profenofos 50% EC @ 2ml per Liter of water.";

    return {
      condition_name: condName,
      condition_marathi: condMarathi,
      causal_agent: causal,
      severity: sev,
      confidence_score: conf,
      symptoms_observed: symptoms,
      ipm_advisory: {
        cultural_mechanical: cultural,
        biological: biological,
        chemical_safe_dosage: chemical,
      },
    };
  });

  const weatherRisk = report.predictive_weather_risk || {
    block_outbreak_risk_score: report.diagnosis.severity_level === "Critical" ? 88 : report.diagnosis.severity_level === "High" ? 85 : 62,
    risk_level: report.diagnosis.severity_level === "Critical" || report.diagnosis.severity_level === "High" ? "CRITICAL_HOTSPOT" : "MODERATE_RISK",
    contributing_factors: report.weather_risk_advisory.advice || "Relative humidity >80% with cloudy conditions favors rapid pest multiplication in the next 72 hours.",
  };

  const hotspotFlag = report.hotspot_geospatial_flag || {
    trigger_block_alert: weatherRisk.block_outbreak_risk_score >= 70,
    recommended_radius_km: 5,
    alert_message_marathi: `सावधान! तुमच्या तालुक्यात ${diagnoses[0]?.condition_marathi || "रोगाचा"} प्रादुर्भाव वाढला आहे. कामगंध सापळे त्वरित बसवा.`,
  };

  const marathiAudio = report.marathi_audio_script ||
    `तुमच्या ${cropMarathi} पिकावर ${diagnoses[0]?.condition_marathi || "रोगाचा"} प्रादुर्भाव दिसून येत आहे. हे नियंत्रणात आणण्यासाठी एकरी २ कामगंध सापळे लावा आणि जैविक उपचारासाठी ट्रायकोग्राम्माचा वापर करा.`;

  return {
    is_valid_specimen: report.is_valid_specimen,
    crop_details: {
      crop_name_english: cropEnglish,
      crop_name_marathi: cropMarathi,
      variety,
      growth_stage: growthStage,
    },
    diagnoses,
    predictive_weather_risk: weatherRisk,
    hotspot_geospatial_flag: hotspotFlag,
    marathi_audio_script: marathiAudio,
  };
}

/**
 * Formats any diagnostic report into the exact SIH JSON output schema
 */
export function toSIHJson(report: DiagnosticReport): SIHDiagnosticResponse {
  if (report.sih_json) return report.sih_json;

  let overallStatus: OverallCropStatus = report.crop_details.overall_status || "DISEASED";
  if (!report.is_valid_specimen) {
    overallStatus = "DISEASED";
  } else if (report.crop_details.leaf_condition === "Healthy") {
    overallStatus = "HEALTHY";
  } else if (report.crop_details.leaf_condition === "Pest Attack") {
    overallStatus = "PEST_INFESTED";
  } else if (report.crop_details.leaf_condition === "Nutrient Deficiency") {
    overallStatus = "NUTRIENT_DEFICIENT";
  }

  const diagnoses: SIHDiagnosisItem[] = (report.diagnoses || []).map((d) => ({
    condition_name: d.condition_name || d.disease_name || "Crop Disease",
    causal_agent: d.causal_agent || d.casual_agent || "Pathogen / Pest",
    severity: (d.severity || d.severity_level || "Moderate") as SeverityLevel,
    confidence_score: typeof d.confidence_score === "number"
      ? Math.round(d.confidence_score <= 1 ? d.confidence_score * 100 : d.confidence_score)
      : 90,
    symptoms_observed: d.symptoms_observed && d.symptoms_observed.length > 0
      ? d.symptoms_observed
      : d.key_symptoms || ["Leaf discoloration and tissue spotting observed."],
    treatment_plan: {
      organic_methods: d.treatment_plan?.organic_methods || d.remediation?.organic_treatment || report.remediation.organic_treatment,
      chemical_methods: d.treatment_plan?.chemical_methods || d.remediation?.chemical_treatment || report.remediation.chemical_treatment,
    },
  }));

  if (diagnoses.length === 0) {
    diagnoses.push({
      condition_name: report.diagnosis.disease_name,
      causal_agent: report.diagnosis.causal_agent || report.diagnosis.casual_agent,
      severity: report.diagnosis.severity_level,
      confidence_score: Math.round(report.confidence_score <= 1 ? report.confidence_score * 100 : report.confidence_score),
      symptoms_observed: report.diagnosis.key_symptoms,
      treatment_plan: {
        organic_methods: report.remediation.organic_treatment,
        chemical_methods: report.remediation.chemical_treatment,
      },
    });
  }

  return {
    is_valid_specimen: report.is_valid_specimen,
    error_message: report.error_message,
    crop_details: {
      common_name: report.crop_details.common_name,
      scientific_name: report.crop_details.scientific_name,
      overall_status: overallStatus,
    },
    diagnoses,
    weather_risk_advisory: {
      risk_level: report.weather_risk_advisory.risk_level || (report.diagnosis.severity_level === "Critical" || report.diagnosis.severity_level === "High" ? "High" : "Moderate"),
      advice: report.weather_risk_advisory.advice || `${report.weather_risk_advisory.high_risk_conditions} ${report.weather_risk_advisory.preventative_action}`.trim(),
    },
    localized_advisory: {
      language: report.localized_advisory?.language || report.localized_text.language,
      summary_script: report.localized_advisory?.summary_script || report.localized_text.summary_audio_script,
    },
  };
}

/**
 * Normalizes any incoming diagnostic report (supporting single diagnosis or multi diagnoses array)
 */
export function normalizeDiagnosticReport(raw: any, defaultLanguage: string = "English"): DiagnosticReport {
  if (!raw || typeof raw !== "object") {
    throw new Error("Invalid diagnostic payload");
  }

  // Handle specimen validity across new SIH schema ("is_valid_specimen") and older "is_valid_crop_image"
  const isValid = raw.is_valid_specimen !== undefined
    ? Boolean(raw.is_valid_specimen)
    : (raw.is_valid_crop_image !== false);

  const errorMessage: string | null = raw.error_message || raw.invalid_reason || (isValid ? null : "Image does not show a recognizable agricultural crop or plant specimen.");

  const rawConfidence = typeof raw.confidence_score === "number" ? raw.confidence_score : 0.91;
  const confidence = rawConfidence > 1 ? rawConfidence / 100 : rawConfidence;

  // Determine Overall Status
  let overallStatus: OverallCropStatus = "DISEASED";
  if (raw.crop_details?.overall_status) {
    overallStatus = raw.crop_details.overall_status.toUpperCase() as OverallCropStatus;
  } else if (raw.crop_details?.leaf_condition) {
    const lc = raw.crop_details.leaf_condition.toLowerCase();
    if (lc.includes("health")) overallStatus = "HEALTHY";
    else if (lc.includes("pest")) overallStatus = "PEST_INFESTED";
    else if (lc.includes("nutri")) overallStatus = "NUTRIENT_DEFICIENT";
    else overallStatus = "DISEASED";
  }

  let leafCondition: LeafCondition = "Diseased";
  if (!isValid) leafCondition = "Invalid Image";
  else if (overallStatus === "HEALTHY") leafCondition = "Healthy";
  else if (overallStatus === "PEST_INFESTED") leafCondition = "Pest Attack";
  else if (overallStatus === "NUTRIENT_DEFICIENT") leafCondition = "Nutrient Deficiency";

  const cropDetails: CropDetails = {
    common_name: raw.crop_details?.crop_name_english || raw.crop_details?.common_name || "Cotton",
    crop_name_english: raw.crop_details?.crop_name_english || raw.crop_details?.common_name || "Cotton",
    crop_name_marathi: raw.crop_details?.crop_name_marathi || (raw.crop_details?.common_name?.toLowerCase().includes("cotton") ? "कापूस" : undefined),
    variety: raw.crop_details?.variety || "BT Cotton",
    growth_stage: raw.crop_details?.growth_stage || "Vegetative / Flowering",
    scientific_name: raw.crop_details?.scientific_name || (raw.crop_details?.crop_name_english === "Cotton" ? "Gossypium hirsutum" : "Solanum lycopersicum"),
    overall_status: overallStatus,
    leaf_condition: leafCondition,
  };

  let diagnoses: DiagnosisItem[] = [];

  if (Array.isArray(raw.diagnoses) && raw.diagnoses.length > 0) {
    diagnoses = raw.diagnoses.map((item: any, idx: number) => {
      const conditionName = item.condition_name || item.disease_name || "Pathological Condition";
      const conditionMarathi = item.condition_marathi;
      const agent = item.causal_agent || item.casual_agent || "Biological Pathogen / Pest";
      const rawSev = item.severity || item.severity_level || "Moderate";
      const severity = (["Low", "Moderate", "High", "Critical"].includes(rawSev) ? rawSev : "Moderate") as SeverityLevel;
      
      const itemConfidence = typeof item.confidence_score === "number"
        ? (item.confidence_score > 1 ? item.confidence_score : Math.round(item.confidence_score * 100))
        : Math.round(confidence * 100) - (idx * 5);

      const symptoms = Array.isArray(item.symptoms_observed)
        ? item.symptoms_observed
        : (Array.isArray(item.key_symptoms) ? item.key_symptoms : ["Observed symptoms on foliage"]);

      const ipmAdv: IPMAdvisory = {
        cultural_mechanical: item.ipm_advisory?.cultural_mechanical || "Install 2 Pheromone traps per acre. Remove and destroy infested plant parts.",
        biological: item.ipm_advisory?.biological || "Release Trichogramma or apply 5% Neem Seed Kernel Extract (NSKE).",
        chemical_safe_dosage: item.ipm_advisory?.chemical_safe_dosage || "Spray Profenofos 50% EC @ 2ml per Liter of water if ETL threshold is exceeded.",
      };

      const organicMethods = item.treatment_plan?.organic_methods || item.remediation?.organic_treatment || [
        ipmAdv.cultural_mechanical,
        ipmAdv.biological,
      ];

      const chemicalMethods = item.treatment_plan?.chemical_methods || item.remediation?.chemical_treatment || [
        ipmAdv.chemical_safe_dosage,
      ];

      const areaPercentage = typeof item.estimated_affected_area_percentage === "number"
        ? item.estimated_affected_area_percentage
        : (severity === "Critical" ? 65 : severity === "High" ? 40 : severity === "Moderate" ? 22 : 8);

      return {
        condition_name: conditionName,
        condition_marathi: conditionMarathi,
        disease_name: conditionName,
        causal_agent: agent,
        casual_agent: agent,
        severity,
        severity_level: severity,
        confidence_score: itemConfidence,
        estimated_affected_area_percentage: areaPercentage,
        symptoms_observed: symptoms,
        key_symptoms: symptoms,
        ipm_advisory: ipmAdv,
        treatment_plan: {
          organic_methods: organicMethods,
          chemical_methods: chemicalMethods,
        },
        remediation: {
          organic_treatment: organicMethods,
          chemical_treatment: chemicalMethods,
          fertilizer_adjustment: item.remediation?.fertilizer_adjustment || "Maintain standard balanced NPK fertigation.",
        },
      };
    });
  } else if (raw.diagnosis) {
    const conditionName = raw.diagnosis.disease_name || raw.diagnosis.condition_name || "Early Blight";
    const agent = raw.diagnosis.causal_agent || raw.diagnosis.casual_agent || "Alternaria solani (Fungus)";
    const severity = (raw.diagnosis.severity_level || raw.diagnosis.severity || "Moderate") as SeverityLevel;
    const symptoms = raw.diagnosis.key_symptoms || raw.diagnosis.symptoms_observed || ["Concentric ring spots on lower leaves"];
    const organicMethods = raw.remediation?.organic_treatment || ["Apply Neem oil solution (5 ml/L of water) every 7 days."];
    const chemicalMethods = raw.remediation?.chemical_treatment || ["Spray Mancozeb 75% WP @ 2g/L of water."];

    diagnoses = [
      {
        condition_name: conditionName,
        disease_name: conditionName,
        causal_agent: agent,
        casual_agent: agent,
        severity,
        severity_level: severity,
        confidence_score: Math.round(confidence * 100),
        estimated_affected_area_percentage: Number(raw.diagnosis.estimated_affected_area_percentage ?? 25),
        symptoms_observed: symptoms,
        key_symptoms: symptoms,
        treatment_plan: {
          organic_methods: organicMethods,
          chemical_methods: chemicalMethods,
        },
        remediation: {
          organic_treatment: organicMethods,
          chemical_treatment: chemicalMethods,
          fertilizer_adjustment: raw.remediation?.fertilizer_adjustment || "Maintain standard NPK schedule.",
        },
      },
    ];
  } else {
    diagnoses = [
      {
        condition_name: "Early Blight",
        disease_name: "Early Blight",
        causal_agent: "Alternaria solani (Fungus)",
        casual_agent: "Alternaria solani (Fungus)",
        severity: "Moderate",
        severity_level: "Moderate",
        confidence_score: 91,
        estimated_affected_area_percentage: 20,
        symptoms_observed: ["Concentric ring spots on lower leaves", "Chlorotic yellowing surrounding lesions"],
        key_symptoms: ["Concentric ring spots on lower leaves", "Chlorotic yellowing surrounding lesions"],
        treatment_plan: {
          organic_methods: ["Apply Neem oil solution (5 ml/L of water) every 7 days.", "Prune severely infected lower leaves."],
          chemical_methods: ["Spray Mancozeb 75% WP @ 2g/L of water.", "Alternate with Copper Oxychloride 50% WP @ 3g/L."],
        },
        remediation: {
          organic_treatment: ["Apply Neem oil solution (5 ml/L of water) every 7 days."],
          chemical_treatment: ["Spray Mancozeb 75% WP @ 2g/L of water."],
          fertilizer_adjustment: "Maintain standard balanced NPK.",
        },
      },
    ];
  }

  // Sort diagnoses by severity (Critical -> High -> Moderate -> Low)
  const severityOrder: Record<SeverityLevel, number> = { Critical: 4, High: 3, Moderate: 2, Low: 1 };
  diagnoses.sort((a, b) => severityOrder[b.severity_level] - severityOrder[a.severity_level]);

  // Primary diagnosis
  const primary = diagnoses[0];
  const diagnosisDetails: DiagnosisDetails = {
    disease_name: primary.disease_name,
    casual_agent: primary.causal_agent || primary.casual_agent || "Pathogen",
    causal_agent: primary.causal_agent || primary.casual_agent || "Pathogen",
    severity_level: primary.severity_level,
    estimated_affected_area_percentage: primary.estimated_affected_area_percentage,
    key_symptoms: primary.key_symptoms,
  };

  // Compile remediation
  let organic_treatment: string[] = [];
  let chemical_treatment: string[] = [];
  let fertilizer_adjustment = "Maintain standard recommended NPK schedule and ensure proper furrow drainage.";

  diagnoses.forEach((d) => {
    if (d.treatment_plan?.organic_methods) {
      d.treatment_plan.organic_methods.forEach((t) => {
        if (!organic_treatment.includes(t)) organic_treatment.push(t);
      });
    } else if (d.remediation?.organic_treatment) {
      d.remediation.organic_treatment.forEach((t) => {
        if (!organic_treatment.includes(t)) organic_treatment.push(t);
      });
    }

    if (d.treatment_plan?.chemical_methods) {
      d.treatment_plan.chemical_methods.forEach((t) => {
        if (!chemical_treatment.includes(t)) chemical_treatment.push(t);
      });
    } else if (d.remediation?.chemical_treatment) {
      d.remediation.chemical_treatment.forEach((t) => {
        if (!chemical_treatment.includes(t)) chemical_treatment.push(t);
      });
    }
  });

  if (organic_treatment.length === 0) {
    organic_treatment = ["Apply Neem oil solution (5 ml/L of water) every 7 days."];
  }
  if (chemical_treatment.length === 0) {
    chemical_treatment = ["Spray Mancozeb 75% WP @ 2g/L of water."];
  }

  const remediation: RemediationDetails = {
    organic_treatment,
    chemical_treatment,
    fertilizer_adjustment,
  };

  // Weather Risk Advisory parsing
  const weatherRiskRaw = raw.weather_risk_advisory || {};
  const riskLevel = weatherRiskRaw.risk_level || (primary.severity_level === "Critical" || primary.severity_level === "High" ? "High" : "Moderate");
  const advice = weatherRiskRaw.advice ||
    (weatherRiskRaw.high_risk_conditions && weatherRiskRaw.preventative_action
      ? `${weatherRiskRaw.high_risk_conditions} ${weatherRiskRaw.preventative_action}`.trim()
      : "High relative humidity promotes fungal spore germination. Avoid overhead sprinkler irrigation.");

  const weather_risk_advisory: WeatherRiskAdvisory = {
    risk_level: riskLevel,
    advice,
    high_risk_conditions: weatherRiskRaw.high_risk_conditions || "High relative humidity and warm canopy temperatures promote pathogen proliferation.",
    preventative_action: weatherRiskRaw.preventative_action || advice,
  };

  // Localized Advisory parsing
  const locRaw = raw.localized_advisory || raw.localized_text || {};
  const locLang = locRaw.language || defaultLanguage || "Hindi";
  const locScript = locRaw.summary_script || locRaw.summary_audio_script ||
    `आपकी ${cropDetails.common_name} की फसल में ${primary.disease_name} के लक्षण पाए गए हैं। तुरंत नीम के तेल (5 मिली/लीटर) या मैंकोजेब (2 ग्राम/लीटर) का छिड़काव करें।`;

  const localized_advisory: SIHLocalizedAdvisory = {
    language: locLang,
    summary_script: locScript,
  };

  const localized_text: LocalizedText = {
    language: locLang,
    summary_audio_script: locScript,
  };

  // Predictive weather risk for Maharashtra block-level computation
  const rawPredRisk = raw.predictive_weather_risk;
  const defaultRiskScore = primary.severity_level === "Critical" ? 88 : primary.severity_level === "High" ? 85 : primary.severity_level === "Moderate" ? 65 : 25;
  const predictive_weather_risk: PredictiveWeatherRisk = rawPredRisk && typeof rawPredRisk.block_outbreak_risk_score === "number"
    ? {
        block_outbreak_risk_score: rawPredRisk.block_outbreak_risk_score,
        risk_level: rawPredRisk.risk_level || (rawPredRisk.block_outbreak_risk_score >= 80 ? "CRITICAL_HOTSPOT" : rawPredRisk.block_outbreak_risk_score >= 60 ? "HIGH_RISK" : "MODERATE_RISK"),
        contributing_factors: rawPredRisk.contributing_factors || weather_risk_advisory.advice || "Relative humidity >80% with cloudy conditions favors rapid pest multiplication in the next 72 hours.",
      }
    : {
        block_outbreak_risk_score: defaultRiskScore,
        risk_level: defaultRiskScore >= 80 ? "CRITICAL_HOTSPOT" : defaultRiskScore >= 60 ? "HIGH_RISK" : "MODERATE_RISK",
        contributing_factors: weather_risk_advisory.advice || "Relative humidity >80% with cloudy conditions favors rapid pest multiplication in the next 72 hours.",
      };

  // Hotspot geospatial flag
  const rawHotspot = raw.hotspot_geospatial_flag;
  const hotspot_geospatial_flag: HotspotGeospatialFlag = rawHotspot && typeof rawHotspot.trigger_block_alert === "boolean"
    ? {
        trigger_block_alert: rawHotspot.trigger_block_alert,
        recommended_radius_km: rawHotspot.recommended_radius_km || 5,
        alert_message_marathi: rawHotspot.alert_message_marathi || `सावधान! तुमच्या तालुक्यात प्रादुर्भाव वाढला आहे. कामगंध सापळे त्वरित बसवा.`,
      }
    : {
        trigger_block_alert: predictive_weather_risk.block_outbreak_risk_score >= 70,
        recommended_radius_km: 5,
        alert_message_marathi: `सावधान! तुमच्या तालुक्यात प्रादुर्भाव वाढला आहे. कामगंध सापळे त्वरित बसवा.`,
      };

  const marathi_audio_script: string = raw.marathi_audio_script ||
    `तुमच्या ${cropDetails.crop_name_marathi || "पिकावर"} प्रादुर्भाव दिसून येत आहे. हे नियंत्रणात आणण्यासाठी एकात्मिक कीड नियंत्रण (IPM) पद्धतीचा वापर करा.`;

  const normalizedReport: DiagnosticReport = {
    is_valid_specimen: isValid,
    is_valid_crop_image: isValid,
    error_message: errorMessage,
    confidence_score: confidence,
    crop_details: cropDetails,
    diagnosis: diagnosisDetails,
    diagnoses,
    remediation,
    weather_risk_advisory,
    localized_advisory,
    localized_text,
    predictive_weather_risk,
    hotspot_geospatial_flag,
    marathi_audio_script,
    invalid_reason: errorMessage || undefined,
  };

  normalizedReport.sih_json = toSIHJson(normalizedReport);
  normalizedReport.maharashtra_json = toMaharashtraSIHJson(normalizedReport);

  return normalizedReport;
}

export type SupportedLanguage = 
  | "Hindi"
  | "Tamil"
  | "Marathi"
  | "Telugu"
  | "Bengali"
  | "Gujarati"
  | "Punjabi"
  | "Kannada"
  | "English";

export interface EmergencyService {
  name: string;
  category: "Helpline" | "Center" | "Portal" | "Emergency";
  description: string;
  phone?: string;
  url?: string;
  mapsQuery?: string;
  timing?: string;
  badge?: string;
}

export interface OfflineDiseaseKnowledge {
  id: string;
  crop: string;
  disease_name: string;
  condition: LeafCondition;
  symptoms: string[];
  organic: string[];
  chemical: string[];
  fertilizer: string;
  weather_risk: string;
  sampleThumbnail?: string;
}
