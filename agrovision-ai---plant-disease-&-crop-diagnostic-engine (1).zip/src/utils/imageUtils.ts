/**
 * Utility to rasterize SVGs, data URLs, and images into clean JPEG Base64 data URLs
 * Suitable for both Gemini API multimodal inputs and HTML5 canvas display.
 */

export async function ensureJpegDataUrl(imageUrl: string): Promise<string> {
  // If it's already a standard JPEG or PNG Base64 data URL with valid header
  if (imageUrl.startsWith("data:image/jpeg;base64,") || imageUrl.startsWith("data:image/png;base64,")) {
    return imageUrl;
  }

  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = "anonymous";

    img.onload = () => {
      try {
        const canvas = document.createElement("canvas");
        const maxDim = 800;
        let width = img.naturalWidth || img.width || 600;
        let height = img.naturalHeight || img.height || 600;

        if (width > maxDim || height > maxDim) {
          if (width > height) {
            height = Math.round((height * maxDim) / width);
            width = maxDim;
          } else {
            width = Math.round((width * maxDim) / height);
            height = maxDim;
          }
        }

        canvas.width = Math.max(width, 100);
        canvas.height = Math.max(height, 100);
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          return resolve(imageUrl);
        }

        // Fill background with dark slate so transparent SVGs render cleanly
        ctx.fillStyle = "#0f172a";
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

        const jpegUrl = canvas.toDataURL("image/jpeg", 0.9);
        resolve(jpegUrl);
      } catch (err) {
        console.warn("Canvas conversion error, using original:", err);
        resolve(imageUrl);
      }
    };

    img.onerror = (err) => {
      console.warn("Image load error for rasterization:", err);
      // Fallback: If it's an SVG data URI with utf8 encoding, convert to base64 data URI directly
      if (imageUrl.startsWith("data:image/svg+xml")) {
        try {
          const parts = imageUrl.split(",");
          if (parts.length > 1) {
            const rawSvg = decodeURIComponent(parts[1]);
            const b64 = btoa(unescape(encodeURIComponent(rawSvg)));
            resolve(`data:image/svg+xml;base64,${b64}`);
            return;
          }
        } catch {
          // ignore
        }
      }
      resolve(imageUrl);
    };

    img.src = imageUrl;
  });
}
