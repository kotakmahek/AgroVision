// Web Speech API Voice Engine for AgroVision Maharashtra
// Provides high-fidelity speech synthesis with fallback to Hindi or nearest Indian English voice
// when Marathi (mr-IN) voice is absent on the host OS/browser.

export interface SpeechEngineState {
  isPlaying: boolean;
  isPaused: boolean;
  currentTimeSec: number;
  durationEstimateSec: number;
  activeLanguage: string;
  activeText: string;
  availableVoices: SpeechSynthesisVoice[];
  selectedVoice: SpeechSynthesisVoice | null;
  playbackRate: number;
  pitch: number;
  volume: number;
}

export interface SpeechEngineOptions {
  rate?: number;
  pitch?: number;
  volume?: number;
  onStart?: () => void;
  onEnd?: () => void;
  onError?: (err: any) => void;
  onPause?: () => void;
  onResume?: () => void;
}

class BrowserSpeechEngine {
  private currentUtterance: SpeechSynthesisUtterance | null = null;
  private voices: SpeechSynthesisVoice[] = [];
  private isLoaded: boolean = false;
  private rate: number = 0.9; // 0.9x speed optimal for rural comprehension
  private pitch: number = 1.0;
  private volume: number = 1.0;

  constructor() {
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      this.initVoices();
      if (window.speechSynthesis.onvoiceschanged !== undefined) {
        window.speechSynthesis.onvoiceschanged = () => {
          this.initVoices();
        };
      }
    }
  }

  private initVoices() {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
    this.voices = window.speechSynthesis.getVoices();
    this.isLoaded = this.voices.length > 0;
  }

  public getVoices(): SpeechSynthesisVoice[] {
    if (this.voices.length === 0 && typeof window !== "undefined" && "speechSynthesis" in window) {
      this.voices = window.speechSynthesis.getVoices();
    }
    return this.voices;
  }

  public isSupported(): boolean {
    return typeof window !== "undefined" && "speechSynthesis" in window;
  }

  public isSpeaking(): boolean {
    if (!this.isSupported()) return false;
    return window.speechSynthesis.speaking;
  }

  public isPaused(): boolean {
    if (!this.isSupported()) return false;
    return window.speechSynthesis.paused;
  }

  public pause(): void {
    if (this.isSupported() && window.speechSynthesis.speaking) {
      window.speechSynthesis.pause();
    }
  }

  public resume(): void {
    if (this.isSupported() && window.speechSynthesis.paused) {
      window.speechSynthesis.resume();
    }
  }

  public stop(): void {
    if (this.isSupported()) {
      window.speechSynthesis.cancel();
      this.currentUtterance = null;
    }
  }

  /**
   * Finds the best voice for Marathi (mr-IN).
   * Prioritizes native Marathi voices, then Hindi (hi-IN) which shares Devanagari phonology,
   * then Indian English (en-IN), and finally system default.
   */
  public findBestMarathiVoice(): SpeechSynthesisVoice | null {
    const voices = this.getVoices();
    if (!voices || voices.length === 0) return null;

    // 1. Direct Marathi voice (e.g. Google मराठी, Marathi India, mr-IN)
    const mrVoice = voices.find(
      (v) => v.lang === "mr-IN" || v.lang.startsWith("mr") || v.name.toLowerCase().includes("marathi")
    );
    if (mrVoice) return mrVoice;

    // 2. Hindi voice (Devanagari script phoneme matching)
    const hiVoice = voices.find(
      (v) => v.lang === "hi-IN" || v.lang.startsWith("hi") || v.name.toLowerCase().includes("hindi")
    );
    if (hiVoice) return hiVoice;

    // 3. Indian English / Regional Indian voice
    const inVoice = voices.find(
      (v) => v.lang === "en-IN" || v.lang.includes("IN")
    );
    if (inVoice) return inVoice;

    return null;
  }

  /**
   * Speak Marathi script or any text with Web Speech API
   */
  public speak(
    text: string,
    langCode: string = "mr-IN",
    options?: SpeechEngineOptions
  ): boolean {
    if (!this.isSupported()) {
      console.warn("Web Speech API is not supported in this browser environment.");
      options?.onError?.(new Error("Web Speech API not supported"));
      return false;
    }

    if (!text || text.trim().length === 0) {
      options?.onError?.(new Error("Empty text string provided"));
      return false;
    }

    // Always stop previous utterances to avoid queuing overlap
    this.stop();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = langCode;
    utterance.rate = options?.rate ?? this.rate;
    utterance.pitch = options?.pitch ?? this.pitch;
    utterance.volume = options?.volume ?? this.volume;

    // Assign appropriate voice
    const bestVoice = langCode.startsWith("mr") ? this.findBestMarathiVoice() : null;
    if (bestVoice) {
      utterance.voice = bestVoice;
    } else {
      // Fallback voice selection for other languages
      const voices = this.getVoices();
      const match = voices.find((v) => v.lang.startsWith(langCode.substring(0, 2)));
      if (match) {
        utterance.voice = match;
      }
    }

    utterance.onstart = () => {
      options?.onStart?.();
    };

    utterance.onend = () => {
      this.currentUtterance = null;
      options?.onEnd?.();
    };

    utterance.onerror = (e) => {
      this.currentUtterance = null;
      options?.onError?.(e);
    };

    utterance.onpause = () => {
      options?.onPause?.();
    };

    utterance.onresume = () => {
      options?.onResume?.();
    };

    this.currentUtterance = utterance;
    window.speechSynthesis.speak(utterance);
    return true;
  }
}

export const speechEngine = new BrowserSpeechEngine();
