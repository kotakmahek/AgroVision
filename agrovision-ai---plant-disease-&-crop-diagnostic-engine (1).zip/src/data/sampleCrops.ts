export interface SampleCrop {
  id: string;
  title: string;
  crop: string;
  condition: string;
  description: string;
  imageUrl: string;
  isInvalidTest?: boolean;
}

// Helper to generate realistic visual SVG data URLs for instant zero-network test samples
function createLeafSvgDataUrl(type: "tomato_blight" | "tomato_co_infection" | "rice_blast" | "potato_late_blight" | "cotton_curl" | "wheat_rust" | "healthy_maize" | "invalid_object"): string {
  if (type === "tomato_co_infection") {
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600">
      <defs>
        <radialGradient id="bgCo" cx="50%" cy="50%" r="70%">
          <stop offset="0%" stop-color="#1e293b"/>
          <stop offset="100%" stop-color="#090d16"/>
        </radialGradient>
        <radialGradient id="leafGradCo" cx="40%" cy="40%" r="60%">
          <stop offset="0%" stop-color="#48bb78"/>
          <stop offset="60%" stop-color="#2f855a"/>
          <stop offset="100%" stop-color="#1f4b36"/>
        </radialGradient>
        <radialGradient id="lesionGradCo" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stop-color="#451a03"/>
          <stop offset="40%" stop-color="#78350f"/>
          <stop offset="70%" stop-color="#b45309"/>
          <stop offset="90%" stop-color="#eab308"/>
          <stop offset="100%" stop-color="transparent"/>
        </radialGradient>
      </defs>
      <rect width="600" height="600" fill="url(#bgCo)"/>
      <g transform="translate(300, 300) rotate(-10)">
        <!-- Stem -->
        <path d="M-10,260 Q-5,100 0,-150" stroke="#276749" stroke-width="12" fill="none" stroke-linecap="round"/>
        <!-- Tomato Leaf Blade -->
        <path d="M0,-180 C140,-120 180,40 120,160 C70,240 20,240 0,250 C-20,240 -70,240 -120,160 C-180,40 -140,-120 0,-180 Z" fill="url(#leafGradCo)"/>
        <!-- Main Veins -->
        <path d="M0,240 Q0,50 0,-170" stroke="#38a169" stroke-width="4" fill="none"/>
        <path d="M0,150 Q50,110 100,120" stroke="#38a169" stroke-width="2.5" fill="none"/>
        <path d="M0,150 Q-50,110 -100,120" stroke="#38a169" stroke-width="2.5" fill="none"/>
        <path d="M0,60 Q60,10 110,30" stroke="#38a169" stroke-width="2.5" fill="none"/>
        <path d="M0,60 Q-60,10 -110,30" stroke="#38a169" stroke-width="2.5" fill="none"/>

        <!-- Early Blight Concentric Rings (25% Area) -->
        <g transform="translate(35, 80)">
          <circle cx="0" cy="0" r="36" fill="url(#lesionGradCo)"/>
          <circle cx="0" cy="0" r="26" stroke="#292524" stroke-width="2" fill="none"/>
          <circle cx="0" cy="0" r="16" stroke="#44403c" stroke-width="2" fill="none"/>
          <circle cx="0" cy="0" r="8" fill="#1c1917"/>
        </g>
        <g transform="translate(-40, 130)">
          <circle cx="0" cy="0" r="30" fill="url(#lesionGradCo)"/>
          <circle cx="0" cy="0" r="20" stroke="#292524" stroke-width="2" fill="none"/>
          <circle cx="0" cy="0" r="10" stroke="#44403c" stroke-width="2" fill="none"/>
        </g>

        <!-- Chlorotic yellowing around lesions -->
        <path d="M-60,160 C-90,140 -110,120 -80,180 Z" fill="#ca8a04" opacity="0.65"/>

        <!-- Spider Mite Fine White Stippling (Tetranychidae ~10% Area) -->
        <g fill="#f8fafc" opacity="0.85">
          <circle cx="-20" cy="-40" r="2.5"/>
          <circle cx="-15" cy="-35" r="2"/>
          <circle cx="-25" cy="-30" r="2.2"/>
          <circle cx="-18" cy="-25" r="1.8"/>
          <circle cx="-30" cy="-45" r="2"/>
          <circle cx="-10" cy="-50" r="2.2"/>
          <circle cx="20" cy="-20" r="2.5"/>
          <circle cx="28" cy="-15" r="2.2"/>
          <circle cx="15" cy="-10" r="1.8"/>
          <circle cx="35" cy="-25" r="2"/>
          <circle cx="45" cy="-10" r="2.5"/>
          <circle cx="30" cy="-35" r="1.8"/>
          <circle cx="-40" cy="10" r="2"/>
          <circle cx="-50" cy="15" r="2.2"/>
          <circle cx="-35" cy="25" r="1.8"/>
          <circle cx="50" cy="40" r="2.2"/>
          <circle cx="60" cy="35" r="1.8"/>
          <circle cx="55" cy="50" r="2.5"/>
        </g>
        <!-- Fine Spider Mite Webbing Silk Threads -->
        <path d="M-30,-45 Q-15,-20 20,-20" stroke="#f8fafc" stroke-width="0.8" fill="none" opacity="0.5"/>
        <path d="M-20,-30 Q5,-5 35,-25" stroke="#f8fafc" stroke-width="0.7" fill="none" opacity="0.4"/>
      </g>
      <text x="30" y="540" fill="#f59e0b" font-family="sans-serif" font-size="14" font-weight="bold">MULTI-DIAGNOSIS SPECIMEN: Tomato Foliage</text>
      <text x="30" y="565" fill="#94a3b8" font-family="sans-serif" font-size="12">1. Early Blight (Alternaria solani) + 2. Spider Mites (Tetranychidae)</text>
    </svg>`;
    return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
  }

  if (type === "tomato_blight") {
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600">
      <defs>
        <radialGradient id="bg" cx="50%" cy="50%" r="70%">
          <stop offset="0%" stop-color="#2d3748"/>
          <stop offset="100%" stop-color="#1a202c"/>
        </radialGradient>
        <radialGradient id="leafGrad" cx="40%" cy="40%" r="60%">
          <stop offset="0%" stop-color="#48bb78"/>
          <stop offset="60%" stop-color="#2f855a"/>
          <stop offset="100%" stop-color="#22543d"/>
        </radialGradient>
        <radialGradient id="lesionGrad" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stop-color="#451a03"/>
          <stop offset="40%" stop-color="#78350f"/>
          <stop offset="70%" stop-color="#b45309"/>
          <stop offset="90%" stop-color="#eab308"/>
          <stop offset="100%" stop-color="transparent"/>
        </radialGradient>
      </defs>
      <rect width="600" height="600" fill="url(#bg)"/>
      <g transform="translate(300, 300) rotate(-15)">
        <!-- Stem -->
        <path d="M-10,260 Q-5,100 0,-150" stroke="#276749" stroke-width="12" fill="none" stroke-linecap="round"/>
        <!-- Tomato Leaf Blade -->
        <path d="M0,-180 C140,-120 180,40 120,160 C70,240 20,240 0,250 C-20,240 -70,240 -120,160 C-180,40 -140,-120 0,-180 Z" fill="url(#leafGrad)"/>
        <!-- Main Veins -->
        <path d="M0,240 Q0,50 0,-170" stroke="#38a169" stroke-width="4" fill="none"/>
        <path d="M0,150 Q50,110 100,120" stroke="#38a169" stroke-width="2.5" fill="none"/>
        <path d="M0,150 Q-50,110 -100,120" stroke="#38a169" stroke-width="2.5" fill="none"/>
        <path d="M0,60 Q60,10 110,30" stroke="#38a169" stroke-width="2.5" fill="none"/>
        <path d="M0,60 Q-60,10 -110,30" stroke="#38a169" stroke-width="2.5" fill="none"/>
        <path d="M0,-40 Q50,-90 90,-70" stroke="#38a169" stroke-width="2" fill="none"/>
        <path d="M0,-40 Q-50,-90 -90,-70" stroke="#38a169" stroke-width="2" fill="none"/>
        
        <!-- Concentric rings / Early Blight lesions (Alternaria solani target boards) -->
        <g transform="translate(35, 70)">
          <circle cx="0" cy="0" r="38" fill="url(#lesionGrad)"/>
          <circle cx="0" cy="0" r="28" stroke="#292524" stroke-width="2" fill="none"/>
          <circle cx="0" cy="0" r="18" stroke="#44403c" stroke-width="2" fill="none"/>
          <circle cx="0" cy="0" r="8" fill="#1c1917"/>
        </g>
        <g transform="translate(-45, 120)">
          <circle cx="0" cy="0" r="32" fill="url(#lesionGrad)"/>
          <circle cx="0" cy="0" r="22" stroke="#292524" stroke-width="2" fill="none"/>
          <circle cx="0" cy="0" r="12" stroke="#44403c" stroke-width="2" fill="none"/>
        </g>
        <g transform="translate(40, -50)">
          <circle cx="0" cy="0" r="26" fill="url(#lesionGrad)"/>
          <circle cx="0" cy="0" r="16" stroke="#292524" stroke-width="2" fill="none"/>
        </g>
        <!-- Chlorosis (Yellowing halos) -->
        <path d="M-60,160 C-90,140 -110,120 -80,180 Z" fill="#ca8a04" opacity="0.6"/>
        <path d="M50,140 C90,130 110,160 80,190 Z" fill="#ca8a04" opacity="0.6"/>
      </g>
      <text x="30" y="560" fill="#a0aec0" font-family="sans-serif" font-size="14" font-weight="bold">SAMPLE: Solanum lycopersicum (Tomato Early Blight)</text>
    </svg>`;
    return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
  }

  if (type === "rice_blast") {
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600">
      <defs>
        <radialGradient id="riceBg" cx="50%" cy="50%" r="70%">
          <stop offset="0%" stop-color="#1e293b"/>
          <stop offset="100%" stop-color="#0f172a"/>
        </radialGradient>
        <linearGradient id="riceBlade" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stop-color="#15803d"/>
          <stop offset="50%" stop-color="#22c55e"/>
          <stop offset="100%" stop-color="#166534"/>
        </linearGradient>
      </defs>
      <rect width="600" height="600" fill="url(#riceBg)"/>
      <!-- Rice Blade -->
      <path d="M250,580 Q290,300 330,40 Q350,300 310,580 Z" fill="url(#riceBlade)"/>
      <path d="M280,580 Q300,300 320,40" stroke="#86efac" stroke-width="2" fill="none"/>
      
      <!-- Spindle-shaped blast lesions (Diamond shaped with gray center and brown margin) -->
      <g transform="translate(295, 200)">
        <path d="M0,-45 Q15,-15 12,0 Q10,15 0,45 Q-10,15 -12,0 Q-15,-15 0,-45 Z" fill="#78350f"/>
        <path d="M0,-30 Q8,-10 6,0 Q5,10 0,30 Q-5,10 -6,0 Q-8,-10 0,-30 Z" fill="#cbd5e1"/>
        <circle cx="0" cy="0" r="3" fill="#475569"/>
      </g>
      <g transform="translate(305, 340)">
        <path d="M0,-35 Q12,-10 10,0 Q8,10 0,35 Q-8,10 -10,0 Q-12,-10 0,-35 Z" fill="#78350f"/>
        <path d="M0,-22 Q6,-5 5,0 Q4,5 0,22 Q-4,5 -5,0 Q-6,-5 0,-22 Z" fill="#cbd5e1"/>
      </g>
      <g transform="translate(285, 420)">
        <path d="M0,-25 Q10,-8 8,0 Q6,8 0,25 Q-6,8 -8,0 Q-10,-8 0,-25 Z" fill="#92400e"/>
        <path d="M0,-15 Q4,-3 3,0 Q2,3 0,15 Q-2,3 -3,0 Q-4,-3 0,-15 Z" fill="#e2e8f0"/>
      </g>
      <text x="30" y="560" fill="#94a3b8" font-family="sans-serif" font-size="14" font-weight="bold">SAMPLE: Oryza sativa (Paddy / Rice Blast Lesions)</text>
    </svg>`;
    return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
  }

  if (type === "cotton_curl") {
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600">
      <defs>
        <radialGradient id="cottonBg" cx="50%" cy="50%" r="70%">
          <stop offset="0%" stop-color="#18181b"/>
          <stop offset="100%" stop-color="#09090b"/>
        </radialGradient>
      </defs>
      <rect width="600" height="600" fill="url(#cottonBg)"/>
      <g transform="translate(300, 310)">
        <!-- Distorted/cupped Cotton Leaf with enation and vein thickening -->
        <path d="M0,-170 C100,-150 170,-80 180,20 C190,110 120,180 30,220 C-10,230 -40,220 -80,200 C-160,160 -190,80 -170,-30 C-150,-120 -80,-160 0,-170 Z" fill="#4d7c0f"/>
        <!-- Thickened irregular yellow-green veins (typical of CLCuV) -->
        <path d="M0,210 Q-20,60 0,-160" stroke="#facc15" stroke-width="8" fill="none"/>
        <path d="M0,130 Q80,90 140,110" stroke="#fef08a" stroke-width="6" fill="none"/>
        <path d="M0,130 Q-90,100 -140,120" stroke="#fef08a" stroke-width="6" fill="none"/>
        <path d="M0,40 Q100,0 150,20" stroke="#fde047" stroke-width="6" fill="none"/>
        <path d="M0,40 Q-100,-10 -140,0" stroke="#fde047" stroke-width="6" fill="none"/>
        <!-- Upward leaf curling margin effect -->
        <path d="M150,20 C180,60 170,120 140,140" stroke="#365314" stroke-width="12" fill="none" stroke-linecap="round"/>
        <path d="M-140,0 C-180,50 -170,110 -130,130" stroke="#365314" stroke-width="12" fill="none" stroke-linecap="round"/>
      </g>
      <text x="30" y="560" fill="#a1a1aa" font-family="sans-serif" font-size="14" font-weight="bold">SAMPLE: Gossypium hirsutum (Cotton Leaf Curl Virus)</text>
    </svg>`;
    return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
  }

  if (type === "healthy_maize") {
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600">
      <defs>
        <radialGradient id="maizeBg" cx="50%" cy="50%" r="70%">
          <stop offset="0%" stop-color="#14532d"/>
          <stop offset="100%" stop-color="#052e16"/>
        </radialGradient>
        <linearGradient id="healthyLeaf" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stop-color="#22c55e"/>
          <stop offset="50%" stop-color="#16a34a"/>
          <stop offset="100%" stop-color="#15803d"/>
        </linearGradient>
      </defs>
      <rect width="600" height="600" fill="url(#maizeBg)"/>
      <g transform="translate(300, 300) rotate(15)">
        <path d="M0,-220 C120,-140 140,80 80,240 C30,280 0,270 0,270 C0,270 -30,280 -80,240 C-140,80 -120,-140 0,-220 Z" fill="url(#healthyLeaf)"/>
        <!-- Clear central midrib with zero necrotic lesions -->
        <path d="M0,270 Q0,40 0,-210" stroke="#bbf7d0" stroke-width="6" fill="none"/>
        <path d="M0,160 Q40,110 70,130" stroke="#4ade80" stroke-width="2" fill="none"/>
        <path d="M0,160 Q-40,110 -70,130" stroke="#4ade80" stroke-width="2" fill="none"/>
        <path d="M0,60 Q50,0 75,30" stroke="#4ade80" stroke-width="2" fill="none"/>
        <path d="M0,60 Q-50,0 -75,30" stroke="#4ade80" stroke-width="2" fill="none"/>
      </g>
      <text x="30" y="560" fill="#bbf7d0" font-family="sans-serif" font-size="14" font-weight="bold">SAMPLE: Zea mays (Healthy Corn Leaf - 0% Lesions)</text>
    </svg>`;
    return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
  }

  // Non-agricultural / Invalid object (a metallic wristwatch/desk) to test validation workflow
  const invalidSvg = `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600">
    <rect width="600" height="600" fill="#334155"/>
    <rect x="180" y="150" width="240" height="300" rx="16" fill="#64748b" stroke="#94a3b8" stroke-width="4"/>
    <circle cx="300" cy="300" r="80" fill="#1e293b" stroke="#cbd5e1" stroke-width="6"/>
    <line x1="300" y1="300" x2="300" y2="250" stroke="#38bdf8" stroke-width="4" stroke-linecap="round"/>
    <line x1="300" y1="300" x2="340" y2="300" stroke="#38bdf8" stroke-width="4" stroke-linecap="round"/>
    <text x="300" y="490" fill="#f1f5f9" font-family="sans-serif" font-size="16" font-weight="bold" text-anchor="middle">Non-Agricultural Object (Metallic Watch)</text>
    <text x="300" y="520" fill="#cbd5e1" font-family="sans-serif" font-size="13" text-anchor="middle">Test for is_valid_crop_image: false fallback</text>
  </svg>`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(invalidSvg)}`;
}

export const SAMPLE_CROPS: SampleCrop[] = [
  {
    id: "tomato-co-infection",
    title: "Tomato: Blight + Spider Mites",
    crop: "Tomato (Multi-Pathogen)",
    condition: "Dual Infection (Fungus + Pest)",
    description: "Concurrent Alternaria solani target lesions (25%) & Tetranychidae spider mite stippling (10%).",
    imageUrl: createLeafSvgDataUrl("tomato_co_infection"),
  },
  {
    id: "tomato-blight",
    title: "Tomato Early Blight",
    crop: "Tomato (Solanum lycopersicum)",
    condition: "Diseased (Alternaria solani)",
    description: "Concentric target-board rings on lower foliage with chlorotic yellowing halo.",
    imageUrl: createLeafSvgDataUrl("tomato_blight"),
  },
  {
    id: "rice-blast",
    title: "Paddy / Rice Blast",
    crop: "Rice (Oryza sativa)",
    condition: "Diseased (Magnaporthe oryzae)",
    description: "Classic spindle/diamond-shaped necrotic lesions with greyish-white ash centers.",
    imageUrl: createLeafSvgDataUrl("rice_blast"),
  },
  {
    id: "cotton-curl",
    title: "Cotton Leaf Curl",
    crop: "Cotton (Gossypium hirsutum)",
    condition: "Viral Attack (CLCuV)",
    description: "Severe upward vein thickening, cupping, and stunted vegetative node growth.",
    imageUrl: createLeafSvgDataUrl("cotton_curl"),
  },
  {
    id: "healthy-corn",
    title: "Healthy Corn Foliage",
    crop: "Maize (Zea mays)",
    condition: "Healthy (Vibrant Green)",
    description: "Deep green photosynthetic lamina with no fungal spots, insect bites, or chlorosis.",
    imageUrl: createLeafSvgDataUrl("healthy_maize"),
  },
  {
    id: "invalid-test",
    title: "Non-Crop Image (Fallback Test)",
    crop: "Non-Agricultural Item",
    condition: "Invalid Input Test",
    description: "Non-plant image to verify system rejection and guidance prompt.",
    imageUrl: createLeafSvgDataUrl("invalid_object"),
    isInvalidTest: true,
  },
];
