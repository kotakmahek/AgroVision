import React, { useState, useEffect } from "react";
import { Header } from "./components/Header";
import { UploadScanSection } from "./components/UploadScanSection";
import { DiagnosticReportView } from "./components/DiagnosticReportView";
import { CameraCaptureModal } from "./components/CameraCaptureModal";
import { EmergencyServicesModal } from "./components/EmergencyServicesModal";
import { OfflineCacheModal } from "./components/OfflineCacheModal";
import { DiagnosticReport, SupportedLanguage, normalizeDiagnosticReport } from "./types";
import { generateOfflineDiagnosticReport } from "./data/offlineKnowledge";
import { 
  AlertCircle, 
  Sprout, 
  ShieldCheck, 
  PhoneCall, 
  ExternalLink,
  MapPin,
  Cpu,
  Layers,
  HeartHandshake
} from "lucide-react";

export default function App() {
  const [currentLanguage, setCurrentLanguage] = useState<SupportedLanguage>("Hindi");
  const [isOfflineMode, setIsOfflineMode] = useState<boolean>(false);
  const [currentReport, setCurrentReport] = useState<DiagnosticReport | null>(null);
  const [uploadedImageUrl, setUploadedImageUrl] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Modals
  const [isCameraOpen, setIsCameraOpen] = useState<boolean>(false);
  const [isEmergencyOpen, setIsEmergencyOpen] = useState<boolean>(false);
  const [isCacheOpen, setIsCacheOpen] = useState<boolean>(false);

  // Saved diagnostic history in LocalStorage
  const [savedReports, setSavedReports] = useState<DiagnosticReport[]>(() => {
    try {
      const stored = localStorage.getItem("agrovision_reports_v1");
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem("agrovision_reports_v1", JSON.stringify(savedReports));
    } catch (e) {
      console.warn("Storage write error", e);
    }
  }, [savedReports]);

  const handleAnalyze = async ({
    imageBase64,
    mimeType,
    language,
    region,
    cropHint,
  }: {
    imageBase64: string;
    mimeType: string;
    language: SupportedLanguage;
    region: string;
    cropHint: string;
  }) => {
    setIsLoading(true);
    setErrorMsg(null);
    setUploadedImageUrl(imageBase64);

    // If offline mode is toggled by farmer / user, use local edge classification
    if (isOfflineMode) {
      setTimeout(() => {
        let presetKey = "tomato-early-blight";
        const hintLower = (cropHint || "").toLowerCase();
        if (hintLower.includes("mite") || hintLower.includes("co-infection") || hintLower.includes("multi") || hintLower.includes("dual")) presetKey = "tomato-co-infection";
        else if (hintLower.includes("rice") || hintLower.includes("paddy")) presetKey = "paddy-blast";
        else if (hintLower.includes("cotton")) presetKey = "cotton-leaf-curl";
        else if (hintLower.includes("potato")) presetKey = "potato-late-blight";

        const rawReport = generateOfflineDiagnosticReport(presetKey, language);
        const offlineReport = normalizeDiagnosticReport(rawReport, language);
        offlineReport.id = `scan_${Date.now()}`;
        offlineReport.timestamp = new Date().toLocaleString();
        offlineReport.imageUrl = imageBase64;

        setCurrentReport(offlineReport);
        setSavedReports((prev) => [offlineReport, ...prev]);
        setIsLoading(false);
      }, 700);
      return;
    }

    try {
      const res = await fetch("/api/diagnose", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          imageBase64,
          mimeType,
          language,
          region,
          cropHint,
        }),
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.message || errData.error || `Server returned error ${res.status}`);
      }

      const rawJson = await res.json();
      const report: DiagnosticReport = normalizeDiagnosticReport(rawJson, language);
      report.id = `scan_${Date.now()}`;
      report.timestamp = new Date().toLocaleString();
      report.imageUrl = imageBase64;
      if (!report.source) {
        report.source = "cloud_gemini";
      }

      setCurrentReport(report);
      // Save report to local SQLite/Storage cache
      if (report.is_valid_crop_image) {
        setSavedReports((prev) => [report, ...prev.slice(0, 49)]);
      }
    } catch (err: any) {
      console.error("Pathology engine failure:", err);
      // Fallback graceful degradation for field situations
      setErrorMsg(
        err?.message || "Failed to reach AI diagnostic engine. Switch to Offline Mode to diagnose via edge database."
      );
    } finally {
      setIsLoading(false);
    }
  };

  const handleCameraCapture = (base64Data: string) => {
    setUploadedImageUrl(base64Data);
    handleAnalyze({
      imageBase64: base64Data,
      mimeType: "image/jpeg",
      language: currentLanguage,
      region: "General India",
      cropHint: "",
    });
  };

  const handleClearHistory = () => {
    if (window.confirm("Are you sure you want to clear your local diagnostic cache?")) {
      setSavedReports([]);
      localStorage.removeItem("agrovision_reports_v1");
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-['Plus_Jakarta_Sans',sans-serif] selection:bg-emerald-500 selection:text-emerald-950">
      {/* Top Navbar */}
      <Header
        currentLanguage={currentLanguage}
        onLanguageChange={(lang) => {
          setCurrentLanguage(lang);
          // If we currently have a report, re-render its language audio script if offline
          if (currentReport && currentReport.source === "offline_cache") {
            const updated = generateOfflineDiagnosticReport(
              currentReport.crop_details?.common_name.toLowerCase().includes("rice")
                ? "paddy-blast"
                : currentReport.crop_details?.common_name.toLowerCase().includes("cotton")
                ? "cotton-leaf-curl"
                : "tomato-early-blight",
              lang
            );
            setCurrentReport({
              ...currentReport,
              localized_text: updated.localized_text,
            });
          }
        }}
        isOfflineMode={isOfflineMode}
        onToggleOffline={() => setIsOfflineMode((prev) => !prev)}
        onOpenEmergency={() => setIsEmergencyOpen(true)}
        onOpenOfflineCache={() => setIsCacheOpen(true)}
        savedCount={savedReports.length}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-6">
        {errorMsg && (
          <div className="max-w-4xl mx-auto mb-6 p-4 bg-rose-950/80 border border-rose-700/80 rounded-2xl flex items-start justify-between gap-3 text-rose-200 text-xs sm:text-sm animate-fade-in shadow-lg">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-rose-100">Pathology Processing Error</p>
                <p className="text-rose-300/90 mt-0.5">{errorMsg}</p>
                <div className="mt-2 flex gap-3">
                  <button
                    onClick={() => {
                      setIsOfflineMode(true);
                      setErrorMsg(null);
                    }}
                    className="px-3 py-1 bg-amber-600 hover:bg-amber-500 text-white rounded-lg text-xs font-bold transition"
                  >
                    Switch to Offline Mode
                  </button>
                  <button
                    onClick={() => setIsEmergencyOpen(true)}
                    className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-medium border border-slate-700"
                  >
                    Call Kisan Helpline (1800-180-1551)
                  </button>
                </div>
              </div>
            </div>
            <button
              onClick={() => setErrorMsg(null)}
              className="text-rose-400 hover:text-white text-xs font-bold"
            >
              Dismiss
            </button>
          </div>
        )}

        {/* Dynamic Display: Scanned Report vs Upload Interface */}
        {currentReport ? (
          <DiagnosticReportView
            report={currentReport}
            uploadedImageUrl={uploadedImageUrl}
            onReset={() => {
              setCurrentReport(null);
              setUploadedImageUrl(null);
            }}
            onOpenEmergency={() => setIsEmergencyOpen(true)}
          />
        ) : (
          <UploadScanSection
            onAnalyze={handleAnalyze}
            isLoading={isLoading}
            onOpenCamera={() => setIsCameraOpen(true)}
            currentLanguage={currentLanguage}
            isOfflineMode={isOfflineMode}
          />
        )}
      </main>

      {/* Modals */}
      <CameraCaptureModal
        isOpen={isCameraOpen}
        onClose={() => setIsCameraOpen(false)}
        onCapture={handleCameraCapture}
      />

      <EmergencyServicesModal
        isOpen={isEmergencyOpen}
        onClose={() => setIsEmergencyOpen(false)}
      />

      <OfflineCacheModal
        isOpen={isCacheOpen}
        onClose={() => setIsCacheOpen(false)}
        savedReports={savedReports}
        onSelectReport={(report) => {
          setCurrentReport(report);
          setUploadedImageUrl(report.imageUrl || null);
        }}
        onClearHistory={handleClearHistory}
        currentLanguage={currentLanguage}
      />

      {/* Footer tailored for Smart India Hackathon (SIH) and Indian Farmers */}
      <footer className="border-t border-slate-800 bg-slate-950 py-8 px-4 text-slate-400 text-xs">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-emerald-950 rounded-xl border border-emerald-800 text-emerald-400">
              <Sprout className="w-5 h-5" />
            </div>
            <div>
              <p className="font-bold text-slate-200">
                AgroVision AI — Smart India Hackathon (SIH) PathoEngine
              </p>
              <p className="text-[11px] text-slate-500">
                Indian Council of Agricultural Research (ICAR) Guidelines & CIBRC Chemical Standards
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4 flex-wrap text-[11px]">
            <a
              href="tel:18001801551"
              className="flex items-center gap-1.5 text-rose-400 hover:text-rose-300 font-bold transition"
            >
              <PhoneCall className="w-3.5 h-3.5" />
              Kisan Call Centre: 1800-180-1551
            </a>
            <span className="text-slate-700">•</span>
            <button
              onClick={() => setIsEmergencyOpen(true)}
              className="hover:text-emerald-300 transition"
            >
              Emergency Directory
            </button>
            <span className="text-slate-700">•</span>
            <button
              onClick={() => setIsCacheOpen(true)}
              className="hover:text-emerald-300 transition"
            >
              Offline SQLite Cache ({savedReports.length})
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
